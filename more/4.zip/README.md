# HDGL-OS

**Analog-over-digital ring-0 OS — Phase 1 complete, booting on bare metal**

```
=======================================================
  HDGL-OS / Temple2 Hybrid  v0.1  (Phase 1)
  YIN : TempleOS ring-0 model (HolyC-inspired C)
  YANG: Analog-Prime phi/Kuramoto conscious layer
  BOT : MCP-Jailbreak confined (zero-network cage)
=======================================================
[BOOT] multiboot2 OK
[YIN]  Temple2 ring-0 kernel ready
[YANG] HDGL phi/Kuramoto engine ready (K=3.0, 8 oscillators)
[BOT]  MCP-Jailbreak confined — ring-0 power, zero network
[PHY]  offline (no NIC driver yet) — bot still fully operational
[OS]   entering Frontierland REPL
```

---

## What Is HDGL-OS?

HDGL-OS is a freestanding x86-64 operating system kernel written in C99 and NASM assembly — no libc, no stdlib, no Linux, no Alpine. It boots via GRUB2 Multiboot2 directly to ring-0, and runs a stack of original systems:

**YIN** — a TempleOS-inspired deterministic ring-0 kernel (Temple2 primitives). HolyC-compatible execution environment, flat memory model, 16KB stack, 32MB bump-heap, x86 GDT/IDT/PIT/PIC all self-installed.

**YANG** — an 8-oscillator Kuramoto phi-resonance engine (Analog-Prime). Uses RK4 integration with phi-weighted natural frequencies, coupling K=3.0, locking detection via order parameter R. This is the "analog layer" — a continuous-time field running inside the discrete digital machine.

**BOT** — the MCP-Jailbreak confined bot. Ring-0 power, zero network. Stores and recalls knowledge via an ERL V3 FNV-hashed BST. Routes passes through: HolyC code execution, key-value store, recall, and Qwen-style inference (inference stub in Phase 1).

**PHY** — the zchg:// conscious networking layer. Scaffolded with HMAC-SHA256 gossip authentication and Intel I350 MMIO driver. Non-fatal in Phase 1 — OS runs fully without a NIC.

The OS is the analog-over-digital infrastructure for a fully distributed P2P ISP, where every node runs this same kernel, hosts the Frontierland UI, and participates in the CHG Coin economy.

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  Frontierland REPL  (serial readline, HolyC/HDGL)   │
├─────────────────────────────────────────────────────┤
│  BOT  MCP-Jailbreak   (ring-0, zero-network cage)    │
│       ERL V3 BST · pass routing · Qwen stub          │
├────────────────────┬────────────────────────────────┤
│  YANG              │  YIN                            │
│  Kuramoto 8-osc    │  Temple2 primitives             │
│  phi-lang tokens   │  GDT · IDT · PIT · heap         │
│  Analog-Prime      │  HolyC exec · scheduler         │
├────────────────────┴────────────────────────────────┤
│  PHY   zchg:// conscious networking                  │
│        HMAC-SHA256 gossip · I350 MMIO (scaffolded)   │
├─────────────────────────────────────────────────────┤
│  64-bit long mode  ·  PAE 64MB identity map          │
│  Multiboot2  ·  GRUB2  ·  El Torito ISO              │
└─────────────────────────────────────────────────────┘
        x86-64 bare metal / QEMU / iDRAC8
```

### Boot Chain (32-bit → 64-bit)

1. GRUB2 loads the Multiboot2 ELF. Hands off in 32-bit protected mode: `EAX` = magic `0x36d76289`, `EBX` = info pointer.
2. `multiboot_entry.asm` saves `EAX`/`EBX` as the very first two instructions (before anything can clobber `AL`).
3. Builds a 3-level PAE page table: PML4 → PDPT → PD. 32 huge-page entries, each 2MB, covering 64MB physical RAM (required because BSS extends to ~33MB).
4. Sets `CR3`, enables PAE (`CR4[5]`), sets `EFER.LME`, sets `CR0.PG` — activating long mode.
5. `lgdt` + far jump to 64-bit code segment (`gdt64.code`).
6. `long_mode_entry`: loads data segments, zero-extends saved mb2 registers into `RDI`/`RSI`, aligns stack to 16, calls `long_mode_start`.
7. `long_mode_start`: serial init → mb2 magic check → `temple2_init` (GDT, SSE, PIC, IDT, PIT) → `hdgl_phi_init` → `mcp_bot_start` → `zchg_phy_start` → `temple2_main_loop`.

### Key Implementation Details

- **Heap**: 32MB bump allocator in BSS. `temple2_alloc(size)` zero-fills. `temple2_free()` is a no-op (bump heap; Phase 1 has no free).
- **GDT**: 5 entries — null, ring-0 code (0x9A/0xA0), ring-0 data (0x92/0xC0), ring-3 code (0xFA/0xA0), ring-3 data (0xF2/0xC0). Descriptor constant is `0x000000000000FFFF` (limit_lo at bits 15:0 — not at bits 47:32, which would corrupt DPL).
- **SSE**: Enabled in `sse_enable()` before phi_engine. Clears `CR0.EM`, sets `CR0.MP`, sets `CR4.OSFXSR` + `CR4.OSXMMEXCPT`, runs `fninit`. Required because phi/kuramoto use `movss`/XMM.
- **IDT**: 22 exception trampolines (push fake/real error code, push vector, jmp common handler). 16 IRQ stubs (EOI + `iretq`). Common exception handler prints vector, error code, RIP, then halts.
- **PIT**: 100Hz. `1193182 / 100 = 11931 = 0x2EAB`. IRQ0 only unmasked; all others masked. Timer ISR increments `_ticks` with `incq`.
- **Kuramoto**: 8 oscillators. Natural frequencies = `phi^axis_index * prime[axis]`. Initial phases staggered by `0.13 * k`. RK4 step with `dt` from caller. Order parameter R = `|Σ e^{iθ}| / N`. Phase-lock at R > 0.95 → `locked = 0xFF`, `S_U = 1.531`.
- **ERL BST**: FNV-1a 64-bit hash, binary search tree, `temple2_alloc`-backed nodes. Key-value store for the bot's memory layer.

---

## What It Can Do (Phase 1)

- Boot from ISO on any x86-64 machine supporting BIOS/legacy boot or iDRAC8 virtual media
- Boot in QEMU with `-nographic -serial stdio`
- Run the Frontierland serial REPL: `phi`, `ticks`, `uptime`, `halt`, or any HolyC string
- Execute the `phi` command: runs `hdgl_phi_prime_test()` — reports whether the 8 Kuramoto oscillators have phase-locked (`LOCKED(prime)` or `unlocked`)
- Execute the `ticks` command: prints the PIT tick counter (100Hz uptime)
- Execute the `halt` command: `cli; hlt`
- Accept arbitrary input and echo it back via the HolyC exec stub (`[HC] <input>`)
- Store and recall values in the ERL BST via the bot's pass router (bot-internal, not yet wired to REPL directly)
- Run entirely ring-0, no userspace, no syscalls, no libc

---

## What It Cannot Do Yet (Phase 1 → 2 → 3)

| Capability | Status | Phase |
|---|---|---|
| NIC driver (Intel I350 MMIO) | Scaffolded, not connected | 2 |
| zchg:// P2P networking | PHY layer offline | 2 |
| Qwen inference (bot `_pass_respond`) | Stub returns empty | 2 |
| HolyC JIT compiler | REPL echoes, doesn't compile | 2 |
| Frontierland UI (graphical / web) | REPL only | 2 |
| Private "homes" + public map | Not started | 2/3 |
| CHG Coin park function | Not started | 3 |
| Multi-node P2P ISP | Not started | 3 |
| IPFS/ETH/Wayback bootstrap | Not started | 3 |
| Userspace / processes | No scheduler running | 2 |
| Filesystem | None | 2 |
| VGA / framebuffer | Serial only | 2 |
| USB / PS2 input | None | 2 |

---

## PLAN.md Roadmap Position

### Phase 1 — COMPLETE ✓
HDGL-OS boots on an ISO ready for iDRAC8. The YIN/YANG/BOT/PHY stack initializes cleanly. The Frontierland REPL is operational over serial. The phi engine runs. The bot is ring-0 confined and alive. The kernel is self-contained: no Linux, no Alpine, no Python.

### Phase 2 — NEXT
Wire the confined MCP bot to the Frontierland UI. NIC driver → zchg:// networking. HolyC compiler (not just echo). Qwen inference running from the bump heap. Frontierland "homes" — private node-hosted UIs, peer-authorized access. Public Frontierland co-hosted by all network nodes.

### Phase 3 — FUTURE
Fully distributed HDGL ISP. CHG Coin park function powering bandwidth economics. Frontierland real-estate map for the network. IPFS / ETH / Wayback resurrect path for zero-node recovery. Intel Xeon Phi 5110P, M60, M40, MI25 as accelerator targets.

---

## Build

Requirements: `gcc` (cross or native x86-64), `nasm`, `xorriso`, `grub-mkimage` / `grub-pc-bin`.

```sh
cd HDGL-OS
chmod +x build.sh
./build.sh
```

The build script:
1. Assembles `boot/multiboot_entry.asm` with NASM → `multiboot_entry.o`
2. Compiles all `.c` files with `-ffreestanding -fno-stack-protector -mno-red-zone -nostdlib`
3. Links with `boot/linker.ld` → `hdgl-os.elf`
4. Stages an El Torito ISO with GRUB2 i386-pc-eltorito using `grub-mkimage` + `xorriso`
5. Outputs `hdgl-os-final.iso`

The `hdgl/` sources (phi_engine, kuramoto, hdgl_glyph) are compiled **without** `-mno-sse` so the compiler can generate SSE; `sse_enable()` in `temple2_init()` ensures CR4.OSFXSR is set before any XMM instruction executes.

---

## Boot in QEMU

### Linux / WSL2 (verified working)

```sh
qemu-system-x86_64 \
  -machine pc -cpu qemu64,+pae,+lm \
  -bios /usr/share/seabios/bios-256k.bin \
  -m 256M \
  -cdrom hdgl-os-final.iso -boot order=d \
  -nographic -serial stdio \
  -no-reboot -net none
```

Install deps on Debian/Ubuntu:
```sh
sudo apt-get install qemu-system-x86 seabios
```

SeaBIOS path may also be `/usr/share/qemu/bios-256k.bin` depending on distro.

---

### Windows — cmd.exe (recommended)

`-serial stdio` does not work from PowerShell on Windows QEMU due to a
`qemu_add_wait_object` limitation. Use **cmd.exe** instead:

```cmd
"C:\Program Files\qemu\qemu-system-x86_64.exe" -machine pc -cpu qemu64,+pae,+lm -bios "C:\Program Files\qemu\share\bios-256k.bin" -m 256M -cdrom "hdgl-os-final.iso" -boot order=d -nographic -serial stdio -no-reboot -net none
```

If QEMU is not installed: https://www.qemu.org/download/#windows (64-bit installer, default path `C:\Program Files\qemu\`).

---

### Windows — PowerShell, output to file

If cmd.exe serial still doesn't render interactively, redirect to a log and tail it from a second terminal:

**Terminal 1** — boot the ISO:
```powershell
& "C:\Program Files\qemu\qemu-system-x86_64.exe" `
  -machine pc -cpu qemu64,+pae,+lm `
  -bios "C:\Program Files\qemu\share\bios-256k.bin" `
  -m 256M `
  -cdrom "hdgl-os-final.iso" -boot order=d `
  -nographic -serial file:serial.log `
  -no-reboot -net none
```

**Terminal 2** — watch serial output live:
```powershell
Get-Content -Wait .\serial.log
```

> This mode is read-only (no REPL input). For interactive use, WSL2 + the Linux command above is the recommended path on Windows.

---

### WSL2 tip (easiest on Windows)

WSL2 gives you a full Linux environment. With QEMU installed inside WSL2,
the Linux command above works without modification. The ISO is accessible
from WSL2 at its `/mnt/c/...` path.

Expected output (serial):

```
=======================================================
  HDGL-OS / Temple2 Hybrid  v0.1  (Phase 1)
  YIN : TempleOS ring-0 model (HolyC-inspired C)
  YANG: Analog-Prime phi/Kuramoto conscious layer
  BOT : MCP-Jailbreak confined (zero-network cage)
=======================================================
[BOOT] multiboot2 OK
[YIN]  Temple2 ring-0 kernel ready
[YANG] HDGL phi/Kuramoto engine ready (K=3.0, 8 oscillators)
[BOT]  MCP-Jailbreak confined — ring-0 power, zero network
[PHY]  offline (no NIC driver yet) — bot still fully operational
[OS]   entering Frontierland REPL
=======================================================
[HDGL-OS] Frontierland REPL ready. Commands: phi ticks help halt
>
```

---

## Boot on Hardware (iDRAC8)

Target hardware: Dell PowerEdge R430/R530, SuperMicro X9DRW-7TPF.

1. Transfer `hdgl-os-final.iso` to a host accessible by iDRAC8.
2. iDRAC8 → **Virtual Console** → **Virtual Media** → **Map CD/DVD** → browse to `hdgl-os-final.iso`.
3. iDRAC8 → **Power** → **Boot Settings** → set boot order: Virtual CD-ROM first.
4. Power cycle or POST → **F11** boot menu → select iDRAC Virtual CD.
5. GRUB2 loads, boots HDGL-OS. Serial console: iDRAC8 → **Serial Over LAN** or Virtual Console text mode.

The ISO uses El Torito / BIOS legacy boot (i386-pc-eltorito). iDRAC8's virtual media emulates a BIOS optical drive — no UEFI required.

---

## REPL Commands

Once at the `>` prompt (serial):

| Command | What it does |
|---|---|
| `phi` | Runs `hdgl_phi_prime_test()`. Reports if the 8 Kuramoto oscillators are phase-locked (`LOCKED(prime)`) or still converging (`unlocked`). |
| `ticks` | Prints the PIT tick counter (100 ticks/sec = hundredths of seconds since boot). |
| `help` | Lists available commands. |
| `halt` | `cli; hlt` — stops the machine. |
| anything else | Passed to `temple2_exec_hc()`. Returns `[HC] <your input>`. In Phase 2 this becomes a real HolyC compiler call. |

Backspace (`DEL`/`0x7F` or `0x08`) works in the readline loop. Enter submits. Max line 511 bytes.

---

## Source Tree

```
HDGL-OS/
├── boot/
│   ├── multiboot_entry.asm   32→64 boot: mb2 save, PAE tables, EFER, far jump
│   ├── long_mode_init.c      first C in 64-bit: boot sequence orchestrator
│   └── linker.ld             ELF layout (BSS ~33MB, load base 0x100000)
├── kernel/
│   ├── temple2_bridge.c      GDT, IDT, PIC, PIT, SSE, heap, HolyC stub
│   ├── temple2_bridge.h
│   ├── hdgl_types.h          SPIRAL8_AXES, phi-type definitions
│   ├── holyc_syscall.c       HolyC syscall shim stubs
│   └── scheduler.c           cooperative scheduler (Phase 2)
├── hdgl/
│   ├── phi_engine.c          phi init, tick, prime test
│   ├── phi_engine.h          kuramoto_state_t, SPIRAL8_AXES
│   ├── kuramoto.c            8-oscillator RK4 integration, order parameter
│   └── hdgl_glyph.c          glyph encoding (HDGL language layer)
├── bot/
│   ├── mcp_confined.c        Wu-Wei MCP bot, ERL BST, pass routing
│   └── mcp_confined.h
├── conscious/
│   └── zchg_phy.{c,h}        zchg:// PHY, HMAC-SHA256 gossip, I350 scaffold
├── tools/
│   └── ...                   HDGL build/lang tools
├── trivoice/
│   └── ...                   TriVoice audio primitives
├── build.sh                  build + ISO assembly script
├── Makefile
├── BUILD.md                  detailed build notes
└── hdgl-os-final.iso         bootable ISO (El Torito, GRUB2)
```

---

## YIN / YANG Duality

The names come from the PLAN.md design philosophy:

**YIN** (random / deterministic substrate) = Temple2 ring-0. This is the hard, structured, deterministic layer. GDT, IDT, PIT, heap, scheduler — the machine's skeleton. Derived from TempleOS's ring-0 model: no protection rings in use during the kernel's own execution, total hardware access, total freedom, total responsibility.

**YANG** (analog resonance) = Kuramoto phi-engine. This is the continuous, oscillatory, "analog" layer running inside the discrete machine. 8 oscillators with phi-ratio-weighted frequencies, RK4 integration, order parameter tracking. When R > 0.95, the system is phase-locked — a computationally detectable analog of coherence. This is HDGL's "analog-over-digital" thesis made executable.

The two layers are not metaphor — they are both running code. YIN provides the substrate. YANG runs on top of it, using the same heap, the same interrupt timer, the same ring-0 privilege.

---

## Constraints

Per PLAN.md (non-negotiable):

- **No Python. Ever.**
- **Only repo source files** — C, HolyC, HDGL languages, b4096, DNA/spiral encoding, HDGL JSON.
- HDGL Languages spec: zchg.org phi-based vector language posts.
- HDGL JSON: HDGL-SQL-0.2 in repo.
- All numeric/encoding work via spiral8plus, base4096, Analog-Prime primitives.

---

## Hardware Targets

- SuperMicro X9DRW-7TPF — Dual Xeon LGA2011, 2× E5-2650V2, iDRAC8
- Dell PowerEdge R430 / R530 — DDR4, iDRAC8
- X99HC Dell PowerEdge iDRAC8 Remote Port Card
- Intel Xeon Phi 5110P — Phase 3 accelerator target
- Nvidia M60, M40, AMD MI25 — Phase 3 accelerator targets

---

## Related

- HDGL Kernel / Prismatic Computer: https://josefkulovany.com/demo/9.24.25-%20kernel/really%20works/
- P2P ISP (CAJI): https://zchg.org/t/caji-0-10-lets-begin/755
- HDGL Languages: https://zchg.org/t/an-elegant-phi-based-language/860
- Analog-Prime: https://zchg.org/t/mafia8-analog-prismatic-engine-scripts-hdgl/858
- CHG Coin: https://etherscan.io/token/0xc4a86561cb0b7ea1214904f26e6d50fd357c7986#code

---

*HDGL-OS v0.1 — Phase 1 complete. Ring-0, no libc, no Python, no compromise.*
