# make_shortcut.ps1
# Run this once from PowerShell to create the HDGL-OS boot shortcut on your Desktop.
# The shortcut launches cmd.exe (not PowerShell) which is required for QEMU -serial stdio.

$QemuExe  = "C:\Program Files\qemu\qemu-system-x86_64.exe"
$QemuBios = "C:\Program Files\qemu\share\bios-256k.bin"
$Iso      = "C:\Users\Owner\Documents\Josef's Code 2026\HDGL P2P Internet\HDGL-OS\hdgl-os-final.iso"
$WorkDir  = "C:\Users\Owner\Documents\Josef's Code 2026\HDGL P2P Internet\HDGL-OS"
$LinkPath = "$env:USERPROFILE\Desktop\HDGL-OS Frontierland REPL.lnk"

# Verify QEMU exists before creating the shortcut
if (-not (Test-Path $QemuExe)) {
    Write-Error "QEMU not found at: $QemuExe`nInstall from https://www.qemu.org/download/#windows"
    exit 1
}
if (-not (Test-Path $Iso)) {
    Write-Error "ISO not found at: $Iso`nRun build.sh first to produce hdgl-os-final.iso"
    exit 1
}

# Build the cmd.exe argument string.
# /k keeps the window open after QEMU exits so you can read the last serial output.
# Outer quotes wrap the whole command; inner double-quotes escape the exe path.
$QemuArgs = "-machine pc -cpu qemu64,+pae,+lm " +
            "-bios `"$QemuBios`" " +
            "-m 256M " +
            "-cdrom `"$Iso`" -boot order=d " +
            "-nographic -serial stdio " +
            "-no-reboot -net none"

$CmdArgs = "/k `"`"$QemuExe`" $QemuArgs`""

# Create the .lnk via WScript.Shell COM object
$WS  = New-Object -ComObject WScript.Shell
$Lnk = $WS.CreateShortcut($LinkPath)
$Lnk.TargetPath       = "C:\Windows\System32\cmd.exe"
$Lnk.Arguments        = $CmdArgs
$Lnk.WorkingDirectory = $WorkDir
$Lnk.Description      = "Boot HDGL-OS Frontierland REPL in QEMU (YIN/YANG/BOT stack)"
$Lnk.IconLocation     = "$QemuExe,0"
$Lnk.Save()

Write-Host "Shortcut created: $LinkPath" -ForegroundColor Green
Write-Host "Double-click it to boot HDGL-OS." -ForegroundColor Cyan
