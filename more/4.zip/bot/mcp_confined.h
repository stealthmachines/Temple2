/* mcp_confined.h — confined MCP bot API */
#pragma once
#ifndef MCP_CONFINED_H
#define MCP_CONFINED_H

#include <stdint.h>
#include "../kernel/hdgl_types.h"

typedef enum {
    MCP_PASS_FETCH=0, MCP_PASS_SHELL=1, MCP_PASS_CODE=2,
    MCP_PASS_TRANSFORM=3, MCP_PASS_STORE=4, MCP_PASS_RECALL=5,
    MCP_PASS_BROWSE=6, MCP_PASS_NOTIFY=7, MCP_PASS_RESPOND=8,
} mcp_pass_type_t;

typedef struct {
    char     cwd[256];
    char     last_stdout[4096];
    char     last_path[256];
    char     last_url[512];
    uint32_t pass_count;
    char     pass_log[32][256];
    uint64_t erl_ledger_ptr;
} mcp_flow_state_t;

int mcp_bot_start(void);
int mcp_unfold(mcp_pass_type_t type, const char *input, char *output, uint32_t olen);
int mcp_infer_qwen(const char *prompt, char *result, uint32_t rlen);

extern mcp_flow_state_t g_flow;

#endif
