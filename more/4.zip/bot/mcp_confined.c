/*
 * mcp_confined.c — Wu-Wei MCP bot, ring-0 confined.
 *
 * Inference via COM1 UART serial bridge to host ZCHG daemon.
 * Protocol: STX (0x02) + text + ETX (0x03), framed in both directions.
 * QEMU launch: -serial tcp:127.0.0.1:9001
 * Host daemon: LN_SERIAL_PORT=9001 zchg_daemon  (listens, phi-routes to Ollama)
 *
 * Hotswap: change LN_OLLAMA_MODEL on the host between requests — zero reboot.
 */

#include "mcp_confined.h"
#include "../kernel/temple2_bridge.h"
#include "../kernel/hdgl_types.h"

mcp_flow_state_t g_flow;

/* ---- COM1 UART (8250) ring-0 port I/O ------------------------------------ */
#define COM1_BASE  0x2F8U  /* COM2 — LLM bridge; COM1 reserved for user REPL */

static inline void _com_outb(uint16_t p, uint8_t v) {
    __asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p));
}
static inline uint8_t _com_inb(uint16_t p) {
    uint8_t v;
    __asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p));
    return v;
}

static int _uart_ok = 0;

static void uart_init(void) {
    _com_outb(COM1_BASE + 1, 0x00); /* Disable all interrupts */
    _com_outb(COM1_BASE + 3, 0x80); /* Enable DLAB (set baud rate divisor) */
    _com_outb(COM1_BASE + 0, 0x01); /* Divisor lo: 115200 baud */
    _com_outb(COM1_BASE + 1, 0x00); /* Divisor hi */
    _com_outb(COM1_BASE + 3, 0x03); /* 8 bits, no parity, one stop */
    _com_outb(COM1_BASE + 2, 0xC7); /* Enable FIFO, clear, 14-byte threshold */
    _com_outb(COM1_BASE + 4, 0x0B); /* IRQs enabled, RTS/DSR set */
    _uart_ok = 1;
}

/* Transmit one byte (blocks until THR empty — ring-0 safe spin). */
static void uart_putc(uint8_t c) {
    while (!(_com_inb(COM1_BASE + 5) & 0x20));
    _com_outb(COM1_BASE, c);
}

/* Receive one byte with loop-count timeout. Returns 0 on success, -1 on timeout. */
static int uart_getc(uint8_t *out, uint64_t loops) {
    for (uint64_t i = 0; i < loops; i++) {
        if (_com_inb(COM1_BASE + 5) & 0x01) {
            *out = _com_inb(COM1_BASE);
            return 0;
        }
    }
    return -1; /* timeout */
}

/*
 * Approximate loop count for N seconds of spin at ~500 MIPS (QEMU estimate).
 * uart_getc inner loop ≈ 3 instructions → ~167M iterations/second.
 * Tune LN_UART_TIMEOUT_SECS (default 120) if response is slow or timeout fires.
 */
#define UART_LOOPS_PER_SEC  167000000ULL
#define UART_TIMEOUT_LOOPS  (UART_LOOPS_PER_SEC * 120ULL)   /* ~120 s */

/* ---- ERL V3 BST ---------------------------------------------------------- */
typedef struct ErlNode { uint64_t h; char *v; struct ErlNode *l,*r; } ErlNode;
static ErlNode *_erl_root = NULL;

static uint64_t _fnv(const char *s) {
    uint64_t h = 14695981039346656037ULL;
    while (*s) { h ^= (uint8_t)*s++; h *= 1099511628211ULL; }
    return h;
}

static void erl_set(const char *key, const char *val) {
    uint64_t h = _fnv(key);
    ErlNode *n = (ErlNode*)temple2_alloc(sizeof(ErlNode));
    if (!n) return;
    n->h = h; n->l = n->r = NULL;
    uint32_t vlen = 0; while (val[vlen]) vlen++;
    n->v = (char*)temple2_alloc(vlen + 1);
    if (n->v) { for (uint32_t i=0;i<=vlen;i++) n->v[i]=val[i]; }
    if (!_erl_root) { _erl_root = n; return; }
    ErlNode *cur = _erl_root;
    for (;;) {
        if      (h < cur->h) { if (!cur->l) { cur->l=n; return; } cur=cur->l; }
        else if (h > cur->h) { if (!cur->r) { cur->r=n; return; } cur=cur->r; }
        else { cur->v = n->v; return; }
    }
}

static const char *erl_get(const char *key) {
    uint64_t h = _fnv(key); ErlNode *c = _erl_root;
    while (c) {
        if (h==c->h) return c->v;
        c = (h < c->h) ? c->l : c->r;
    }
    return NULL;
}

/* ---- Pass routing -------------------------------------------------------- */
static int _pass_code(const char *in, char *out, uint32_t ol) {
    return temple2_exec_hc(in, out, ol);
}

static int _pass_store(const char *in, char *out, uint32_t ol) {
    const char *eq = in;
    while (*eq && *eq != '=') eq++;
    if (*eq == '=') {
        uint32_t klen = (uint32_t)(eq - in);
        char *key = (char*)temple2_alloc(klen+1);
        if (key) { for(uint32_t i=0;i<klen;i++) key[i]=in[i]; key[klen]='\0'; }
        erl_set(key ? key : in, eq+1);
    }
    if (out && ol>0) out[0]='\0';
    return 0;
}

static int _pass_recall(const char *in, char *out, uint32_t ol) {
    const char *v = erl_get(in);
    if (v && out && ol>0) {
        uint32_t i=0; while(v[i]&&i<ol-1) { out[i]=v[i]; i++; } out[i]='\0';
        return 0;
    }
    if (out && ol>0) out[0]='\0';
    return -1;
}

static int _pass_respond(const char *in, char *out, uint32_t ol) {
    return mcp_infer_qwen(in, out, ol);
}

/* ---- Public API ---------------------------------------------------------- */

int mcp_bot_start(void) {
    uint8_t *p = (uint8_t*)&g_flow;
    for (uint32_t i=0;i<sizeof(g_flow);i++) p[i]=0;
    g_flow.cwd[0]='/'; g_flow.cwd[1]='\0';
    g_flow.erl_ledger_ptr = (uint64_t)(uintptr_t)_erl_root;
    return 0;
}

int mcp_unfold(mcp_pass_type_t type, const char *in, char *out, uint32_t ol) {
    if (g_flow.pass_count < 32) {
        char *lg = g_flow.pass_log[g_flow.pass_count];
        const char *tn[] = {"FETCH","SHELL","CODE","TRANSFORM","STORE",
                            "RECALL","BROWSE","NOTIFY","RESPOND"};
        const char *t = (type < 9) ? tn[type] : "?";
        uint32_t i=0; while(t[i]&&i<255) { lg[i]=t[i]; i++; } lg[i]='\0';
    }
    g_flow.pass_count++;

    switch(type) {
        case MCP_PASS_CODE:    return _pass_code(in, out, ol);
        case MCP_PASS_STORE:   return _pass_store(in, out, ol);
        case MCP_PASS_RECALL:  return _pass_recall(in, out, ol);
        case MCP_PASS_RESPOND: return _pass_respond(in, out, ol);
        default:
            if (out && ol>0) out[0]='\0';
            return 0;
    }
}

/*
 * mcp_infer_qwen — COM1 UART serial bridge to host ZCHG daemon.
 *
 * Request frame:  STX (0x02) + prompt bytes + ETX (0x03)
 * Response frame: STX (0x02) + response bytes + ETX (0x03)
 *
 * The host ZCHG daemon (started with LN_SERIAL_PORT=9001) listens on TCP 9001.
 * QEMU routes COM1 to that port via: -serial tcp:127.0.0.1:9001
 *
 * Hotswap: the daemon's model selection is runtime-configurable on the host.
 * No kernel reboot required to change models — just update LN_OLLAMA_MODEL
 * and restart the daemon process. The next inference call uses the new model.
 */
int mcp_infer_qwen(const char *prompt, char *result, uint32_t rlen) {
    if (!_uart_ok) uart_init();

    if (!result || rlen == 0) return -1;
    result[0] = '\0';

    /* ── Send: STX + prompt + ETX ─────────────────────────────────────── */
    uart_putc(0x02);  /* STX */
    for (const char *p = prompt; *p; p++) uart_putc((uint8_t)*p);
    uart_putc(0x03);  /* ETX */

    /* ── Receive: wait for STX ────────────────────────────────────────── */
    uint8_t c;
    /* Drain any stale bytes before STX */
    for (;;) {
        if (uart_getc(&c, UART_TIMEOUT_LOOPS) != 0) {
            /* Timeout waiting for response */
            const char *err = "[ZCHG-UART: timeout waiting for STX]";
            uint32_t i=0; while(err[i]&&i<rlen-1){result[i]=(char)err[i];i++;}
            result[i] = '\0';
            return -1;
        }
        if (c == 0x02) break;  /* Got STX */
    }

    /* ── Receive: read until ETX ──────────────────────────────────────── */
    uint32_t i = 0;
    while (i < rlen - 1) {
        if (uart_getc(&c, UART_TIMEOUT_LOOPS) != 0) break;  /* timeout mid-response */
        if (c == 0x03) break;  /* ETX = end of response */
        result[i++] = (char)c;
    }
    result[i] = '\0';
    return (i > 0) ? 0 : -1;
}