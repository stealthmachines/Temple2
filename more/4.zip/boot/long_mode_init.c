/*
 * long_mode_init.c — first C code in 64-bit long mode.
 * Boot sequence: GDT/IDT → phi engine → confined bot → conscious PHY → REPL
 */

#include <stdint.h>
#include "../kernel/hdgl_types.h"
#include "../kernel/temple2_bridge.h"
#include "../hdgl/phi_engine.h"
#include "../bot/mcp_confined.h"
#include "../conscious/zchg_phy.h"

#define MB2_MAGIC_EXPECTED 0x36d76289U

static void serial_init(void) {
    __asm__ volatile("outb %0,%1"::"a"((uint8_t)0x00),"Nd"((uint16_t)0x3F9));
    __asm__ volatile("outb %0,%1"::"a"((uint8_t)0x80),"Nd"((uint16_t)0x3FB));
    __asm__ volatile("outb %0,%1"::"a"((uint8_t)0x01),"Nd"((uint16_t)0x3F8));
    __asm__ volatile("outb %0,%1"::"a"((uint8_t)0x00),"Nd"((uint16_t)0x3F9));
    __asm__ volatile("outb %0,%1"::"a"((uint8_t)0x03),"Nd"((uint16_t)0x3FB));
    __asm__ volatile("outb %0,%1"::"a"((uint8_t)0xC7),"Nd"((uint16_t)0x3FA));
    __asm__ volatile("outb %0,%1"::"a"((uint8_t)0x0B),"Nd"((uint16_t)0x3FC));
}

static void __attribute__((noreturn)) kpanic(const char *msg) {
    kprint("\n[PANIC] "); kprint(msg); kprint("\n");
    for(;;) __asm__ volatile("cli;hlt");
}

void long_mode_start(uint64_t mb2_magic, uint64_t mb2_info) {
    serial_init();
    kprint("\n");
    kprint("=======================================================\n");
    kprint("  HDGL-OS / Temple2 Hybrid  v0.1  (Phase 1)\n");
    kprint("  YIN : TempleOS ring-0 model (HolyC-inspired C)\n");
    kprint("  YANG: Analog-Prime phi/Kuramoto conscious layer\n");
    kprint("  BOT : MCP-Jailbreak confined (zero-network cage)\n");
    kprint("=======================================================\n");

    if (mb2_magic != (uint64_t)MB2_MAGIC_EXPECTED)
        kpanic("bad multiboot2 magic — load via GRUB2");
    kprint("[BOOT] multiboot2 OK\n");

    /* 1. Temple2 ring-0 kernel (GDT, IDT, PIT, heap) */
    if (temple2_init(mb2_info) != 0) kpanic("temple2_init failed");
    kprint("[YIN]  Temple2 ring-0 kernel ready\n");

    /* 2. HDGL phi engine (8D Kuramoto, phi-lang tokens) */
    if (hdgl_phi_init() != 0) kpanic("hdgl_phi_init failed");
    kprint("[YANG] HDGL phi/Kuramoto engine ready (K=3.0, 8 oscillators)\n");

    /* 3. Confined MCP bot (zero-network, ring-0 Wu-Wei) */
    if (mcp_bot_start() != 0) kpanic("mcp_bot_start failed");
    kprint("[BOT]  MCP-Jailbreak confined — ring-0 power, zero network\n");

    /* 4. Conscious PHY (non-fatal — runs offline if no NIC) */
    if (zchg_phy_start() == 0)
        kprint("[PHY]  zchg:// conscious networking active\n");
    else
        kprint("[PHY]  offline (no NIC driver yet) — bot still fully operational\n");

    /* 5. HDGL OS main loop */
    kprint("[OS]   entering Frontierland REPL\n");
    kprint("=======================================================\n");
    temple2_main_loop();
    kpanic("main loop returned");
}
