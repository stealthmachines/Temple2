; =============================================================================
; HDGL-OS multiboot_entry.asm -- Multiboot2 + 32-bit to 64-bit long mode
; Loaded by GRUB2. Jumps to long_mode_start (long_mode_init.c).
;
; Key fixes applied:
;  - mb2 magic/info saved BEFORE any serial_probe (probe clobbers AL)
;  - 32 x 2 MB PAE huge pages (64 MB) to cover 33 MB BSS
;  - CR4 save/restore pattern so probe doesn't corrupt PAE enable value
; =============================================================================

BITS 32
section .multiboot2
align 8

MB2_MAGIC       equ 0xE85250D6
MB2_ARCH        equ 0
MB2_HEADER_LEN  equ (mb2_header_end - mb2_header_start)
MB2_CHECKSUM    equ -(MB2_MAGIC + MB2_ARCH + MB2_HEADER_LEN)

mb2_header_start:
    dd  MB2_MAGIC
    dd  MB2_ARCH
    dd  MB2_HEADER_LEN
    dd  MB2_CHECKSUM & 0xFFFFFFFF
    dw  0   ; terminating tag type
    dw  0   ; flags
    dd  8   ; size
mb2_header_end:

; ---- GDT for 64-bit long mode -----------------------------------------------
section .data
align 8
gdt64:
    dq 0
.code: equ $ - gdt64
    dq (1<<43)|(1<<44)|(1<<47)|(1<<53)
.data: equ $ - gdt64
    dq (1<<44)|(1<<47)|(1<<41)
gdt64_ptr:
    dw $ - gdt64 - 1
    dq gdt64

; Saved mb2 registers -- written in 32-bit, read back in 64-bit.
align 4
mb2_magic_save: dd 0
mb2_info_save:  dd 0
cr4_save:       dd 0

; ---- Page tables: 32 x 2 MB PAE huge pages = 64 MB identity map -----------
section .bss
align 4096
pml4:   resb 4096
pdpt:   resb 4096
pd:     resb 4096

; ---- Stack (16 KB) -----------------------------------------------------------
stack_bottom:   resb 16384
stack_top:

; ---- Entry point (32-bit) ---------------------------------------------------
section .text
global _start
extern long_mode_start

_start:
    ; Save mb2 magic (EAX) and info ptr (EBX) before anything touches AL.
    mov [mb2_magic_save], eax
    mov [mb2_info_save],  ebx
    cli
    mov esp, stack_top

    ; PML4[0] -> PDPT
    mov eax, pdpt
    or  eax, 0x3
    mov [pml4], eax

    ; PDPT[0] -> PD
    mov eax, pd
    or  eax, 0x3
    mov [pdpt], eax

    ; PD[0..31] -> 2 MB huge pages (64 MB identity map)
    mov ecx, 32
    mov eax, 0x83           ; phys 0x0 | present+writable+huge
    mov edx, pd
.pd_fill:
    mov dword [edx],   eax
    mov dword [edx+4], 0
    add eax, 0x200000
    add edx, 8
    loop .pd_fill

    ; Load CR3
    mov eax, pml4
    mov cr3, eax

    ; Enable PAE (CR4 bit 5)
    mov eax, cr4
    or  eax, (1 << 5)
    mov cr4, eax

    ; Enable long mode (EFER.LME)
    mov ecx, 0xC0000080
    rdmsr
    or  eax, (1 << 8)
    wrmsr

    ; Enable paging + protected mode
    mov eax, cr0
    or  eax, (1 << 31) | 1
    mov cr0, eax

    lgdt [gdt64_ptr]
    jmp gdt64.code:long_mode_entry

BITS 64
long_mode_entry:
    mov ax, gdt64.data
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    ; Pass saved mb2 registers as 64-bit args (zero-extended from 32-bit saves)
    mov edi, [mb2_magic_save]   ; rdi = mb2_magic (arg1)
    mov esi, [mb2_info_save]    ; rsi = mb2_info_ptr (arg2)
    and rsp, ~15
    call long_mode_start

.halt:
    hlt
    jmp .halt
