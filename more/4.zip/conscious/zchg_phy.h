/* zchg_phy.h — conscious networking sub-layer (YANG PHY) */
#pragma once
#ifndef ZCHG_PHY_H
#define ZCHG_PHY_H

#include "../kernel/hdgl_types.h"

/* RX buffer size exposed for nic_recv callers */
#define BUF_SZ_EXTERN  2048

typedef struct {
    uint32_t node_id;        /* peer node identifier (from MAC lower 32 bits) */
    float    phi_tau;
    float    strand_weight;  /* Kuramoto S_U of peer */
    uint32_t peer_addr;
    uint16_t port;
    uint8_t  health;         /* 0..255, decays per tick, refreshed on gossip rx */
} zchg_strand_t;

typedef struct __attribute__((packed)) {
    uint32_t node_id;
    uint32_t seq;
    uint32_t cluster_hash;
    uint16_t strand_count;
    uint16_t flags;
} zchg_gossip_msg_t;

#define ZCHG_FLAG_RESURRECTION_ETH  (1<<0)
#define ZCHG_FLAG_RESURRECTION_IPFS (1<<1)
#define ZCHG_FLAG_RESURRECTION_WB   (1<<2)

int  zchg_phy_start(void);
void zchg_phy_tick(void);
int  zchg_phi_route(const uint8_t *frame, uint32_t len);
void zchg_resurrection_probe(void);
void zchg_set_cluster_secret(const uint8_t *s, uint32_t len);

#endif
