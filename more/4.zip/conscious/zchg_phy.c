/*
 * zchg_phy.c
 * Analog-Prime conscious networking sub-layer — ring-0 stub.
 *
 * === COPILOT FILL ZONE ===
 * Port the key routines from NGINX-HDGL-0.6-c into ring-0 C:
 *   zchg_lattice.c  → strand routing, phi-tau, provisioner
 *   zchg_gossip.c   → 16-byte binary gossip
 *   zchg_frame.c    → frame serialization + HMAC-SHA256
 *   zchg_transport.c → peer transport (raw Ethernet in ring-0)
 *
 * Network interface: raw Ethernet frames via direct NIC MMIO.
 * No TCP/IP stack — the zchg:// protocol runs directly on L2.
 * This keeps the networking layer orthogonal to the MCP bot.
 */

#include "zchg_phy.h"
#include "sha256.h"
#include "nic_i350.h"
#include "../hdgl/phi_engine.h"

#define MAX_STRANDS     64
#define GOSSIP_INTERVAL 30      /* seconds */
#define PHI             1.6180339887498948482f

static zchg_strand_t strands[MAX_STRANDS];
static int strand_count = 0;
static uint32_t my_node_id = 0;
static uint32_t gossip_seq = 0;
static int resurrection_mode = 0;

/* ---- Phi-tau routing --------------------------------------------------- */
/*
 * phi-tau: each strand k has weight w[k] = phi^(-k) normalized.
 * Route to strand with highest (weight * health * (1 - load)).
 * From zchg_lattice.c phi_tau_route() logic.
 */
static int phi_tau_select(void) {
    int best = -1;
    float best_score = -1.0f;
    float phi_inv = 1.0f / PHI;
    float phi_k = 1.0f;

    for (int k = 0; k < strand_count; k++) {
        if (strands[k].health == 0) { phi_k *= phi_inv; continue; }
        float score = phi_k
                    * (float)strands[k].health
                    * (1.0f - strands[k].strand_weight);
        if (score > best_score) { best_score = score; best = k; }
        phi_k *= phi_inv;
    }
    return best;
}

/* ---- Cluster secret (set at boot from multiboot2 cmdline or default) ------ */
static uint8_t _cluster_secret[32] = {
    /* Default dev secret — replace at deploy via zchg_set_cluster_secret() */
    0x48,0x44,0x47,0x4c,0x2d,0x4f,0x53,0x5f,  /* HDGL-OS_ */
    0x70,0x68,0x69,0x5f,0x73,0x65,0x63,0x72,  /* phi_secr */
    0x65,0x74,0x5f,0x76,0x31,0x2e,0x30,0x2e,  /* et_v1.0. */
    0x30,0x00,0x00,0x00,0x00,0x00,0x00,0x00   /* 0....... */
};

void zchg_set_cluster_secret(const uint8_t *s, uint32_t len) {
    uint32_t i;
    for (i = 0; i < 32; i++) _cluster_secret[i] = 0;
    for (i = 0; i < len && i < 32; i++) _cluster_secret[i] = s[i];
}

/* ---- Frame serialization + HMAC-SHA256 ----------------------------------- */
/*
 * zchg frame layout (authenticated):
 *   [0..1]   magic    0x5A43 ('ZC')
 *   [2]      version  0x01
 *   [3]      flags
 *   [4..7]   node_id  (LE32)
 *   [8..11]  seq      (LE32)
 *   [12..N]  payload
 *   [N..N+31] HMAC-SHA256(frame[0..N], cluster_secret)
 */
#define ZCHG_FRAME_MAX  1024
#define ZCHG_FRAME_HDR  12
#define ZCHG_MAGIC      0x5A43U

typedef struct __attribute__((packed)) {
    uint16_t magic;
    uint8_t  version;
    uint8_t  flags;
    uint32_t node_id;
    uint32_t seq;
} zchg_frame_hdr_t;

static uint32_t _frame_seq = 0;

static uint32_t zchg_frame_build(uint8_t *buf, uint32_t bufsz,
                                  const uint8_t *payload, uint32_t plen,
                                  uint8_t flags)
{
    if (plen + ZCHG_FRAME_HDR + 32 > bufsz) return 0;
    zchg_frame_hdr_t *hdr = (zchg_frame_hdr_t *)buf;
    hdr->magic   = ZCHG_MAGIC;
    hdr->version = 0x01;
    hdr->flags   = flags;
    hdr->node_id = my_node_id;
    hdr->seq     = _frame_seq++;
    uint32_t i;
    for (i = 0; i < plen; i++) buf[ZCHG_FRAME_HDR + i] = payload[i];
    uint32_t frame_len = ZCHG_FRAME_HDR + plen;
    /* Append HMAC-SHA256 */
    hmac_sha256(_cluster_secret, 32, buf, frame_len, buf + frame_len);
    return frame_len + 32;
}

static int zchg_frame_verify(const uint8_t *buf, uint32_t len) {
    if (len < ZCHG_FRAME_HDR + 32) return 0;
    const zchg_frame_hdr_t *hdr = (const zchg_frame_hdr_t *)buf;
    if (hdr->magic != ZCHG_MAGIC) return 0;
    uint32_t frame_len = len - 32;
    uint8_t expected[32];
    hmac_sha256(_cluster_secret, 32, buf, frame_len, expected);
    /* Constant-time compare */
    uint8_t diff = 0;
    for (int i = 0; i < 32; i++) diff |= buf[frame_len + i] ^ expected[i];
    return diff == 0;
}

/* ---- Ethernet frame helpers ----------------------------------------------- */
/*
 * Build raw Ethernet frame:
 *   [0..5]   dst MAC
 *   [6..11]  src MAC  (our NIC MAC)
 *   [12..13] EtherType 0x88B5 (IEEE 802.3 local experimental — zchg://)
 *   [14..N]  zchg authenticated payload (zchg_frame_build output)
 */
#define ZCHG_ETHERTYPE 0x88B5U

static uint32_t _eth_build(uint8_t *eth_buf, uint32_t eth_bufsz,
                            const uint8_t *dst_mac,
                            const uint8_t *payload, uint32_t plen,
                            uint8_t flags)
{
    if (14 + plen + ZCHG_FRAME_HDR + 32 > eth_bufsz) return 0;
    const nic_info_t *ni = nic_get_info();

    /* Ethernet header */
    for (int i=0;i<6;i++) eth_buf[i]   = dst_mac[i];
    for (int i=0;i<6;i++) eth_buf[6+i] = ni->mac[i];
    eth_buf[12] = (uint8_t)(ZCHG_ETHERTYPE >> 8);
    eth_buf[13] = (uint8_t)(ZCHG_ETHERTYPE);

    /* Authenticated zchg frame in payload area */
    uint32_t flen = zchg_frame_build(eth_buf + 14, eth_bufsz - 14,
                                     payload, plen, flags);
    if (flen == 0) return 0;
    return 14 + flen;
}

/* ---- Gossip ------------------------------------------------------------ */

static void gossip_send(void) {
    zchg_gossip_msg_t msg;
    msg.node_id      = my_node_id;
    msg.seq          = gossip_seq++;
    msg.cluster_hash = (uint32_t)(g_kuramoto.S_U * 1000.0f);
    msg.strand_count = (uint16_t)strand_count;
    msg.flags        = resurrection_mode ? ZCHG_FLAG_RESURRECTION_ETH : 0;

    /* Build and transmit raw Ethernet frame to zchg multicast group */
    uint8_t eth_buf[256];
    uint8_t flags = resurrection_mode ? ZCHG_FLAG_RESURRECTION_ETH : 0;
    uint32_t total = _eth_build(eth_buf, sizeof(eth_buf),
                                ZCHG_MCAST_MAC,
                                (const uint8_t *)&msg, sizeof(msg),
                                flags);
    if (total > 0)
        nic_send(eth_buf, total);
}

/* ---- Resurrection ------------------------------------------------------- */

void zchg_resurrection_probe(void) {
    /*
     * Called when strand_count drops to 0 (no surviving nodes).
     * Priority order: ETH bootstrap → IPFS → Wayback Machine
     *
     * ETH: query CHG Coin contract 0xc4a86561cb0b7ea1214904f26e6d50fd357c7986
     *      park() function events on mainnet to recover node addresses.
     *      Requires an Ethereum light client or JSON-RPC endpoint.
     *
     * IPFS: resolve CID of hdgl_vectors.json + hdgl_lattice.hdgl
     *       from the pinned network state. Bootstrap via known IPFS peers.
     *
     * Wayback: fetch https://web.archive.org/ (wayback zchg.org)
     *          to recover last-known node list.
     *
     * COPILOT: implement the ETH light client query (EIP-1186 eth_getProof
     * or simplified: raw JSON-RPC eth_call to park() ABI).
     */
    resurrection_mode = 1;
    gossip_seq = 0;
    /* Trigger gossip with resurrection flag set */
    gossip_send();
}

/* ---- Public API -------------------------------------------------------- */

int zchg_phy_start(void) {
    strand_count = 0;
    gossip_seq   = 0;
    resurrection_mode = 0;

    /* Probe Intel I350/X540 NIC via PCI config space + BAR0 MMIO */
    int rc = nic_init();
    if (rc != 0) {
        /* Non-fatal: OS runs in bot-only mode until NIC comes up */
        return -1;
    }

    /* Derive node_id from lower 32 bits of MAC */
    const nic_info_t *ni = nic_get_info();
    my_node_id = (uint32_t)ni->mac[2]<<24 | (uint32_t)ni->mac[3]<<16
               | (uint32_t)ni->mac[4]<<8  | (uint32_t)ni->mac[5];

    /* Announce ourselves on zchg multicast */
    gossip_send();
    return 0;
}

/* ---- Incoming frame handler ---------------------------------------------- */
static void _process_rx(const uint8_t *eth, uint32_t len) {
    if (len < 14 + ZCHG_FRAME_HDR + 32) return;
    /* Check EtherType */
    uint16_t et = ((uint16_t)eth[12] << 8) | eth[13];
    if (et != ZCHG_ETHERTYPE) return;
    const uint8_t *payload = eth + 14;
    uint32_t plen = len - 14;
    if (!zchg_frame_verify(payload, plen)) return;  /* HMAC fail */

    /* Parse gossip message from frame payload (after ZCHG_FRAME_HDR) */
    if (plen < ZCHG_FRAME_HDR + (uint32_t)sizeof(zchg_gossip_msg_t) + 32) return;
    const zchg_gossip_msg_t *g = (const zchg_gossip_msg_t *)(payload + ZCHG_FRAME_HDR);

    /* Update or add strand for this peer */
    for (int i = 0; i < strand_count; i++) {
        if (strands[i].node_id == g->node_id) {
            strands[i].health = 255;
            strands[i].strand_weight = (float)g->cluster_hash / 1000.0f;
            return;
        }
    }
    /* New peer */
    if (strand_count < MAX_STRANDS) {
        strands[strand_count].node_id      = g->node_id;
        strands[strand_count].health       = 255;
        strands[strand_count].strand_weight = (float)g->cluster_hash / 1000.0f;
        strand_count++;
    }
}

void zchg_phy_tick(void) {
    /* Drain RX ring */
    uint8_t rx_buf[BUF_SZ_EXTERN];
    int rlen;
    while ((rlen = nic_recv(rx_buf, sizeof(rx_buf))) > 0)
        _process_rx(rx_buf, (uint32_t)rlen);

    /* Age strand health (decay per tick) */
    for (int i = 0; i < strand_count; i++)
        if (strands[i].health > 0) strands[i].health--;

    /* Advance phi engine */
    hdgl_phi_tick(1.0f / 60.0f);  /* 60Hz tick */

    /* If no healthy strands → probe resurrection */
    int healthy = 0;
    for (int i = 0; i < strand_count; i++)
        if (strands[i].health > 0) healthy++;

    if (strand_count > 0 && healthy == 0)
        zchg_resurrection_probe();
    else
        gossip_send();
}

int zchg_phi_route(const uint8_t *frame, uint32_t len) {
    (void)frame; (void)len;
    return phi_tau_select();
}
