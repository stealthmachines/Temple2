/*
 * phi_router.c
 * Phi-spiral strand router — selects best zchg:// strand per frame.
 * Implements the phi-tau routing algorithm from NGINX-HDGL-0.6-c/zchg_lattice.c.
 *
 * Formula: score[k] = phi^(-k) × health[k] × (1 − load[k])
 * Route to strand with max score; on tie, prefer lower prime index.
 */

#include "zchg_phy.h"
#include "../hdgl/phi_engine.h"
#include "../kernel/hdgl_types.h"

#define PHI_INV  0.6180339887498948482f   /* 1/φ */

/* EMA (exponential moving average) for strand load — α = 0.1 */
void phi_router_update_load(zchg_strand_t *s, float new_sample) {
    s->strand_weight = 0.9f * s->strand_weight + 0.1f * new_sample;
}

/*
 * phi_router_select()
 * Pick best strand from strands[] array of length n.
 * Returns index, or -1 if all dead.
 */
int phi_router_select(const zchg_strand_t *strands, int n) {
    int   best  = -1;
    float bscore = -1.f;
    float phi_k  = 1.f;   /* phi^(-k) — starts at k=0: 1.0 */

    for (int k = 0; k < n; k++) {
        if (strands[k].health == 0) { phi_k *= PHI_INV; continue; }
        float score = phi_k
                    * (float)strands[k].health
                    * (1.f - strands[k].strand_weight);
        if (score > bscore) { bscore = score; best = k; }
        phi_k *= PHI_INV;
    }
    return best;
}

/*
 * phi_router_hash()
 * Deterministic phi-hash of a frame header → strand affinity.
 * Used for consistent routing of streams (same source always → same strand).
 * Maps to NGINX-HDGL-0.6-c zchg_lattice.c phi_tau_hash().
 */
int phi_router_hash(const uint8_t *frame, uint32_t len, int n_strands) {
    if (n_strands <= 0) return -1;
    uint64_t h = 14695981039346656037ULL;
    uint32_t sample = len > 8 ? 8 : len;
    for (uint32_t i = 0; i < sample; i++) { h ^= frame[i]; h *= 1099511628211ULL; }
    /* Map to strand via phi-fractional part */
    float frac = (float)(h & 0xFFFF) / 65536.f;  /* 0.0 – 1.0 */
    float phi_acc = 0.f, phi_k = 1.f;
    for (int k = 0; k < n_strands; k++) {
        phi_acc += phi_k; phi_k *= PHI_INV;
    }
    float target = frac * phi_acc;
    float acc = 0.f; phi_k = 1.f;
    for (int k = 0; k < n_strands; k++) {
        acc += phi_k;
        if (acc >= target) return k;
        phi_k *= PHI_INV;
    }
    return n_strands - 1;
}
