/*
 * sha256.h — freestanding SHA-256 + HMAC-SHA256, pure C99.
 * No libc. No SSE. x87-safe. Ring-0 compatible.
 *
 * Usage:
 *   sha256_ctx ctx;
 *   sha256_init(&ctx);
 *   sha256_update(&ctx, data, len);
 *   sha256_final(&ctx, digest);   // digest[32]
 *
 *   hmac_sha256(key, klen, msg, mlen, mac);  // mac[32]
 */
#ifndef SHA256_H
#define SHA256_H

#include "../kernel/hdgl_types.h"

/* ---- types ---------------------------------------------------------------- */
typedef struct {
    uint32_t state[8];
    uint64_t count;          /* total bits processed */
    uint8_t  buf[64];
    uint32_t buf_len;
} sha256_ctx;

/* ---- SHA-256 round constants (first 32 bits of cbrt of primes 2..311) ---- */
static const uint32_t _K256[64] = {
    0x428a2f98U,0x71374491U,0xb5c0fbcfU,0xe9b5dba5U,
    0x3956c25bU,0x59f111f1U,0x923f82a4U,0xab1c5ed5U,
    0xd807aa98U,0x12835b01U,0x243185beU,0x550c7dc3U,
    0x72be5d74U,0x80deb1feU,0x9bdc06a7U,0xc19bf174U,
    0xe49b69c1U,0xefbe4786U,0x0fc19dc6U,0x240ca1ccU,
    0x2de92c6fU,0x4a7484aaU,0x5cb0a9dcU,0x76f988daU,
    0x983e5152U,0xa831c66dU,0xb00327c8U,0xbf597fc7U,
    0xc6e00bf3U,0xd5a79147U,0x06ca6351U,0x14292967U,
    0x27b70a85U,0x2e1b2138U,0x4d2c6dfcU,0x53380d13U,
    0x650a7354U,0x766a0abbU,0x81c2c92eU,0x92722c85U,
    0xa2bfe8a1U,0xa81a664bU,0xc24b8b70U,0xc76c51a3U,
    0xd192e819U,0xd6990624U,0xf40e3585U,0x106aa070U,
    0x19a4c116U,0x1e376c08U,0x2748774cU,0x34b0bcb5U,
    0x391c0cb3U,0x4ed8aa4aU,0x5b9cca4fU,0x682e6ff3U,
    0x748f82eeU,0x78a5636fU,0x84c87814U,0x8cc70208U,
    0x90befffaU,0xa4506cebU,0xbef9a3f7U,0xc67178f2U
};

/* ---- helpers -------------------------------------------------------------- */
static inline uint32_t _rotr32(uint32_t x, int n){ return (x>>n)|(x<<(32-n)); }
static inline uint32_t _bswap32(uint32_t x){
    return ((x&0xFF)<<24)|((x>>24)&0xFF)|
           (((x>>8)&0xFF)<<16)|(((x>>16)&0xFF)<<8);
}
static inline uint64_t _bswap64(uint64_t x){
    return ((uint64_t)_bswap32((uint32_t)(x>>32))) |
           ((uint64_t)_bswap32((uint32_t)x)<<32);
}

/* ---- SHA-256 block transform --------------------------------------------- */
static void _sha256_transform(uint32_t s[8], const uint8_t blk[64]) {
    uint32_t w[64], a,b,c,d,e,f,g,h,t1,t2;
    int i;
    for (i=0;i<16;i++){
        w[i] = ((uint32_t)blk[i*4]<<24)|((uint32_t)blk[i*4+1]<<16)|
               ((uint32_t)blk[i*4+2]<<8)|(uint32_t)blk[i*4+3];
    }
    for (i=16;i<64;i++){
        uint32_t s0=_rotr32(w[i-15],7)^_rotr32(w[i-15],18)^(w[i-15]>>3);
        uint32_t s1=_rotr32(w[i-2],17)^_rotr32(w[i-2],19)^(w[i-2]>>10);
        w[i]=w[i-16]+s0+w[i-7]+s1;
    }
    a=s[0];b=s[1];c=s[2];d=s[3];e=s[4];f=s[5];g=s[6];h=s[7];
    for (i=0;i<64;i++){
        uint32_t S1=_rotr32(e,6)^_rotr32(e,11)^_rotr32(e,25);
        uint32_t ch=(e&f)^((~e)&g);
        t1=h+S1+ch+_K256[i]+w[i];
        uint32_t S0=_rotr32(a,2)^_rotr32(a,13)^_rotr32(a,22);
        uint32_t maj=(a&b)^(a&c)^(b&c);
        t2=S0+maj;
        h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;
    }
    s[0]+=a;s[1]+=b;s[2]+=c;s[3]+=d;
    s[4]+=e;s[5]+=f;s[6]+=g;s[7]+=h;
}

/* ---- Public SHA-256 API -------------------------------------------------- */
static inline void sha256_init(sha256_ctx *ctx) {
    ctx->state[0]=0x6a09e667U; ctx->state[1]=0xbb67ae85U;
    ctx->state[2]=0x3c6ef372U; ctx->state[3]=0xa54ff53aU;
    ctx->state[4]=0x510e527fU; ctx->state[5]=0x9b05688cU;
    ctx->state[6]=0x1f83d9abU; ctx->state[7]=0x5be0cd19U;
    ctx->count=0; ctx->buf_len=0;
}

static inline void sha256_update(sha256_ctx *ctx, const uint8_t *data, uint32_t len) {
    uint32_t i=0;
    ctx->count += (uint64_t)len*8;
    while (i<len) {
        ctx->buf[ctx->buf_len++]=data[i++];
        if (ctx->buf_len==64){
            _sha256_transform(ctx->state, ctx->buf);
            ctx->buf_len=0;
        }
    }
}

static inline void sha256_final(sha256_ctx *ctx, uint8_t digest[32]) {
    uint64_t bc = ctx->count;
    uint8_t pad = 0x80;
    sha256_update(ctx, &pad, 1);
    pad = 0;
    while (ctx->buf_len != 56) sha256_update(ctx, &pad, 1);
    /* big-endian bit count */
    uint8_t len_be[8];
    for (int i=7;i>=0;i--){ len_be[i]=(uint8_t)(bc&0xFF); bc>>=8; }
    sha256_update(ctx, len_be, 8);
    for (int i=0;i<8;i++){
        digest[i*4]  =(uint8_t)(ctx->state[i]>>24);
        digest[i*4+1]=(uint8_t)(ctx->state[i]>>16);
        digest[i*4+2]=(uint8_t)(ctx->state[i]>>8);
        digest[i*4+3]=(uint8_t)(ctx->state[i]);
    }
}

/* ---- HMAC-SHA256 ---------------------------------------------------------- */
static inline void hmac_sha256(
        const uint8_t *key,  uint32_t klen,
        const uint8_t *msg,  uint32_t mlen,
        uint8_t mac[32])
{
    uint8_t k0[64], ipad[64], opad[64], inner[32];
    sha256_ctx ctx;
    int i;

    /* Step 1: normalize key to 64 bytes */
    for (i=0;i<64;i++) k0[i]=0;
    if (klen>64){
        sha256_init(&ctx);
        sha256_update(&ctx, key, klen);
        sha256_final(&ctx, k0);          /* hash long key → 32 bytes */
    } else {
        for (i=0;i<(int)klen;i++) k0[i]=key[i];
    }

    /* Step 2: inner = SHA256((k0 XOR ipad) || msg) */
    for (i=0;i<64;i++){ ipad[i]=k0[i]^0x36; }
    sha256_init(&ctx);
    sha256_update(&ctx, ipad, 64);
    sha256_update(&ctx, msg,  mlen);
    sha256_final(&ctx, inner);

    /* Step 3: outer = SHA256((k0 XOR opad) || inner) */
    for (i=0;i<64;i++){ opad[i]=k0[i]^0x5c; }
    sha256_init(&ctx);
    sha256_update(&ctx, opad,  64);
    sha256_update(&ctx, inner, 32);
    sha256_final(&ctx, mac);
}

#endif /* SHA256_H */
