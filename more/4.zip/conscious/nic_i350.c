/*
 * nic_i350.c — Intel I350 / X540 raw Ethernet ring-0 driver.
 * Pure C99, freestanding. No stdlib, no TCP/IP.
 *
 * References:
 *   Intel 82580/I350 Software Developer Manual (332552)
 *   Intel X540/X550 Software Developer Manual (333016)
 *
 * Hardware layout assumed:
 *   Dell R430/R530 → I350-AM4 (quad-port GbE) or X540-AT2 (10GbE)
 *   PCI bus 0, device 0x1521 (I350) or 0x1528 (X540)
 *   BAR0 = 128KB MMIO, 64-bit, prefetchable
 *
 * Ring sizes: 16 TX + 16 RX descriptors (fits in 1 page each).
 * Packet buffers: 2048 bytes per descriptor, 16 TX + 16 RX = 64KB total.
 */

#include "nic_i350.h"
#include "../kernel/hdgl_types.h"

/* =========================================================================
 * PCI config space access (legacy CF8/CFC I/O ports)
 * ========================================================================= */
static inline void _outl(uint16_t port, uint32_t val) {
    __asm__ volatile("outl %0, %w1" :: "a"(val), "Nd"(port));
}
static inline uint32_t _inl(uint16_t port) {
    uint32_t v;
    __asm__ volatile("inl %w1, %0" : "=a"(v) : "Nd"(port));
    return v;
}
static inline void _outb(uint16_t port, uint8_t val) {
    __asm__ volatile("outb %0, %w1" :: "a"(val), "Nd"(port));
}
static inline uint8_t _inb(uint16_t port) {
    uint8_t v;
    __asm__ volatile("inb %w1, %0" : "=a"(v) : "Nd"(port));
    return v;
}

#define PCI_ADDR   0xCF8
#define PCI_DATA   0xCFC

static uint32_t pci_read(uint8_t bus, uint8_t dev, uint8_t fn, uint8_t reg) {
    uint32_t addr = 0x80000000U
                  | ((uint32_t)bus << 16)
                  | ((uint32_t)dev << 11)
                  | ((uint32_t)fn  << 8)
                  | (reg & 0xFC);
    _outl(PCI_ADDR, addr);
    return _inl(PCI_DATA);
}
static void pci_write(uint8_t bus, uint8_t dev, uint8_t fn, uint8_t reg, uint32_t val) {
    uint32_t addr = 0x80000000U
                  | ((uint32_t)bus << 16)
                  | ((uint32_t)dev << 11)
                  | ((uint32_t)fn  << 8)
                  | (reg & 0xFC);
    _outl(PCI_ADDR, addr);
    _outl(PCI_DATA, val);
}

/* =========================================================================
 * I350 / X540 MMIO register offsets (from BAR0)
 * ========================================================================= */
#define REG_CTRL        0x00000   /* Device Control */
#define REG_STATUS      0x00008   /* Device Status */
#define REG_CTRL_EXT    0x00018
#define REG_EERD        0x12014   /* EEPROM/Flash Read (I350) */
#define REG_MDIC        0x00020   /* MDI Control */
#define REG_ICR         0x000C0   /* Interrupt Cause Read */
#define REG_IMC         0x000D8   /* Interrupt Mask Clear */
#define REG_RCTL        0x00100   /* RX Control */
#define REG_TCTL        0x00400   /* TX Control */
#define REG_TIPG        0x00410   /* TX Inter-Packet Gap */

/* TX descriptor ring base/len/head/tail — queue 0 */
#define REG_TDBAL       0x03800
#define REG_TDBAH       0x03804
#define REG_TDLEN       0x03808
#define REG_TDH         0x03810
#define REG_TDT         0x03818
#define REG_TXDCTL      0x03828   /* TX Descriptor Control */

/* RX descriptor ring base/len/head/tail — queue 0 */
#define REG_RDBAL       0x02800
#define REG_RDBAH       0x02804
#define REG_RDLEN       0x02808
#define REG_RDH         0x02810
#define REG_RDT         0x02818
#define REG_RXDCTL      0x02828   /* RX Descriptor Control */
#define REG_SRRCTL      0x0280C   /* Split/Replication RX Control */

/* MAC address filters */
#define REG_RAL0        0x05400   /* RX Addr Low [0] */
#define REG_RAH0        0x05404   /* RX Addr High [0] */

/* CTRL bits */
#define CTRL_RST        (1U<<26)  /* Device Reset */
#define CTRL_SLU        (1U<<6)   /* Set Link Up */
#define CTRL_ASDE       (1U<<5)   /* Auto-Speed Detect */
#define CTRL_FD         (1U<<0)   /* Full Duplex */

/* RCTL bits */
#define RCTL_EN         (1U<<1)
#define RCTL_SBP        (1U<<2)
#define RCTL_UPE        (1U<<3)   /* Unicast Promisc */
#define RCTL_MPE        (1U<<4)   /* Multicast Promisc */
#define RCTL_BAM        (1U<<15)  /* Broadcast Accept */
#define RCTL_BSIZE_2K   (0U<<16)  /* Buffer size: 00 = 2048 */
#define RCTL_SECRC      (1U<<26)  /* Strip Ethernet CRC */

/* TCTL bits */
#define TCTL_EN         (1U<<1)
#define TCTL_PSP        (1U<<3)   /* Pad Short Packets */
#define TCTL_CT_SHIFT   4
#define TCTL_COLD_SHIFT 12
#define TCTL_CT_DEFAULT (0xF  << TCTL_CT_SHIFT)
#define TCTL_COLD_FD    (0x40 << TCTL_COLD_SHIFT)

/* TX legacy descriptor done/cmd bits */
#define TDESC_CMD_EOP   (1U<<0)
#define TDESC_CMD_IFCS  (1U<<1)
#define TDESC_CMD_RS    (1U<<3)   /* Report Status */
#define TDESC_STA_DD    (1U<<0)   /* Descriptor Done */

/* RX legacy descriptor done bit */
#define RDESC_STA_DD    (1U<<0)
#define RDESC_STA_EOP   (1U<<1)

/* =========================================================================
 * Descriptor structures (Intel legacy format)
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint64_t addr;      /* buffer physical address */
    uint16_t length;
    uint16_t csum;
    uint8_t  cmd;
    uint8_t  status;
    uint8_t  css;
    uint16_t special;
} tx_desc_t;

typedef struct __attribute__((packed)) {
    uint64_t addr;      /* buffer physical address */
    uint16_t length;
    uint16_t csum;
    uint8_t  status;
    uint8_t  errors;
    uint16_t special;
} rx_desc_t;

/* =========================================================================
 * Ring state (static — one NIC supported)
 * ========================================================================= */
#define TX_RING_SZ  16
#define RX_RING_SZ  16
#define BUF_SZ      2048

/* Aligned static buffers — live in .bss (zero on disk) */
static tx_desc_t __attribute__((aligned(16))) _tx_ring[TX_RING_SZ];
static rx_desc_t __attribute__((aligned(16))) _rx_ring[RX_RING_SZ];
static uint8_t   __attribute__((aligned(16))) _tx_buf[TX_RING_SZ][BUF_SZ];
static uint8_t   __attribute__((aligned(16))) _rx_buf[RX_RING_SZ][BUF_SZ];

static uint32_t _tx_head = 0, _tx_tail = 0;
static uint32_t _rx_tail = 0;

static nic_info_t _nic;

/* =========================================================================
 * MMIO read/write (volatile pointer to physical MMIO)
 * ========================================================================= */
static volatile uint32_t *_bar0 = 0;

static inline uint32_t  mmio_r(uint32_t off) { return _bar0[off/4]; }
static inline void       mmio_w(uint32_t off, uint32_t v) { _bar0[off/4]=v; }

/* Busy-wait delay using PAUSE instruction */
static void _udelay(uint32_t us) {
    /* ~1000 iterations per μs at 1GHz — conservative */
    volatile uint32_t n = us * 1000;
    while (n--) __asm__ volatile("pause");
}

/* =========================================================================
 * PCI device scan
 * ========================================================================= */
#define PCI_VENDID_INTEL  0x8086U
#define PCI_DEVID_I350    0x1521U   /* I350-AM4 */
#define PCI_DEVID_X540    0x1528U   /* X540-AT2 */
#define PCI_DEVID_X550    0x1563U   /* X550-AT2 */

typedef struct { uint8_t bus, dev, fn; uint32_t devid; } pci_loc_t;

static int pci_find_nic(pci_loc_t *loc) {
    for (uint16_t bus = 0; bus < 256; bus++) {
        for (uint8_t dev = 0; dev < 32; dev++) {
            uint32_t id = pci_read((uint8_t)bus, dev, 0, 0x00);
            if ((id & 0xFFFF) != PCI_VENDID_INTEL) continue;
            uint32_t devid = id >> 16;
            if (devid == PCI_DEVID_I350 ||
                devid == PCI_DEVID_X540 ||
                devid == PCI_DEVID_X550) {
                loc->bus   = (uint8_t)bus;
                loc->dev   = dev;
                loc->fn    = 0;
                loc->devid = devid;
                return 1;
            }
        }
    }
    return 0;
}

/* =========================================================================
 * Read MAC from RAL/RAH registers (already loaded from EEPROM by BIOS)
 * ========================================================================= */
static void read_mac(void) {
    uint32_t lo = mmio_r(REG_RAL0);
    uint32_t hi = mmio_r(REG_RAH0);
    _nic.mac[0] = (uint8_t)(lo);
    _nic.mac[1] = (uint8_t)(lo >> 8);
    _nic.mac[2] = (uint8_t)(lo >> 16);
    _nic.mac[3] = (uint8_t)(lo >> 24);
    _nic.mac[4] = (uint8_t)(hi);
    _nic.mac[5] = (uint8_t)(hi >> 8);
}

/* =========================================================================
 * TX/RX ring init
 * ========================================================================= */
static void tx_ring_init(void) {
    uint32_t i;
    for (i = 0; i < TX_RING_SZ; i++) {
        _tx_ring[i].addr   = (uint64_t)(uintptr_t)_tx_buf[i];
        _tx_ring[i].length = 0;
        _tx_ring[i].status = TDESC_STA_DD; /* mark all as done initially */
    }
    uint64_t pa = (uint64_t)(uintptr_t)_tx_ring;
    mmio_w(REG_TDBAL, (uint32_t)(pa & 0xFFFFFFFF));
    mmio_w(REG_TDBAH, (uint32_t)(pa >> 32));
    mmio_w(REG_TDLEN, TX_RING_SZ * sizeof(tx_desc_t));
    mmio_w(REG_TDH, 0);
    mmio_w(REG_TDT, 0);
    _tx_head = _tx_tail = 0;
    /* TXDCTL: enable queue, WTHRESH=1 */
    mmio_w(REG_TXDCTL, (1U<<25) | (1U<<16));
}

static void rx_ring_init(void) {
    uint32_t i;
    for (i = 0; i < RX_RING_SZ; i++) {
        _rx_ring[i].addr   = (uint64_t)(uintptr_t)_rx_buf[i];
        _rx_ring[i].status = 0;
    }
    uint64_t pa = (uint64_t)(uintptr_t)_rx_ring;
    mmio_w(REG_RDBAL, (uint32_t)(pa & 0xFFFFFFFF));
    mmio_w(REG_RDBAH, (uint32_t)(pa >> 32));
    mmio_w(REG_RDLEN, RX_RING_SZ * sizeof(rx_desc_t));
    mmio_w(REG_RDH, 0);
    /* Give all descriptors to hardware */
    mmio_w(REG_RDT, RX_RING_SZ - 1);
    _rx_tail = RX_RING_SZ - 1;
    /* SRRCTL: buffer size 2KB, no header split */
    mmio_w(REG_SRRCTL, 0x02000000U | 2U); /* BSIZEPACKET=2 (2KB) */
    /* RXDCTL: enable queue */
    mmio_w(REG_RXDCTL, (1U<<25));
}

/* =========================================================================
 * nic_init — public entry point
 * ========================================================================= */
int nic_init(void) {
    pci_loc_t loc;
    if (!pci_find_nic(&loc)) return -1;  /* no supported NIC */

    /* Read BAR0 (64-bit) */
    uint32_t bar0_lo = pci_read(loc.bus, loc.dev, loc.fn, 0x10);
    uint32_t bar0_hi = pci_read(loc.bus, loc.dev, loc.fn, 0x14);
    uint64_t bar0 = ((uint64_t)bar0_hi << 32) | (bar0_lo & ~0xFULL);
    if (bar0 == 0) return -2;

    /* Enable PCI Bus Master + Memory Space */
    uint32_t cmd = pci_read(loc.bus, loc.dev, loc.fn, 0x04);
    pci_write(loc.bus, loc.dev, loc.fn, 0x04, cmd | 0x06);

    _bar0 = (volatile uint32_t *)(uintptr_t)bar0;
    _nic.mmio_base = bar0;

    /* Mask all interrupts */
    mmio_w(REG_IMC, 0xFFFFFFFFU);

    /* Global device reset */
    mmio_w(REG_CTRL, mmio_r(REG_CTRL) | CTRL_RST);
    _udelay(1000);
    /* Re-mask after reset */
    mmio_w(REG_IMC, 0xFFFFFFFFU);

    /* Set link up, auto-speed */
    mmio_w(REG_CTRL, CTRL_SLU | CTRL_ASDE);

    /* Wait up to 3 seconds for link */
    uint32_t status = 0;
    for (int t = 0; t < 3000; t++) {
        status = mmio_r(REG_STATUS);
        if (status & (1U<<1)) break;  /* LU = link up */
        _udelay(1000);
    }
    _nic.link_speed = (status & (1U<<1)) ? 1000 : 0;

    read_mac();

    /* Program our MAC into filter 0 */
    uint32_t ral = (uint32_t)_nic.mac[0]
                 | ((uint32_t)_nic.mac[1] << 8)
                 | ((uint32_t)_nic.mac[2] << 16)
                 | ((uint32_t)_nic.mac[3] << 24);
    uint32_t rah = (uint32_t)_nic.mac[4]
                 | ((uint32_t)_nic.mac[5] << 8)
                 | (1U << 31);  /* Address Valid */
    mmio_w(REG_RAL0, ral);
    mmio_w(REG_RAH0, rah);

    tx_ring_init();
    rx_ring_init();

    /* Enable TX: pad short packets, full-duplex */
    mmio_w(REG_TCTL, TCTL_EN | TCTL_PSP | TCTL_CT_DEFAULT | TCTL_COLD_FD);
    /* Standard TIPG for GbE (802.3) */
    mmio_w(REG_TIPG, 0x0060200AU);

    /* Enable RX: promisc multicast, 2KB buffers, strip CRC, broadcast */
    mmio_w(REG_RCTL, RCTL_EN | RCTL_MPE | RCTL_BAM | RCTL_BSIZE_2K | RCTL_SECRC);

    _nic.online = 1;
    return 0;
}

/* =========================================================================
 * nic_send — copy frame into next TX descriptor + ring doorbell
 * ========================================================================= */
int nic_send(const uint8_t *frame, uint32_t len) {
    if (!_nic.online) return -1;
    if (len > BUF_SZ || len < 14) return -2;  /* min Ethernet frame = 14 bytes hdr */

    uint32_t i = _tx_tail;
    /* Wait for descriptor to be free (DD bit set by hardware) */
    uint32_t spin = 0;
    while (!(_tx_ring[i].status & TDESC_STA_DD)) {
        if (++spin > 100000) return -3;  /* TX timeout */
        __asm__ volatile("pause");
    }

    /* Copy frame data */
    for (uint32_t b = 0; b < len; b++) _tx_buf[i][b] = frame[b];

    /* Set up descriptor */
    _tx_ring[i].length = (uint16_t)len;
    _tx_ring[i].cmd    = TDESC_CMD_EOP | TDESC_CMD_IFCS | TDESC_CMD_RS;
    _tx_ring[i].status = 0;  /* clear DD — hardware owns it now */

    /* Advance tail and ring doorbell */
    _tx_tail = (_tx_tail + 1) & (TX_RING_SZ - 1);
    mmio_w(REG_TDT, _tx_tail);
    return (int)len;
}

/* =========================================================================
 * nic_recv — poll RX ring, copy first complete frame, return length
 * ========================================================================= */
int nic_recv(uint8_t *buf, uint32_t bufsz) {
    if (!_nic.online) return 0;

    /* Next expected descriptor is one past current tail (hardware writes head→tail) */
    uint32_t next = (_rx_tail + 1) & (RX_RING_SZ - 1);
    rx_desc_t *d = &_rx_ring[next];

    if (!(d->status & RDESC_STA_DD)) return 0;   /* nothing received */
    if (!(d->status & RDESC_STA_EOP)) return 0;  /* not a complete frame */

    uint32_t len = d->length;
    if (len > bufsz) len = bufsz;
    for (uint32_t b = 0; b < len; b++) buf[b] = _rx_buf[next][b];

    /* Return descriptor to hardware */
    d->status = 0;
    d->addr   = (uint64_t)(uintptr_t)_rx_buf[next];
    _rx_tail  = next;
    mmio_w(REG_RDT, _rx_tail);
    return (int)len;
}

/* =========================================================================
 * Accessors
 * ========================================================================= */
const nic_info_t *nic_get_info(void) { return &_nic; }

/* zchg multicast group: 01:00:5E:7A:43:00 */
const uint8_t ZCHG_MCAST_MAC[6] = { 0x01, 0x00, 0x5E, 0x7A, 0x43, 0x00 };
