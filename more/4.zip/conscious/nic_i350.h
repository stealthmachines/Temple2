/*
 * nic_i350.h — Intel I350/X540 raw Ethernet driver, ring-0.
 * Direct MMIO via PCI BAR0. No OS abstraction.
 * Targets: Dell R430/R530 on-board I350-AM4 or X540-AT2.
 */
#ifndef NIC_I350_H
#define NIC_I350_H

#include "../kernel/hdgl_types.h"

/* NIC capabilities reported after init */
typedef struct {
    uint64_t mmio_base;      /* BAR0 physical address */
    uint8_t  mac[6];         /* burned-in MAC */
    uint32_t link_speed;     /* 1000 or 10000 Mbps; 0 = no link */
    int      online;         /* 1 if init succeeded */
} nic_info_t;

/* ---- Public API ---- */
int  nic_init(void);                                /* probe + init first NIC */
int  nic_send(const uint8_t *frame, uint32_t len); /* raw Ethernet TX */
int  nic_recv(uint8_t *buf, uint32_t bufsz);       /* raw Ethernet RX, returns len or 0 */
const nic_info_t *nic_get_info(void);

/* zchg multicast group: 01:00:5E:7A:43:00 (zchg = 0x7A43) */
extern const uint8_t ZCHG_MCAST_MAC[6];

#endif /* NIC_I350_H */
