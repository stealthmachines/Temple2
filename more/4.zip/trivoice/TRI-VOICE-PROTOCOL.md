# TRI-VOICE Coordination Protocol
## HDGL-OS / Temple2 Hybrid ISO Build

Three AI voices build the OS together. Each has a designated domain.
All work is tracked in FILL ZONEs inside the source files.

---

## VOICE 1 — CLAUDE (Architecture + Glue)
**Files owned:** Makefile, linker.ld, boot/*, kernel/temple2_bridge.h,
                 hdgl/phi_engine.h, bot/mcp_confined.h, conscious/zchg_phy.h,
                 trivoice/, design_tree.json, PLAN.md sync

**Responsibilities:**
- Overall architecture and layer boundaries
- Header contracts (all .h files define the API)
- Build system (Makefile, linker script)
- Boot entry (multiboot_entry.asm, long_mode_init.c boot sequence)
- design_tree.json updates as the design evolves
- Pass task boundaries to Copilot + Qwen via FILL ZONE comments

**Current output:** this scaffold (all files in HDGL-OS/)

---

## VOICE 2 — COPILOT (HolyC Kernel + C implementations)
**Files owned:** kernel/temple2_bridge.c, kernel/holyc_syscall.c,
                 kernel/scheduler.c, bot/mcp_confined.c (pass routing),
                 conscious/zchg_phy.c (NIC driver + gossip + HMAC-SHA256)

**Fill zones in temple2_bridge.c:**
- [ ] `KernelInit()` — from 02-Kernel-Core/ IDT + exception handler setup
- [ ] `SchedulerInit()` — from 02-Kernel-Core/Scheduler/ task structures
- [ ] `SysCAllInit()` — from 02-Kernel-Core/Syscall-Trap-Boundary/
- [ ] `CInit()` — from 06-Compiler-Toolchain/Build-Driver/CInit.HC
- [ ] `HomeSys()` — from 01-Boot-Early-Bring-Up/System-Init-Startup/HomeSys.HC
- [ ] `StartOS()` — from 01-Boot-Early-Bring-Up/System-Init-Startup/StartOS.HC
- [ ] `temple2_exec_hc()` — wire Lex→Parse→CodeGen→Asm pipeline
- [ ] `temple2_main_loop()` — Frontierland terminal REPL

**Fill zones in conscious/zchg_phy.c:**
- [ ] NIC MMIO init (Intel I350/X540 for Dell R430/R530)
- [ ] HMAC-SHA256 compression function
- [ ] ETH light client query for CHG Coin park() resurrection

**Fill zones in bot/mcp_confined.c:**
- [ ] ERL V3 BST insertion / full ledger ops
- [ ] `pass_shell()` — Temple2 ring-0 shell command dispatch
- [ ] Temple2 scheduler task registration

**Source files to read:**
```
../OS primitives (temple2)/Spare Parts/02-Kernel-Core/Scheduler/
../OS primitives (temple2)/Spare Parts/06-Compiler-Toolchain/Build-Driver/CInit.HC
../OS primitives (temple2)/Spare Parts/01-Boot-Early-Bring-Up/System-Init-Startup/StartOS.HC
../NGINX-HDGL-0.6-c/zchg_gossip.c
../NGINX-HDGL-0.6-c/zchg_frame.c
../MCP-Jailbreak-0.11/server.js (ERL V3)
```

---

## VOICE 3 — QWEN3.5-9B (Phi Math + Local Inference)
**Model:** `~/.ollama/models/blobs/unsloth/Qwen3.5-9B-GGUF/Qwen3.5-9B-UD-Q6_K_XL.gguf`
**Files owned:** hdgl/phi_engine.c, bot/mcp_confined.c (mcp_infer_qwen),
                 hdgl/kuramoto.c (to be created), hdgl/hdgl_glyph.c (to be created)

**Fill zones in hdgl/phi_engine.c:**
- [ ] `binet_F(x)` — continuous Fibonacci via x87 fyl2x
- [ ] `phi_pow2(x)` — proper fractional 2^x (f2xm1 + scale)
- [ ] `kuramoto_rk4_step()` — upgrade Euler to 4th-order Runge-Kutta
- [ ] `hdgl_glyph_encode()` — full 20-float glyph vector from concept string
- [ ] Tune `g_kuramoto.K` for reliable 8-oscillator locking

**Fill zones in bot/mcp_confined.c:**
- [ ] `mcp_infer_qwen()` — GGUF header parse, Q6_K dequant, matmul, BPE decode

**Math constants (already in hdgl_phi_lang.h):**
```c
PHI               = 1.6180339887498948482
DN_EMPIRICAL_BETA = 0.360942   // chi^2_red ≈ 0 (Pan-STARRS1 fit)
SPIRAL8_AXES[8]   // primes 2,3,5,7,11,13,17,19 + phi^k
PHI_LANG_TOKENS[5] // Lambda_phi, D_n, S_p, U_field, D_n_cal
```

**Key formula:**
```
D(n,beta) = sqrt(phi * F(n+beta) * P(n+beta) * 2^(n+beta) * Omega) * r^k
Omega     = 0.5 + 0.5*sin(pi*frac(n)*phi)
Lambda_phi = log(p*ln2/lnphi)/lnphi - 1/(2*phi)
S(p)      = |e^(i*pi*Lambda_phi) + 1_eff|
```

---

## Build Order

```
Step 1 (Claude)  : scaffold complete — all files in HDGL-OS/ ✓
Step 2 (Copilot) : implement Temple2 kernel init chain
Step 3 (Qwen)    : implement phi engine math (RK4, glyph encoder)
Step 4 (Copilot) : implement NIC driver + zchg gossip
Step 5 (Qwen)    : implement GGUF loader + Qwen inference in ring-0
Step 6 (Copilot) : wire full HolyC compiler pipeline
Step 7 (Claude)  : integration, Makefile tuning, ISO build verification
Step 8 (All)     : test boot in QEMU → iDRAC8 virtual media
```

## Test Command (QEMU)
```bash
make all
qemu-system-x86_64 -cdrom hdgl-os.iso -m 8G -serial stdio \
  -cpu host -smp 4 -enable-kvm
```

## iDRAC8 Boot
1. Upload `hdgl-os.iso` to iDRAC8 Virtual Media
2. Boot order: Virtual CD/DVD first
3. Monitor via serial console (COM1, 115200 8N1)

---

## TRI-VOICE Integration with TRI-VOICE tool
*When the TRI-VOICE tool files are pasted here, add them to this directory.*
*The tool coordinates all three voices via the FILL ZONE annotation system.*
*Each voice reads only its own fill zones and writes only its owned files.*
