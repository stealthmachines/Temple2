#!/usr/bin/env bash
# HDGL-OS Phase 1 build script — run from Linux sandbox
# Requires: nasm (at /snap/lxd/38800/bin/nasm), gcc, ld, grub-mkimage
set -e

BUILD="$(cd "$(dirname "$0")" && pwd)"
NASM="/snap/lxd/38800/bin/nasm"
OUT="/tmp"

KFLAGS=( -std=c99 -ffreestanding -fno-stack-protector -mno-red-zone
         -mno-sse -mno-sse2 -mno-mmx -O2 -Wall -Wno-unused-parameter
         "-I${BUILD}/kernel" "-I${BUILD}/hdgl" "-I${BUILD}/conscious" )

HFLAGS=( -std=c99 -ffreestanding -fno-stack-protector -mno-red-zone
         -O2 -Wall -Wno-unused-parameter
         "-I${BUILD}/kernel" "-I${BUILD}/hdgl" "-I${BUILD}/conscious" )

echo "[1/4] GRUB El Torito image"
grub-mkimage \
  --format=i386-pc-eltorito \
  --output="${OUT}/grub-eltorito.img" \
  --prefix=/boot/grub \
  biosdisk iso9660 multiboot2 normal configfile terminal \
  serial echo all_video gfxterm gfxterm_background ls cat help

echo "[2/4] Compile modules"
"$NASM" -f elf64 -o "${OUT}/mbe.o" "${BUILD}/boot/multiboot_entry.asm"
gcc "${KFLAGS[@]}" -c -o "${OUT}/lmi.o"  "${BUILD}/boot/long_mode_init.c"
gcc "${KFLAGS[@]}" -c -o "${OUT}/t2b.o"  "${BUILD}/kernel/temple2_bridge.c"
gcc "${KFLAGS[@]}" -c -o "${OUT}/hcs.o"  "${BUILD}/kernel/holyc_syscall.c"
gcc "${KFLAGS[@]}" -c -o "${OUT}/sch.o"  "${BUILD}/kernel/scheduler.c"
gcc "${HFLAGS[@]}" -c -o "${OUT}/phe.o"  "${BUILD}/hdgl/phi_engine.c"
gcc "${HFLAGS[@]}" -c -o "${OUT}/kur.o"  "${BUILD}/hdgl/kuramoto.c"
gcc "${HFLAGS[@]}" -c -o "${OUT}/gly.o"  "${BUILD}/hdgl/hdgl_glyph.c"
gcc "${KFLAGS[@]}" -c -o "${OUT}/mcp.o"  "${BUILD}/bot/mcp_confined.c"
gcc "${KFLAGS[@]}" -c -o "${OUT}/zphy.o" "${BUILD}/conscious/zchg_phy.c"
gcc "${KFLAGS[@]}" -c -o "${OUT}/nic.o"  "${BUILD}/conscious/nic_i350.c"
gcc "${KFLAGS[@]}" -c -o "${OUT}/prt.o"  "${BUILD}/conscious/phi_router.c"

echo "[3/4] Link kernel ELF"
ld -nostdlib -z max-page-size=0x1000 \
   -T "${BUILD}/boot/linker.ld" \
   -o "${OUT}/hdgl-kernel.elf" \
   "${OUT}/mbe.o" "${OUT}/lmi.o" "${OUT}/t2b.o" "${OUT}/hcs.o" "${OUT}/sch.o" \
   "${OUT}/phe.o" "${OUT}/kur.o" "${OUT}/gly.o" \
   "${OUT}/mcp.o" \
   "${OUT}/zphy.o" "${OUT}/nic.o" "${OUT}/prt.o"
echo "  kernel: $(ls -lh ${OUT}/hdgl-kernel.elf | awk '{print $5}')"

echo "[4/4] Build ISO"
# Rebuild iso_builder if needed
[ -x "${OUT}/iso_builder" ] || gcc -O2 -o "${OUT}/iso_builder" "${BUILD}/../tools/iso_builder.c"
"${OUT}/iso_builder" \
  "${OUT}/grub-eltorito.img" \
  "${OUT}/hdgl-kernel.elf" \
  "${BUILD}/iso/grub/grub.cfg" \
  "${BUILD}/hdgl-os.iso"

echo ""
echo "Done: ${BUILD}/hdgl-os.iso"
echo "Test: qemu-system-x86_64 -cdrom ${BUILD}/hdgl-os.iso -m 8G -serial stdio -nographic -enable-kvm"
