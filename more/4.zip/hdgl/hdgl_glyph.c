/*
 * hdgl_glyph.c
 * HDGL 20-float glyph vector encoder/decoder.
 *
 * Glyph vector layout (from design_tree.json + zchg.org forum #862):
 *   [X, Y, Z, M  |  ΔDNA, ΔBase4096  |  phi_n, Fn, Pn, 2^n
 *    |  s, C, Ω, m, h, E, F, V  |  D_n_r, k]
 *
 * Encoding:
 *   1. Hash concept string → (n, prime_idx) in phi-log space
 *   2. Compute D(n, DN_EMPIRICAL_BETA) using x87 FPU
 *   3. Fill spatial coords from Spiral8 axis geometry
 *   4. Physical constants from CODATA (embedded)
 */

#include "phi_engine.h"
#include "../kernel/hdgl_types.h"

#define PHI          1.6180339887498948482f
#define DN_BETA      0.360942f
#define PI           3.14159265358979323846f
#define SQRT5        2.2360679774997896f

/* x87 helpers */
static inline float _sin(float x)  { float r; __asm__ volatile("fsin"  :"=t"(r):"0"(x)); return r; }
static inline float _sqrt(float x) { float r; __asm__ volatile("fsqrt" :"=t"(r):"0"(x)); return r; }
static inline float _fabs(float x) { return x < 0.f ? -x : x; }

/* x87 2^x using f2xm1 + fscale */
static inline float _pow2(float x) {
    float frac = x - (float)(int)x;
    float i    = (float)(int)x;
    float t, one = 1.0f;
    __asm__ volatile("f2xm1"  : "=t"(t) : "0"(frac));
    t += 1.0f;
    __asm__ volatile("fscale" : "=t"(t) : "0"(t), "u"(i));
    (void)one;
    return t;
}

/* x87 log2 */
static inline float _log2(float x) {
    float r;
    __asm__ volatile("fld1\nfxch\nfyl2x" : "=t"(r) : "0"(x));
    return r;
}
static inline float _log(float x)  { return _log2(x) / _log2(2.718281828f); }

/* Continuous Binet Fibonacci F(x) = (phi^x - cos(πx)·phi^(-x)) / √5 */
static float binet_F(float x) {
    float phi_pos = _pow2(x * _log2(PHI));
    float phi_neg = 1.f / (phi_pos < 1e-10f ? 1e-10f : phi_pos);
    float c;
    __asm__ volatile("fcos" : "=t"(c) : "0"(PI * x));
    return (phi_pos - c * phi_neg) / SQRT5;
}

/* Ω modulation: 0.5 + 0.5·sin(π·frac(n)·φ) */
static float omega_mod(float n) {
    float frac = n - (float)(int)n;
    return 0.5f + 0.5f * _sin(PI * frac * PHI);
}

/* D(n, beta) = sqrt(φ·F(n+β)·P(n+β)·2^(n+β)·Ω)·r^k  at r=1, k=1 */
static float D_val(float n, float beta, float prime) {
    float nb  = n + beta;
    float Fnb = binet_F(nb);
    if (Fnb < 0.f) Fnb = -Fnb;
    float Om  = omega_mod(nb);
    float val = PHI * Fnb * prime * _pow2(nb) * Om;
    return _sqrt(_fabs(val));
}

/* FNV-1a 64 → (n, prime_idx) mapping */
static void concept_to_coord(const char *s, float *n_out, int *pidx_out) {
    uint64_t h = 14695981039346656037ULL;
    while (*s) { h ^= (uint8_t)*s++; h *= 1099511628211ULL; }
    /* n in [0, 8), prime_idx in [0, 8) */
    *n_out   = (float)(h & 0xFF) / 32.f;          /* 0.0 – 8.0 */
    *pidx_out = (int)((h >> 8) & 0x7);             /* 0 – 7     */
}

/* CODATA-2018 physical constants (embedded, no runtime lookup) */
#define CODATA_c    2.99792458e8f    /* speed of light m/s       */
#define CODATA_h    6.62607015e-34f  /* Planck constant J·s       */
#define CODATA_e    1.60217663e-19f  /* elementary charge C       */
#define CODATA_me   9.1093837015e-31f/* electron mass kg          */

/* ---- Public API -------------------------------------------------------- */

void hdgl_glyph_encode(const char *concept, hdgl_glyph_t *out) {
    float n; int pidx;
    concept_to_coord(concept, &n, &pidx);

    const spiral8_axis_t *ax = spiral8_find(pidx);
    float prime = ax ? (float)ax->prime : 2.f;

    float d = D_val(n, DN_BETA, prime);
    float Om = omega_mod(n + DN_BETA);

    /* Spatial: map Spiral8 geometry to XYZ */
    out->X = ax ? ax->phi_power * _sin(n * PI) : n;
    out->Y = ax ? ax->phi_power * _sin(n * PI * PHI) : n * PHI;
    out->Z = d;
    out->M = Om;

    /* Symbolic */
    out->dDNA     = d * DN_BETA;
    out->dBase4096 = d * (1.f / 4096.f);

    /* Harmonic */
    out->phi_n  = n;
    out->Fn     = binet_F(n);
    out->Pn     = prime;
    out->pow2n  = _pow2(n);

    /* Physical (CODATA) */
    out->s     = CODATA_c;
    out->C     = CODATA_e;
    out->Omega = Om;
    out->m     = CODATA_me;
    out->h     = CODATA_h;
    out->E     = d * CODATA_h;
    out->F     = prime * d;
    out->V     = d * d;

    /* Recursive */
    out->D_n_r = d;
    out->k     = 1.f;
}

/* Decode: recover best-matching token label from glyph D_n_r */
const char *hdgl_glyph_label(const hdgl_glyph_t *g) {
    const phi_token_t *best = NULL;
    float best_dist = 1e30f;
    for (int i = 0; i < PHI_LANG_N_TOKENS; i++) {
        float diff = PHI_LANG_TOKENS[i].d_val - g->D_n_r;
        if (diff < 0.f) diff = -diff;
        if (diff < best_dist) { best_dist = diff; best = &PHI_LANG_TOKENS[i]; }
    }
    return best ? best->label : "unknown";
}
