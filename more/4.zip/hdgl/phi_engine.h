/* phi_engine.h — HDGL phi analog engine API */
#pragma once
#ifndef PHI_ENGINE_H
#define PHI_ENGINE_H

#include <stdint.h>
#include "../kernel/hdgl_types.h"

/* Pull in phi token + spiral8 tables from Analog-Prime */
#include "hdgl_phi_lang.h"

/* 20-float HDGL glyph vector */
typedef struct {
    float X,Y,Z,M;
    float dDNA, dBase4096;
    float phi_n, Fn, Pn, pow2n;
    float s, C, Omega, m, h, E, F, V;
    float D_n_r, k;
} hdgl_glyph_t;

/* 8D Kuramoto oscillator state */
typedef struct {
    float theta[8];
    float omega[8];
    float K;
    int   locked;
    float S_U;
} kuramoto_state_t;

extern kuramoto_state_t g_kuramoto;

int  hdgl_phi_init(void);
void hdgl_phi_tick(float dt);
int  hdgl_phi_prime_test(void);
void hdgl_glyph_encode(const char *concept, hdgl_glyph_t *out);
const char *hdgl_glyph_label(const hdgl_glyph_t *g);

/* from kuramoto.c */
float kuramoto_order_param(const kuramoto_state_t *ks);

#endif
