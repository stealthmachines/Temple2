/*
 * kuramoto.c -- 8-oscillator Kuramoto RK4. YANG phi-resonance field.
 */
#include "phi_engine.h"
#include "../kernel/hdgl_types.h"

#define N_OSC 8
#define PI    3.14159265358979323846f

static inline float _sin(float x){float r;__asm__ volatile("fsin" :"=t"(r):"0"(x));return r;}
static inline float _cos(float x){float r;__asm__ volatile("fcos" :"=t"(r):"0"(x));return r;}
static inline float _sqrt(float x){float r;__asm__ volatile("fsqrt":"=t"(r):"0"(x));return r;}
static inline float _fabs(float x){return x<0.f?-x:x;}
static inline float _atan2(float y,float x){
    float r;__asm__ volatile("fpatan":"=t"(r):"0"(x),"u"(y):"st(1)");return r;}
static float wrap(float a){while(a>PI)a-=2.f*PI;while(a<-PI)a+=2.f*PI;return a;}

static float dth(const float*th,int i,const float*om,float K){
    float s=0.f;for(int j=0;j<N_OSC;j++)if(j!=i)s+=_sin(th[j]-th[i]);
    return om[i]+(K/N_OSC)*s;}

static void rk4_step(kuramoto_state_t*ks,float dt){
    float k1[8],k2[8],k3[8],k4[8],tmp[8];
    for(int i=0;i<N_OSC;i++)k1[i]=dth(ks->theta,i,ks->omega,ks->K);
    for(int i=0;i<N_OSC;i++)tmp[i]=wrap(ks->theta[i]+0.5f*dt*k1[i]);
    for(int i=0;i<N_OSC;i++)k2[i]=dth(tmp,i,ks->omega,ks->K);
    for(int i=0;i<N_OSC;i++)tmp[i]=wrap(ks->theta[i]+0.5f*dt*k2[i]);
    for(int i=0;i<N_OSC;i++)k3[i]=dth(tmp,i,ks->omega,ks->K);
    for(int i=0;i<N_OSC;i++)tmp[i]=wrap(ks->theta[i]+dt*k3[i]);
    for(int i=0;i<N_OSC;i++)k4[i]=dth(tmp,i,ks->omega,ks->K);
    for(int i=0;i<N_OSC;i++)
        ks->theta[i]=wrap(ks->theta[i]+(dt/6.f)*(k1[i]+2.f*k2[i]+2.f*k3[i]+k4[i]));}

float kuramoto_order_param(const kuramoto_state_t*ks){
    float sr=0.f,si=0.f;
    for(int i=0;i<N_OSC;i++){sr+=_cos(ks->theta[i]);si+=_sin(ks->theta[i]);}
    return _sqrt((sr*sr+si*si)/(float)(N_OSC*N_OSC));}

static void check_lock(kuramoto_state_t*ks){
    float R=kuramoto_order_param(ks);
    if(R>0.95f){ks->locked=0xFF;ks->S_U=1.531f;return;}
    float cx=0.f,cy=0.f;
    for(int i=0;i<N_OSC;i++){cx+=_cos(ks->theta[i]);cy+=_sin(ks->theta[i]);}
    cx/=N_OSC;cy/=N_OSC;
    float cen=_atan2(cy,cx);ks->locked=0;
    for(int i=0;i<N_OSC;i++)
        if(_fabs(wrap(ks->theta[i]-cen))<0.1f)ks->locked|=(1<<i);
    ks->S_U=R;}

void kuramoto_tick(kuramoto_state_t*ks,float dt){rk4_step(ks,dt);check_lock(ks);}
