/*
 * phi_engine.c — HDGL phi analog engine (init + tick + prime test).
 * hdgl_glyph_encode() lives in hdgl_glyph.c (same translation unit group).
 */

#include "phi_engine.h"
#include "../kernel/hdgl_types.h"

#define PHI    1.6180339887498948482f
#define PI     3.14159265358979323846f

static inline float _sin(float x){float r;__asm__ volatile("fsin" :"=t"(r):"0"(x));return r;}

/* Forward from kuramoto.c */
extern void kuramoto_tick(kuramoto_state_t *ks, float dt);

kuramoto_state_t g_kuramoto;

int hdgl_phi_init(void) {
    for (int k = 0; k < 8; k++) {
        g_kuramoto.omega[k] = SPIRAL8_AXES[k].phi_power * (float)SPIRAL8_AXES[k].prime;
        g_kuramoto.theta[k] = (float)k * 0.13f;
    }
    g_kuramoto.K      = 3.0f;
    g_kuramoto.locked = 0;
    g_kuramoto.S_U    = 0.f;
    return 0;
}

void hdgl_phi_tick(float dt) {
    kuramoto_tick(&g_kuramoto, dt);
}

int hdgl_phi_prime_test(void) {
    return (g_kuramoto.locked == 0xFF) ? 1 : 0;
}
