/*
 * holyc_syscall.c
 * Syscall/trap boundary — Temple2 ring-0 model (no user-mode separation).
 * All "syscalls" are direct function calls in the same address space.
 * Reference: OS primitives (temple2)/Spare Parts/02-Kernel-Core/Syscall-Trap-Boundary/KMain.HC
 */

#include "hdgl_types.h"
#include "temple2_bridge.h"

/* Syscall table — index matches Temple2 SysCall IDs */
typedef void (*syscall_fn_t)(void);

#define SYSCALL_MAX 64
syscall_fn_t _syscall_table[SYSCALL_MAX];

void syscall_register(int id, syscall_fn_t fn) {
    if (id >= 0 && id < SYSCALL_MAX) _syscall_table[id] = fn;
}

/* INT 0x80 dispatch (ring-0 software interrupt) */
__attribute__((naked)) void _int80_handler(void) {
    __asm__ volatile(
        "pushq %%rax\n\t"
        "cmpq $64, %%rax\n\t"
        "jae 1f\n\t"
        /* call _syscall_table[rax] */
        "lea _syscall_table(%%rip), %%rcx\n\t"
        "movq (%%rcx,%%rax,8), %%rcx\n\t"
        "testq %%rcx, %%rcx\n\t"
        "jz 1f\n\t"
        "callq *%%rcx\n\t"
        "1: popq %%rax\n\t"
        "iretq"
        ::: "rcx"
    );
}

/* SYSCALL MSR-based fast path (SYSCALL/SYSRET, IA32_STAR/LSTAR) */
void syscall_msr_init(void) {
    /* IA32_EFER — enable SCE (syscall extensions) */
    uint64_t efer;
    __asm__ volatile("rdmsr" : "=A"(efer) : "c"(0xC0000080U));
    efer |= 1;
    __asm__ volatile("wrmsr" :: "A"(efer), "c"(0xC0000080U));

    /* LSTAR — syscall handler (not used in ring-0 only OS, but set anyway) */
    uint64_t h = (uint64_t)_int80_handler;
    __asm__ volatile("wrmsr" :: "A"(h), "c"(0xC0000082U));

    /* STAR — CS/SS selectors */
    __asm__ volatile("wrmsr" :: "A"((uint64_t)0x0008000800000000ULL), "c"(0xC0000081U));
}
