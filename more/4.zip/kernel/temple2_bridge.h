/*
 * temple2_bridge.h — Temple2-inspired ring-0 kernel API
 */
#pragma once
#ifndef TEMPLE2_BRIDGE_H
#define TEMPLE2_BRIDGE_H

#include <stdint.h>
#include "hdgl_types.h"

int   temple2_init(uint64_t mb2_info);
int   temple2_exec_hc(const char *src, char *result, uint32_t rlen);
void  temple2_main_loop(void);
void *temple2_alloc(uint64_t size);
void  temple2_free(void *ptr);

#endif
