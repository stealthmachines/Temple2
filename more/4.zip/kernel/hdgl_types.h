/*
 * hdgl_types.h  — shared freestanding types, included by every module
 */
#pragma once
#ifndef HDGL_TYPES_H
#define HDGL_TYPES_H

#include <stdint.h>

typedef uint8_t  U8;
typedef uint16_t U16;
typedef uint32_t U32;
typedef uint64_t U64;
typedef int8_t   I8;
typedef int16_t  I16;
typedef int32_t  I32;
typedef int64_t  I64;
typedef double   F64;
typedef float    F32;

#define NULL ((void*)0)
#define TRUE  1
#define FALSE 0

/* serial write helpers (COM1 = 0x3F8) */
static inline void _serial_putc(char c) {
    uint8_t s;
    do { __asm__ volatile("inb %1,%0":"=a"(s):"Nd"((uint16_t)0x3FD)); } while(!(s&0x20));
    __asm__ volatile("outb %0,%1"::"a"((uint8_t)c),"Nd"((uint16_t)0x3F8));
}
static inline void kprint(const char *s) {
    while (*s) { if (*s=='\n') _serial_putc('\r'); _serial_putc(*s++); }
}
static inline void kprint_hex64(uint64_t v) {
    const char *h="0123456789ABCDEF";
    kprint("0x");
    for(int i=60;i>=0;i-=4) _serial_putc(h[(v>>i)&0xF]);
}

#endif
