/*
 * scheduler.c
 * Minimal cooperative ring-0 scheduler — Temple2 single-address-space model.
 * Reference: OS primitives (temple2)/Spare Parts/02-Kernel-Core/Scheduler/Sched.HC
 *
 * Temple2 runs everything at ring-0, cooperative multitasking.
 * Tasks yield explicitly; the timer IRQ bumps a tick counter only.
 * For Phase 1 we run a single task (main loop). Expansion in Phase 2.
 */

#include "hdgl_types.h"
#include "temple2_bridge.h"

#define MAX_TASKS   16
#define STACK_SIZE  (64 * 1024)   /* 64KB per task stack */

typedef struct Task {
    uint64_t  rsp;          /* saved stack pointer */
    uint64_t  rip;          /* saved instruction pointer (unused — cooperative) */
    uint8_t   state;        /* 0=empty, 1=ready, 2=running, 3=blocked */
    char      name[32];
    uint8_t  *stack;
} Task;

static Task   _tasks[MAX_TASKS];
static int    _cur = 0;
static int    _task_count = 0;

/* Allocate a stack from the ring-0 heap */
static uint8_t *alloc_stack(void) {
    return (uint8_t *)temple2_alloc(STACK_SIZE);
}

/* Register the boot task (the one already running at boot) */
void scheduler_init(void) {
    for (int i = 0; i < MAX_TASKS; i++) _tasks[i].state = 0;

    /* Task 0 = current boot context */
    _tasks[0].state = 2; /* running */
    _tasks[0].stack = NULL; /* uses boot stack */
    const char *n = "hdgl_main";
    for (int i = 0; n[i] && i < 31; i++) _tasks[0].name[i] = n[i];
    _cur = 0;
    _task_count = 1;
}

/* Spawn a new ring-0 task (cooperative) */
int task_spawn(const char *name, void (*entry)(void)) {
    if (_task_count >= MAX_TASKS) return -1;
    int slot = -1;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (_tasks[i].state == 0) { slot = i; break; }
    }
    if (slot < 0) return -1;

    uint8_t *stk = alloc_stack();
    if (!stk) return -1;

    /* Set up initial stack frame for first context switch */
    uint64_t *sp = (uint64_t *)(stk + STACK_SIZE);
    *--sp = 0;                  /* alignment */
    *--sp = (uint64_t)entry;    /* return address = task entry */

    _tasks[slot].rsp   = (uint64_t)sp;
    _tasks[slot].state = 1; /* ready */
    _tasks[slot].stack = stk;
    for (int i = 0; name[i] && i < 31; i++) _tasks[slot].name[i] = name[i];
    _task_count++;
    return slot;
}

/* Yield — switch to next ready task (round-robin, cooperative) */
void task_yield(void) {
    int next = (_cur + 1) % MAX_TASKS;
    while (_tasks[next].state != 1 && next != _cur)
        next = (next + 1) % MAX_TASKS;
    if (next == _cur) return;  /* nothing else to run */

    int prev = _cur;
    _cur = next;
    _tasks[prev].state = 1;    /* was running → ready */
    _tasks[next].state = 2;    /* ready → running */

    /* Context switch via stack swap */
    __asm__ volatile(
        "movq %%rsp, %0\n\t"
        "movq %1, %%rsp\n\t"
        : "=m"(_tasks[prev].rsp)
        : "m"(_tasks[next].rsp)
        : "memory"
    );
}
