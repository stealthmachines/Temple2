/*
 * temple2_bridge.c  —  Temple2-inspired ring-0 kernel environment.
 * Pure C99, ffreestanding. No HolyC runtime required at boot.
 */

#include "temple2_bridge.h"
#include "hdgl_types.h"

/* =========================================================================
 * RING-0 HEAP
 * ========================================================================= */
#define HOLYC_HEAP_SIZE (32 * 1024 * 1024)
static uint8_t __attribute__((aligned(16)))
               _heap[HOLYC_HEAP_SIZE];
static uint64_t _heap_top = 0;

void *temple2_alloc(uint64_t size) {
    size = (size + 15) & ~15ULL;
    if (_heap_top + size > HOLYC_HEAP_SIZE) return NULL;
    uint8_t *p = _heap + _heap_top; _heap_top += size;
    for (uint64_t i = 0; i < size; i++) p[i] = 0;
    return p;
}
void temple2_free(void *p) { (void)p; }

/* =========================================================================
 * PORT I/O helpers (AT&T syntax — value in %al, port immediate)
 * ========================================================================= */
static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile("outb %0, %1" :: "a"(val), "Nd"(port));
}
static inline uint8_t inb(uint16_t port) {
    uint8_t v;
    __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(port));
    return v;
}

/* =========================================================================
 * GDT
 * ========================================================================= */
typedef struct { uint64_t raw; } __attribute__((packed)) GdtEntry;
typedef struct { uint16_t limit; uint64_t base; } __attribute__((packed)) GdtPtr;

static GdtEntry _gdt[5];
static GdtPtr   _gdt_ptr;

static void gdt_set(int i, uint8_t access, uint8_t gran) {
    /* GDT descriptor 64-bit layout (little-endian):
     *   bits 15: 0  = limit  15:0   (byte 0-1)
     *   bits 31:16  = base   15:0   (byte 2-3)
     *   bits 39:32  = base   23:16  (byte 4)
     *   bits 47:40  = access byte   (byte 5)
     *   bits 51:48  = limit  19:16  (byte 6 lo)
     *   bits 55:52  = flags G/D/L/A (byte 6 hi)
     *   bits 63:56  = base   31:24  (byte 7)
     * Flat base=0, limit=0xFFFF → full 4 GB with G=1.
     */
    _gdt[i].raw =
        0x000000000000FFFFULL             |   /* limit lo = 0xFFFF */
        ((uint64_t)access      << 40)     |   /* access byte */
        ((uint64_t)0xF         << 48)     |   /* limit hi = 0xF */
        ((uint64_t)(gran&0xF0) << 48);        /* flags nibble (G,D/B,L,AVL) */
}

static void gdt_install(void) {
    _gdt[0].raw = 0;
    gdt_set(1, 0x9A, 0xA0);   /* 64-bit code ring-0 */
    gdt_set(2, 0x92, 0xC0);   /* 64-bit data ring-0 */
    gdt_set(3, 0xFA, 0xA0);   /* 64-bit code ring-3 */
    gdt_set(4, 0xF2, 0xC0);   /* 64-bit data ring-3 */
    _gdt_ptr.limit = sizeof(_gdt) - 1;
    _gdt_ptr.base  = (uint64_t)_gdt;
    __asm__ volatile("lgdt %0" :: "m"(_gdt_ptr));
    __asm__ volatile(
        "pushq $0x08\n\t"
        "lea 1f(%%rip), %%rax\n\t"
        "pushq %%rax\n\t"
        "lretq\n\t"
        "1: mov $0x10, %%ax\n\t"
        "mov %%ax, %%ds; mov %%ax, %%es; mov %%ax, %%ss\n\t"
        "xor %%ax, %%ax; mov %%ax, %%fs; mov %%ax, %%gs\n\t"
        ::: "rax", "memory");
}

/* =========================================================================
 * IDT
 * ========================================================================= */
typedef struct {
    uint16_t off_lo, sel; uint8_t ist, type;
    uint16_t off_mid; uint32_t off_hi, zero;
} __attribute__((packed)) IdtEntry;
typedef struct { uint16_t limit; uint64_t base; } __attribute__((packed)) IdtPtr;

static IdtEntry _idt[256];
static IdtPtr   _idt_ptr;

static void idt_set(int v, void *h, uint8_t t) {
    uint64_t a = (uint64_t)h;
    _idt[v].off_lo  = a & 0xFFFF;
    _idt[v].sel     = 0x08;
    _idt[v].ist     = 0;
    _idt[v].type    = t;
    _idt[v].off_mid = (a >> 16) & 0xFFFF;
    _idt[v].off_hi  = (a >> 32) & 0xFFFFFFFF;
    _idt[v].zero    = 0;
}

/* Exception common handler — called from trampoline */
typedef struct {
    uint64_t rax,rbx,rcx,rdx,rsi,rdi,rbp;
    uint64_t r8,r9,r10,r11,r12,r13,r14,r15;
    uint64_t vec, err, rip, cs, rflags, rsp, ss;
} ExcCtx;

void __attribute__((noreturn)) exc_c_handler(ExcCtx *c) {
    static const char *names[] = {
        "#DE","#DB","NMI","#BP","#OF","#BR","#UD","#NM",
        "#DF","#TS","#NP","#SS","#GP","#PF","--","#MF",
        "#AC","#MC","#XM","#VE","#CP"
    };
    kprint("\n[EXC] "); kprint(c->vec < 21 ? names[c->vec] : "?");
    kprint(" err="); kprint_hex64(c->err);
    kprint(" rip="); kprint_hex64(c->rip);
    kprint("\n");
    for(;;) __asm__ volatile("cli;hlt");
}

/* Non-static so the naked trampoline ASM can reference the label */
void exc_common_entry(void);

void __attribute__((naked)) exc_common_entry(void) {
    __asm__ volatile(
        "push %%r15; push %%r14; push %%r13; push %%r12\n\t"
        "push %%r11; push %%r10; push %%r9;  push %%r8\n\t"
        "push %%rbp; push %%rdi; push %%rsi; push %%rdx\n\t"
        "push %%rcx; push %%rbx; push %%rax\n\t"
        "mov %%rsp, %%rdi\n\t"
        "callq exc_c_handler\n\t"
        ::: );
}

/* Per-exception trampolines: push fake/real err, push vec, jmp common */
#define EXC_NE(n) void __attribute__((naked)) _ex##n(void){__asm__ volatile(\
    "pushq $0\npushq $" #n "\njmp exc_common_entry":::);}
#define EXC_WE(n) void __attribute__((naked)) _ex##n(void){__asm__ volatile(\
    "pushq $" #n "\njmp exc_common_entry":::);}

EXC_NE(0)  EXC_NE(1)  EXC_NE(2)  EXC_NE(3)  EXC_NE(4)  EXC_NE(5)
EXC_NE(6)  EXC_NE(7)  EXC_WE(8)  EXC_NE(9)  EXC_WE(10) EXC_WE(11)
EXC_WE(12) EXC_WE(13) EXC_WE(14) EXC_NE(15) EXC_NE(16) EXC_WE(17)
EXC_NE(18) EXC_NE(19) EXC_NE(20) EXC_WE(21)

/* IRQ stubs: EOI + iretq */
#define IRQ_STUB(n) void __attribute__((naked)) _irq##n(void){ \
    __asm__ volatile("pushq %%rax\nmovb $0x20,%%al\noutb %%al,$0x20\npopq %%rax\niretq":::);}

IRQ_STUB(32) IRQ_STUB(33) IRQ_STUB(34) IRQ_STUB(35)
IRQ_STUB(36) IRQ_STUB(37) IRQ_STUB(38) IRQ_STUB(39)
IRQ_STUB(40) IRQ_STUB(41) IRQ_STUB(42) IRQ_STUB(43)
IRQ_STUB(44) IRQ_STUB(45) IRQ_STUB(46) IRQ_STUB(47)

static void idt_install(void) {
    void *ev[] = {_ex0,_ex1,_ex2,_ex3,_ex4,_ex5,_ex6,_ex7,_ex8,_ex9,
                  _ex10,_ex11,_ex12,_ex13,_ex14,_ex15,_ex16,_ex17,
                  _ex18,_ex19,_ex20,_ex21};
    for (int i=0;i<22;i++) idt_set(i, ev[i], 0x8E);

    void *iv[] = {_irq32,_irq33,_irq34,_irq35,_irq36,_irq37,_irq38,_irq39,
                  _irq40,_irq41,_irq42,_irq43,_irq44,_irq45,_irq46,_irq47};
    for (int i=0;i<16;i++) idt_set(32+i, iv[i], 0x8E);

    _idt_ptr.limit = sizeof(_idt) - 1;
    _idt_ptr.base  = (uint64_t)_idt;
    __asm__ volatile("lidt %0" :: "m"(_idt_ptr));
}

/* =========================================================================
 * PIC remap + PIT 100Hz
 * ========================================================================= */
static void pic_remap(void) {
    outb(0x20, 0x11); outb(0xA0, 0x11);   /* ICW1: init */
    outb(0x21, 0x20); outb(0xA1, 0x28);   /* ICW2: vector offsets */
    outb(0x21, 0x04); outb(0xA1, 0x02);   /* ICW3: cascade */
    outb(0x21, 0x01); outb(0xA1, 0x01);   /* ICW4: 8086 mode */
    outb(0x21, 0xFF); outb(0xA1, 0xFF);   /* mask all IRQs */
}

static volatile uint64_t _ticks = 0;
void __attribute__((naked)) _timer_isr(void) {
    __asm__ volatile(
        "pushq %%rax\n\t"
        "incq _ticks\n\t"
        "movb $0x20, %%al\n\t"
        "outb %%al, $0x20\n\t"
        "popq %%rax\n\t"
        "iretq" :::);
}

static void pit_init(void) {
    /* 100 Hz: 1193182/100 = 11931 = 0x2EAB */
    outb(0x43, 0x36);
    outb(0x40, 0xAB);   /* lo byte */
    outb(0x40, 0x2E);   /* hi byte */
    idt_set(32, _timer_isr, 0x8E);
    outb(0x21, (uint8_t)(inb(0x21) & 0xFE));  /* unmask IRQ0 only */
}

/* =========================================================================
 * SSE enable (required before phi_engine/kuramoto use XMM registers)
 * CR0: clear EM (bit2), set MP (bit1)
 * CR4: set OSFXSR (bit9) + OSXMMEXCPT (bit10)
 * ========================================================================= */
static void sse_enable(void) {
    uint64_t cr0, cr4;
    __asm__ volatile("mov %%cr0, %0" : "=r"(cr0));
    cr0 &= ~(1ULL << 2);   /* clear EM */
    cr0 |=  (1ULL << 1);   /* set MP  */
    __asm__ volatile("mov %0, %%cr0" :: "r"(cr0));
    __asm__ volatile("mov %%cr4, %0" : "=r"(cr4));
    cr4 |= (1ULL << 9) | (1ULL << 10);  /* OSFXSR + OSXMMEXCPT */
    __asm__ volatile("mov %0, %%cr4" :: "r"(cr4));
    __asm__ volatile("fninit");          /* initialize x87 FPU state */
}

/* =========================================================================
 * temple2_init
 * ========================================================================= */
int temple2_init(uint64_t mb2_info) {
    (void)mb2_info;
    gdt_install();
    sse_enable();
    pic_remap();
    idt_install();
    pit_init();
    __asm__ volatile("sti");
    return 0;
}

/* =========================================================================
 * HolyC REPL stub
 * ========================================================================= */
int temple2_exec_hc(const char *src, char *res, uint32_t rlen) {
    if (!res || rlen < 6) return -1;
    res[0]='['; res[1]='H'; res[2]='C'; res[3]=']'; res[4]=' '; res[5]='\0';
    uint32_t i=5, j=0;
    while (src[j] && i < rlen-1) res[i++] = src[j++];
    res[i] = '\0';
    return 0;
}

/* =========================================================================
 * Serial readline + Frontierland REPL
 * ========================================================================= */
static char _line[512];

static void readline(char *buf, uint32_t max) {
    uint32_t i = 0; uint8_t c;
    while (i < max-1) {
        while (!(inb(0x3FD) & 1));
        c = inb(0x3F8);
        _serial_putc(c);
        if (c=='\r'||c=='\n') { _serial_putc('\n'); break; }
        if (c==127||c==8)     { if(i>0) i--; continue; }
        buf[i++] = c;
    }
    buf[i] = '\0';
}

void temple2_main_loop(void) {
    /* mcp_infer_qwen is in bot/mcp_confined.c — forward declare to avoid
       circular include (mcp_confined.h already includes temple2_bridge.h) */
    extern int mcp_infer_qwen(const char *prompt, char *result, uint32_t rlen);

    static char _result[4096];   /* large enough for RELAY/CHALLENGE responses */

    kprint("\n[HDGL-OS] HDGL Bot ready.\n");
    kprint("  Type a question  — routed via phi to Ollama (SOLO/RELAY/CHALLENGE)\n");
    kprint("  Built-in: phi  ticks  help  halt\n");
    kprint("  COM1=REPL  COM2=LLM bridge (QEMU: -serial stdio -serial tcp::9001)\n");
    kprint("> ");

    while (1) {
        readline(_line, sizeof(_line));
        if (_line[0]=='\0') { kprint("> "); continue; }

        if (_line[0]=='h' && _line[1]=='e') {
            kprint("phi    — Kuramoto lock status\n");
            kprint("ticks  — PIT tick counter\n");
            kprint("halt   — power down\n");
            kprint("(anything else) — sent to LLM via COM2 serial bridge\n");

        } else if (_line[0]=='t') {
            kprint("ticks="); kprint_hex64(_ticks); kprint("\n");

        } else if (_line[0]=='h' && _line[1]=='a') {
            kprint("Halting.\n"); __asm__ volatile("cli;hlt");

        } else if (_line[0]=='p' && _line[1]=='h') {
            extern int hdgl_phi_prime_test(void);
            kprint("phi lock=");
            kprint(hdgl_phi_prime_test() ? "LOCKED(prime)" : "unlocked");
            kprint("\n");

        } else {
            /* Send to LLM via COM2 serial bridge */
            kprint("[BOT] thinking...\n");
            _result[0] = '\0';
            int rc = mcp_infer_qwen(_line, _result, sizeof(_result));
            if (rc == 0 && _result[0] != '\0') {
                kprint(_result);
                kprint("\n");
            } else {
                kprint("[BOT] no response (daemon not connected on COM2?)\n");
                kprint("  Start: LN_SERIAL_PORT=9001 zchg_daemon\n");
                kprint("  QEMU:  -serial stdio -serial tcp:127.0.0.1:9001\n");
            }
        }
        kprint("> ");
    }
}
