# HDGL-OS Phase 1 — Build Summary

## Output
`hdgl-os.iso` — 216KB bootable ISO (El Torito no-emulation, GRUB2)

## Boot chain
```
BIOS/iDRAC8 → El Torito → grub-eltorito (GRUB2 core, LBA 20, 271×512B)
  → grub.cfg  → multiboot2 /boot/hdgl-kernel.elf
    → multiboot_entry.asm (_start, 32→64-bit long mode)
      → long_mode_init.c → temple2_init → hdgl_phi_init
        → mcp_bot_start → zchg_phy_start → temple2_main_loop
```

## Kernel modules compiled
| File | Role |
|------|------|
| `boot/multiboot_entry.asm` | Multiboot2 header + long mode setup (NASM) |
| `boot/long_mode_init.c` | Serial init, MB2 validation, subsystem startup |
| `kernel/temple2_bridge.c` | GDT/IDT/PIC/PIT, ring-0 heap, serial REPL |
| `kernel/holyc_syscall.c` | Syscall table, INT 0x80, SYSCALL MSR |
| `kernel/scheduler.c` | Cooperative ring-0 scheduler, 16 task slots |
| `hdgl/phi_engine.c` | Kuramoto oscillator init + tick |
| `hdgl/kuramoto.c` | 8-oscillator RK4 Kuramoto, order param, lock check |
| `hdgl/hdgl_glyph.c` | 20-float HDGL glyph encoding, D(n,β) formula |
| `bot/mcp_confined.c` | MCP pass router, ERL V3 BST, ring-0 confinement |
| `conscious/zchg_phy.c` | Phi-tau strand routing, gossip, resurrection probe |
| `conscious/phi_router.c` | EMA load balancing, FNV-1a strand affinity |

## Test with QEMU
```bash
qemu-system-x86_64 \
  -cdrom hdgl-os.iso \
  -m 8G -serial stdio -nographic \
  -cpu host -smp 4 -enable-kvm
```
Expected serial output:
```
[HDGL-OS] Frontierland REPL ready. Commands: phi ticks help halt
>
```

## REPL commands
- `phi`    — run Kuramoto lock test (shows LOCKED/unlocked)
- `ticks`  — timer tick counter (100Hz)
- `help`   — command list
- `halt`   — CLI + HLT
- anything else → forwarded to `temple2_exec_hc` (HolyC stub → Phase 2)

## Phase 2 TODO (TRI-VOICE fill zones)
- `temple2_exec_hc()` → wire real HolyC compiler pipeline (Copilot)
- `mcp_infer_qwen()` → GGUF loader for Qwen3.5-9B ring-0 inference (Qwen)
- HMAC-SHA256 in `zchg_phy.c` (Claude/Copilot)

## Phase 3 TODO
- Intel I350/X540 NIC MMIO driver in `zchg_phy.c`
- CHG Coin ETH light client (park() events for node discovery)
