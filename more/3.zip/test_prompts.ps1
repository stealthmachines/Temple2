# test_prompts.ps1 — ZCHG daemon end-to-end test
# Run on Windows where Ollama is serving on :11434
# Usage: .\test_prompts.ps1
# Requires: the ZCHG daemon running (start.bat), or just Ollama directly via -DirectOllama

param(
    [switch]$DirectOllama,
    [string]$DaemonUrl  = "http://127.0.0.1:8080",
    [string]$OllamaUrl  = "http://127.0.0.1:11434",
    [string]$Model      = "qwen3.5:9b"
)

$target = if ($DirectOllama) { "$OllamaUrl/v1/chat/completions" } `
          else                { "$DaemonUrl/v1/chat/completions" }

$prompts = @(
    "What is phi (the golden ratio) and why does it appear in nature?",
    "Explain HDGL strand routing in one sentence.",
    "What is consciousness?"
)

Write-Host ""
Write-Host "ZCHG phi-routing test" -ForegroundColor Cyan
Write-Host "Target: $target" -ForegroundColor DarkGray
Write-Host "Model:  $Model"  -ForegroundColor DarkGray
Write-Host ""

# Check health (daemon mode only)
if (-not $DirectOllama) {
    try {
        $h = Invoke-RestMethod "$DaemonUrl/health" -TimeoutSec 3
        Write-Host "Daemon health: $h" -ForegroundColor Green
        $s = Invoke-RestMethod "$DaemonUrl/status" -TimeoutSec 3
        Write-Host "Uptime: $($s.uptime_sec)s  Peers: $($s.peers)  Phi: $($s.phi)" -ForegroundColor DarkGray
    } catch {
        Write-Host "Daemon not reachable at $DaemonUrl — start with start.bat first" -ForegroundColor Red
        exit 1
    }
    Write-Host ""
}

foreach ($prompt in $prompts) {
    Write-Host ("=" * 70) -ForegroundColor DarkGray
    Write-Host "PROMPT: $prompt" -ForegroundColor Yellow
    Write-Host ""

    $body = @{
        model    = $Model
        stream   = $false
        messages = @(@{ role = "user"; content = $prompt })
    } | ConvertTo-Json -Depth 5

    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $resp = Invoke-RestMethod $target `
            -Method POST `
            -ContentType "application/json" `
            -Body $body `
            -TimeoutSec 300

        $sw.Stop()
        $elapsed = [math]::Round($sw.Elapsed.TotalSeconds, 1)

        # Extract content from OpenAI-format response
        $content = $resp.choices[0].message.content
        if (-not $content) { $content = $resp | ConvertTo-Json -Depth 10 }

        # Show route if daemon returned it (error path exposes phi/route)
        if ($resp.route) {
            Write-Host "Route: $($resp.route)  phi: $($resp.phi)" -ForegroundColor Magenta
        }

        Write-Host "RESPONSE ($($elapsed)s):" -ForegroundColor Green
        Write-Host $content
    } catch {
        $sw.Stop()
        Write-Host "ERROR ($([math]::Round($sw.Elapsed.TotalSeconds,1))s): $_" -ForegroundColor Red
    }
    Write-Host ""
}

Write-Host ("=" * 70) -ForegroundColor DarkGray
Write-Host "Done." -ForegroundColor Cyan
