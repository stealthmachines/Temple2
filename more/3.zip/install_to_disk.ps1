# install_to_disk.ps1 -- Write HDGL-OS ISO to physical disk
# Run as Administrator in PowerShell:
#   cd "C:\Users\Owner\Documents\Josef's Code 2026\KISS HDGL Bot"
#   .\install_to_disk.ps1

$DiskNumber  = 4
$ExpectedGB  = 14.88
$ToleranceGB = 0.5
$ISO = Join-Path $PSScriptRoot "hdgl-os-serial-bridge.iso"

# -- 1. Verify the disk -------------------------------------------------------
$disk = Get-Disk -Number $DiskNumber -ErrorAction Stop
$actualGB = [math]::Round($disk.Size / 1GB, 2)

Write-Host ""
Write-Host ("Disk ${DiskNumber}:") -ForegroundColor Cyan
Write-Host ("  Name  : $($disk.FriendlyName)")
Write-Host ("  Size  : $actualGB GB")
Write-Host ("  Bus   : $($disk.BusType)")
Write-Host ("  Status: $($disk.OperationalStatus)")
Write-Host ""

if ([math]::Abs($actualGB - $ExpectedGB) -gt $ToleranceGB) {
    Write-Host ("ERROR: Expected ~$ExpectedGB GB, found $actualGB GB.") -ForegroundColor Red
    Write-Host "Aborting -- wrong disk." -ForegroundColor Red
    exit 1
}
Write-Host ("Size check PASSED ($actualGB GB ≈ $ExpectedGB GB)") -ForegroundColor Green

# -- 2. Confirm ---------------------------------------------------------------
Write-Host ""
Write-Host ("WARNING: ALL DATA on Disk $DiskNumber will be overwritten.") -ForegroundColor Yellow
$confirm = Read-Host "Type YES to continue"
if ($confirm -ne "YES") { Write-Host "Aborted."; exit 0 }

# -- 3. Take disk offline so Windows releases handles -------------------------
Write-Host "Taking disk offline..."
Set-Disk -Number $DiskNumber -IsOffline $true  -ErrorAction SilentlyContinue
Set-Disk -Number $DiskNumber -IsReadOnly $false -ErrorAction SilentlyContinue

# -- 4. Write ISO to raw physical disk ----------------------------------------
$isoBytes = [System.IO.File]::ReadAllBytes($ISO)
$isoKB    = [math]::Round($isoBytes.Length / 1KB, 1)
Write-Host ("Writing " + $isoKB + " KB ISO to \\.\PhysicalDrive" + $DiskNumber + " ...")

$dev    = ("\\.\PhysicalDrive" + $DiskNumber)
$stream = [System.IO.File]::OpenWrite($dev)
$stream.Write($isoBytes, 0, $isoBytes.Length)
$stream.Flush()
$stream.Close()

Write-Host "Write complete." -ForegroundColor Green

# -- 5. Bring disk back online ------------------------------------------------
Set-Disk -Number $DiskNumber -IsOffline $false -ErrorAction SilentlyContinue

Write-Host ""
Write-Host ("Done. Disk " + $DiskNumber + " is now bootable with HDGL-OS.") -ForegroundColor Cyan
Write-Host ""
Write-Host "Test in QEMU (run as Administrator):"
Write-Host ("  qemu-system-x86_64 -hda \\.\PhysicalDrive" + $DiskNumber + " -m 256M -serial stdio -serial tcp:127.0.0.1:9001 -nographic")
Write-Host ""
Write-Host "Or set Disk 4 as the boot device in BIOS/UEFI."
