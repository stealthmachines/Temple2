@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul

:: ZCHG Bot test — hits Ollama directly, shows phi-route + actual LLM output
:: Requires: Ollama running on :11434 with a model loaded
:: Usage:    double-click, or:  test_bot.bat [MODEL]

set MODEL=%~1
if "%MODEL%"=="" set MODEL=qwen3.5:9b

set OLLAMA=http://127.0.0.1:11434/v1/chat/completions
set OUTFILE=%TEMP%\zchg_resp.json

echo.
echo ZCHG phi-routing bot test
echo Model: %MODEL%
echo Ollama: %OLLAMA%
echo.

:: Check Ollama is up
curl -sf http://127.0.0.1:11434/api/tags >nul 2>&1
if errorlevel 1 (
    echo ERROR: Ollama not reachable on :11434
    echo Run:   ollama serve
    pause & exit /b 1
)
echo Ollama: OK
echo.

:: ── Prompt 1 ─────────────────────────────────────────────────────────────
call :run_prompt "What is phi, the golden ratio, and why does it appear in nature?" "P1"

:: ── Prompt 2 ─────────────────────────────────────────────────────────────
call :run_prompt "Explain HDGL strand routing in one sentence." "P2"

:: ── Prompt 3 ─────────────────────────────────────────────────────────────
call :run_prompt "What is consciousness?" "P3"

echo.
echo Done.
pause
exit /b 0

:: ── Subroutine ────────────────────────────────────────────────────────────
:run_prompt
set PROMPT=%~1
set TAG=%~2

echo ============================================================
echo PROMPT: %PROMPT%
echo.

:: Build JSON body — escape double quotes inside prompt with \"
set BODY={"model":"%MODEL%","stream":false,"messages":[{"role":"user","content":"%PROMPT%"}]}

curl -s -X POST "%OLLAMA%" ^
     -H "Content-Type: application/json" ^
     -d "%BODY%" ^
     --max-time 300 ^
     -o "%OUTFILE%"

if errorlevel 1 (
    echo ERROR: curl failed
    echo.
    goto :eof
)

:: Extract content field — PowerShell one-liner (available on Win10+)
for /f "delims=" %%C in ('powershell -NoProfile -Command ^
    "(Get-Content '%OUTFILE%' -Raw | ConvertFrom-Json).choices[0].message.content"') do (
    echo RESPONSE: %%C
)

echo.
goto :eof
