/*
 * zchg_main.c - ZCHG v0.6 Main Entry Point
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <pthread.h>

#include "zchg_core.h"
#include "zchg_transport.h"
#include "zchg_lattice.h"

/* Serial bridge thread — defined in zchg_http.c (shares static LLM helpers) */
void *zchg_serial_bridge_run(void *arg);

static zchg_transport_server_t *g_server = NULL;
static zchg_event_loop_t       *g_loop   = NULL;
static volatile int             g_running = 1;

void zchg_handle_sigterm(int sig) {
    (void)sig;
    fprintf(stderr, "[ZCHG] SIGTERM received, shutting down...\n");
    g_running = 0;
    if (g_loop) zchg_event_loop_break(g_loop);
}

void zchg_handle_sighup(int sig) {
    (void)sig;
    fprintf(stderr, "[ZCHG] SIGHUP received, reloading config...\n");
}

int zchg_load_config(zchg_config_t *cfg) {
    const char *local_node     = getenv("LN_LOCAL_NODE");
    const char *cluster_secret = getenv("LN_CLUSTER_SECRET");

    if (!local_node)     { fprintf(stderr, "Error: LN_LOCAL_NODE not set\n");     return -1; }
    if (!cluster_secret) { fprintf(stderr, "Error: LN_CLUSTER_SECRET not set\n"); return -1; }

    cfg->local_node_ip   = (char *)local_node;
    cfg->cluster_secret  = (char *)cluster_secret;
    cfg->dry_run         = 0;
    cfg->simulation_mode = getenv("LN_SIMULATION") ? atoi(getenv("LN_SIMULATION")) : 0;
    return 0;
}

int zchg_init(void) {
    zchg_config_t config;
    memset(&config, 0, sizeof(config));
    if (zchg_load_config(&config) != 0) return -1;

    g_server = zchg_server_create(&config);
    if (!g_server) { fprintf(stderr, "Error: Failed to create server\n"); return -1; }

    g_loop = zchg_event_loop_create();
    if (!g_loop) {
        fprintf(stderr, "Error: Failed to create event loop\n");
        zchg_server_destroy(g_server);
        return -1;
    }

    if (zchg_server_listen(g_server, g_loop) != 0) {
        fprintf(stderr, "Error: Failed to start listening\n");
        zchg_event_loop_destroy(g_loop);
        zchg_server_destroy(g_server);
        return -1;
    }
    return 0;
}

int main(int argc, char *argv[]) {
    (void)argc; (void)argv;

    signal(SIGTERM, zchg_handle_sigterm);
    signal(SIGINT,  zchg_handle_sigterm);
    signal(SIGHUP,  zchg_handle_sighup);

    printf("ZCHG v0.6 — Pure C HDGL Daemon\n");
    printf("Initializing...\n");

    /* Serial bridge: always start; listens on LN_SERIAL_PORT (default 9001).
     * QEMU connects COM1 to this port via: -serial tcp:127.0.0.1:9001
     * Hotswap model by changing LN_OLLAMA_MODEL and restarting daemon only. */
    pthread_t serial_tid;
    if (pthread_create(&serial_tid, NULL, zchg_serial_bridge_run, NULL) == 0) {
        pthread_detach(serial_tid);
    }

    if (zchg_init() != 0) {
        fprintf(stderr, "Error: Initialization failed\n");
        return 1;
    }

    char local_ip_text[64];
    struct in_addr addr;
    addr.s_addr = g_server->local_ip;
    snprintf(local_ip_text, sizeof(local_ip_text), "%s", inet_ntoa(addr));
    printf("HTTP  : http://%s:%d\n", local_ip_text, g_server->port);
    printf("Serial: tcp://127.0.0.1:%s (QEMU COM1 bridge)\n",
           getenv("LN_SERIAL_PORT") ? getenv("LN_SERIAL_PORT") : "9001");
    printf("Ollama: %s:%s model=%s\n",
           getenv("LN_OLLAMA_HOST") ? getenv("LN_OLLAMA_HOST") : "127.0.0.1",
           getenv("LN_OLLAMA_PORT") ? getenv("LN_OLLAMA_PORT") : "11434",
           getenv("LN_OLLAMA_MODEL") ? getenv("LN_OLLAMA_MODEL") : "qwen3.5:9b");
    printf("Waiting for connections...\n");

    if (zchg_event_loop_run(g_loop) != 0) {
        fprintf(stderr, "Error: Event loop failed\n");
    }

    printf("\nShutting down...\n");
    zchg_event_loop_destroy(g_loop);
    zchg_server_destroy(g_server);
    printf("Goodbye.\n");
    return 0;
}

/* ---- Server stub --------------------------------------------------------- */

zchg_transport_server_t *zchg_server_create(zchg_config_t *cfg) {
    zchg_transport_server_t *server =
        (zchg_transport_server_t *)malloc(sizeof(*server));
    if (!server) return NULL;
    memset(server, 0, sizeof(*server));

    server->cluster_secret = cfg->cluster_secret;
    server->secret_len     = strlen(cfg->cluster_secret);
    server->port = getenv("LN_HTTP_PORT")
                 ? (uint16_t)atoi(getenv("LN_HTTP_PORT")) : 8080;
    if (server->port == 0) server->port = 8080;

    server->local_ip              = inet_addr(cfg->local_node_ip);
    server->lattice.local_ip      = server->local_ip;
    server->lattice.port          = server->port;
    server->started_at            = time(NULL);

    for (uint8_t s = 0; s < zchg_STRAND_COUNT; s++) {
        server->lattice.my_strands[s].strand_id       = s;
        server->lattice.my_strands[s].authority_weight = 1;
        server->lattice.my_strands[s].latency_ema     = 50.0;
    }
    return server;
}

void zchg_server_destroy(zchg_transport_server_t *server) {
    if (server) free(server);
}
