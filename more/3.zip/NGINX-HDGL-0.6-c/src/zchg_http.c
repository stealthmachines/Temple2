/* Enable POSIX extensions (getaddrinfo, struct addrinfo, etc.) */
#define _POSIX_C_SOURCE 200809L

/*
 * zchg_http.c - Native HTTP Server for ZCHG v0.6-c
 *
 * This file replaces NGINX for the ZCHG front door.
 *
 * Features:
 * - Native HTTP/1.1 server in pure C
 * - Non-blocking sockets + select()-based event loop
 * - Keep-alive and basic request pipelining
 * - Strand-aware routing for /serve/ paths
 * - Direct ZCHG endpoints: /health, /metrics, /node_info, /strand_map
 * - Binary ZCHG frame handlers for gossip and fetch operations
 */

#include "zchg_transport.h"
#include "zchg_lattice.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <netdb.h>
#include <math.h>
#include <openssl/hmac.h>

#ifndef zchg_HTTP_MAX_CONNECTIONS
#define zchg_HTTP_MAX_CONNECTIONS   1024
#endif

#ifndef zchg_HTTP_READ_BUF
#define zchg_HTTP_READ_BUF          8192
#endif

#ifndef zchg_HTTP_RESPONSE_MAX
#define zchg_HTTP_RESPONSE_MAX      262144
#endif

#ifndef zchg_HTTP_METHOD_MAX
#define zchg_HTTP_METHOD_MAX        8
#endif

#ifndef zchg_HTTP_PATH_MAX
#define zchg_HTTP_PATH_MAX          1024
#endif

#ifndef zchg_HTTP_VERSION_MAX
#define zchg_HTTP_VERSION_MAX       16
#endif

typedef enum {
    zchg_HTTP_CONN_FREE = 0,
    zchg_HTTP_CONN_READING,
    zchg_HTTP_CONN_WRITING
} zchg_http_conn_state_t;

typedef struct {
    int                     fd;
    zchg_http_conn_state_t  state;
    char                    read_buf[zchg_HTTP_READ_BUF];
    size_t                  read_len;
    char                   *write_buf;
    size_t                  write_len;
    size_t                  write_sent;
    char                    method[zchg_HTTP_METHOD_MAX];
    char                    path[zchg_HTTP_PATH_MAX];
    char                    version[zchg_HTTP_VERSION_MAX];
    size_t                  content_length;
    size_t                  body_offset;
    int                     keep_alive;
} zchg_http_connection_t;

struct zchg_event_loop {
    zchg_transport_server_t   *server;
    int                        running;
    zchg_http_connection_t     connections[zchg_HTTP_MAX_CONNECTIONS];
};

/* ========================================================================== */
/* Utility Helpers                                                           */
/* ========================================================================== */

static int zchg_http_set_nonblocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) {
        return -1;
    }
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

static uint16_t __attribute__((unused)) zchg_http_port_from_env(void) {
    const char *port_text = getenv("LN_HTTP_PORT");
    if (!port_text || *port_text == '\0') {
        return 8080;
    }

    long port = strtol(port_text, NULL, 10);
    if (port < 1 || port > 65535) {
        return 8080;
    }

    return (uint16_t)port;
}

static void zchg_http_reset_response(zchg_http_connection_t *conn) {
    if (conn->write_buf) {
        free(conn->write_buf);
        conn->write_buf = NULL;
    }
    conn->write_len = 0;
    conn->write_sent = 0;
}

static void zchg_http_reset_connection(zchg_http_connection_t *conn) {
    zchg_http_reset_response(conn);
    conn->read_len = 0;
    conn->method[0] = '\0';
    conn->path[0] = '\0';
    conn->version[0] = '\0';
    conn->content_length = 0;
    conn->body_offset = 0;
    conn->keep_alive = 0;
}

static void zchg_http_close_connection(struct zchg_event_loop *loop, zchg_http_connection_t *conn) {
    if (conn->fd >= 0) {
        close(conn->fd);
    }
    if (loop && loop->server && loop->server->active_connections > 0) {
        loop->server->active_connections -= 1;
    }
    conn->fd = -1;
    conn->state = zchg_HTTP_CONN_FREE;
    zchg_http_reset_connection(conn);
}

static zchg_http_connection_t *zchg_http_find_connection(struct zchg_event_loop *loop, int fd) {
    if (fd < 0 || fd >= zchg_HTTP_MAX_CONNECTIONS) {
        return NULL;
    }

    zchg_http_connection_t *conn = &loop->connections[fd];
    if (conn->state == zchg_HTTP_CONN_FREE) {
        return NULL;
    }

    return conn;
}

static zchg_http_connection_t *zchg_http_acquire_connection(struct zchg_event_loop *loop, int fd) {
    if (fd < 0 || fd >= zchg_HTTP_MAX_CONNECTIONS) {
        return NULL;
    }

    zchg_http_connection_t *conn = &loop->connections[fd];
    memset(conn, 0, sizeof(*conn));
    conn->fd = fd;
    conn->state = zchg_HTTP_CONN_READING;
    return conn;
}

static int __attribute__((unused)) zchg_http_socket_write(int fd, const char *buf, size_t len) {
    size_t written = 0;
    while (written < len) {
        ssize_t rc = send(fd, buf + written, len - written, 0);
        if (rc < 0) {
            if (errno == EINTR) {
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return (int)written;
            }
            return -1;
        }
        if (rc == 0) {
            break;
        }
        written += (size_t)rc;
    }
    return (int)written;
}

static const char *zchg_http_status_text(int status_code) {
    switch (status_code) {
        case 200: return "OK";
        case 204: return "No Content";
        case 401: return "Unauthorized";
        case 403: return "Forbidden";
        case 400: return "Bad Request";
        case 404: return "Not Found";
        case 405: return "Method Not Allowed";
        case 413: return "Payload Too Large";
        case 426: return "Upgrade Required";
        case 431: return "Request Header Fields Too Large";
        case 500: return "Internal Server Error";
        case 503: return "Service Unavailable";
        default:  return "OK";
    }
}

static const char *zchg_http_content_type_from_path(const char *path) {
    if (strstr(path, ".json") != NULL) return "application/json";
    if (strstr(path, ".html") != NULL) return "text/html; charset=utf-8";
    if (strstr(path, ".css") != NULL) return "text/css; charset=utf-8";
    if (strstr(path, ".js") != NULL) return "application/javascript";
    if (strstr(path, ".txt") != NULL) return "text/plain; charset=utf-8";
    if (strstr(path, ".png") != NULL) return "image/png";
    if (strstr(path, ".jpg") != NULL || strstr(path, ".jpeg") != NULL) return "image/jpeg";
    return "application/octet-stream";
}

static int zchg_http_build_response(zchg_http_connection_t *conn,
                                    int status_code,
                                    const char *content_type,
                                    const char *body,
                                    size_t body_len,
                                    int keep_alive) {
    static const char *server_name = "ZCHG-C/0.6";
    const char *status_text = zchg_http_status_text(status_code);
    const char *connection_text = keep_alive ? "keep-alive" : "close";

    char header[1024];
    int header_len = snprintf(
        header,
        sizeof(header),
        "HTTP/1.1 %d %s\r\n"
        "Server: %s\r\n"
        "Content-Type: %s\r\n"
        "Content-Length: %zu\r\n"
        "Connection: %s\r\n"
        "X-ZCHG-Scheme: zchg://\r\n"
        "X-ZCHG-Mode: native-c\r\n"
        "\r\n",
        status_code,
        status_text,
        server_name,
        content_type,
        body_len,
        connection_text
    );

    if (header_len < 0) {
        return -1;
    }

    size_t total_len = (size_t)header_len + body_len;
    char *response = (char *)malloc(total_len);
    if (!response) {
        return -1;
    }

    memcpy(response, header, (size_t)header_len);
    if (body_len > 0 && body != NULL) {
        memcpy(response + header_len, body, body_len);
    }

    zchg_http_reset_response(conn);
    conn->write_buf = response;
    conn->write_len = total_len;
    conn->write_sent = 0;
    conn->keep_alive = keep_alive;
    conn->state = zchg_HTTP_CONN_WRITING;

    return 0;
}

static const char *zchg_http_find_header_value(const char *headers, const char *header_name) {
    size_t header_name_len = strlen(header_name);
    const char *cursor = headers;

    while (*cursor != '\0') {
        const char *line_end = strstr(cursor, "\r\n");
        if (!line_end) {
            /* Last header line has no trailing \r\n in header_copy — check it directly */
            if (strncasecmp(cursor, header_name, header_name_len) == 0 &&
                cursor[header_name_len] == ':') {
                const char *value = cursor + header_name_len + 1;
                while (*value == ' ' || *value == '\t') { value++; }
                return value;
            }
            break;
        }

        if ((size_t)(line_end - cursor) >= header_name_len + 1) {
            if (strncasecmp(cursor, header_name, header_name_len) == 0 && cursor[header_name_len] == ':') {
                const char *value = cursor + header_name_len + 1;
                while (*value == ' ' || *value == '\t') {
                    value++;
                }
                return value;
            }
        }

        cursor = line_end + 2;
        if (cursor[0] == '\r' && cursor[1] == '\n') {
            break;
        }
    }

    return NULL;
}

static size_t zchg_http_header_value_length(const char *value) {
    const char *end = value;
    while (*end != '\0' && *end != '\r' && *end != '\n') {
        end++;
    }
    return (size_t)(end - value);
}

static void zchg_http_copy_trunc(char *dst, size_t dst_cap, const char *src) {
    if (!dst || dst_cap == 0) {
        return;
    }

    if (!src) {
        dst[0] = '\0';
        return;
    }

    size_t n = strlen(src);
    if (n >= dst_cap) {
        n = dst_cap - 1;
    }

    memcpy(dst, src, n);
    dst[n] = '\0';
}

static int zchg_http_parse_request(zchg_http_connection_t *conn, size_t *out_consumed) {
    char *header_end = NULL;
    if (conn->read_len < 4) {
        return 0;
    }

    for (size_t i = 0; i + 3 < conn->read_len; i++) {
        if (conn->read_buf[i] == '\r' && conn->read_buf[i + 1] == '\n' &&
            conn->read_buf[i + 2] == '\r' && conn->read_buf[i + 3] == '\n') {
            header_end = &conn->read_buf[i];
            break;
        }
    }

    if (!header_end) {
        if (conn->read_len >= zchg_HTTP_READ_BUF - 1) {
            return -2;
        }
        return 0;
    }

    size_t header_len = (size_t)(header_end - conn->read_buf);
    char header_copy[zchg_HTTP_READ_BUF];
    if (header_len >= sizeof(header_copy)) {
        return -2;
    }

    memcpy(header_copy, conn->read_buf, header_len);
    header_copy[header_len] = '\0';

    char *line_end = strstr(header_copy, "\r\n");
    if (!line_end) {
        return -1;
    }
    *line_end = '\0';

    char version[zchg_HTTP_VERSION_MAX] = {0};
    char target[zchg_HTTP_PATH_MAX] = {0};
    if (sscanf(header_copy, "%7s %1023s %15s", conn->method, target, version) != 3) {
        return -1;
    }

    zchg_http_copy_trunc(conn->version, sizeof(conn->version), version);

    if (strncmp(target, "zchg://", 7) == 0 || strncmp(target, "zchg://", 7) == 0) {
        const char *path_start = strchr(target + 7, '/');
        if (path_start) {
            zchg_http_copy_trunc(conn->path, sizeof(conn->path), path_start);
        } else {
            zchg_http_copy_trunc(conn->path, sizeof(conn->path), "/");
        }
    } else {
        zchg_http_copy_trunc(conn->path, sizeof(conn->path), target);
    }

    const char *header_lines = line_end + 2;
    const char *content_length_text = zchg_http_find_header_value(header_lines, "Content-Length");
    const char *connection_text = zchg_http_find_header_value(header_lines, "Connection");

    conn->content_length = 0;
    if (content_length_text) {
        conn->content_length = (size_t)strtoull(content_length_text, NULL, 10);
    }

    if (connection_text) {
        size_t connection_len = zchg_http_header_value_length(connection_text);
        if (connection_len == 5 && strncasecmp(connection_text, "close", 5) == 0) {
            conn->keep_alive = 0;
        } else if (connection_len == 10 && strncasecmp(connection_text, "keep-alive", 10) == 0) {
            conn->keep_alive = 1;
        }
    } else {
        conn->keep_alive = (strcmp(conn->version, "HTTP/1.1") == 0);
    }

    size_t request_len = header_len + 4 + conn->content_length;
    if (conn->read_len < request_len) {
        return 0;
    }

    conn->body_offset = header_len + 4;
    *out_consumed = request_len;
    return 1;
}

static void zchg_http_consume_bytes(zchg_http_connection_t *conn, size_t consumed) {
    if (consumed >= conn->read_len) {
        conn->read_len = 0;
        return;
    }

    size_t remaining = conn->read_len - consumed;
    memmove(conn->read_buf, conn->read_buf + consumed, remaining);
    conn->read_len = remaining;
}

static void zchg_http_append_body(char *body, size_t body_cap, size_t *body_len, const char *fmt, ...) {
    if (*body_len >= body_cap) {
        return;
    }

    va_list args;
    va_start(args, fmt);
    int written = vsnprintf(body + *body_len, body_cap - *body_len, fmt, args);
    va_end(args);

    if (written < 0) {
        return;
    }

    size_t appended = (size_t)written;
    if (*body_len + appended >= body_cap) {
        *body_len = body_cap - 1;
        body[body_cap - 1] = '\0';
        return;
    }

    *body_len += appended;
}

static void zchg_http_ip_to_text(uint32_t ip_addr, char *out, size_t out_len) {
    struct in_addr addr;
    addr.s_addr = ip_addr;
    const char *text = inet_ntoa(addr);
    if (!text) {
        snprintf(out, out_len, "0.0.0.0");
        return;
    }
    snprintf(out, out_len, "%s", text);
}

static int zchg_http_peer_ip_from_fd(int fd, uint32_t *out_ip) {
    if (fd < 0 || !out_ip) {
        return -1;
    }

    struct sockaddr_in peer_addr;
    socklen_t peer_len = sizeof(peer_addr);
    memset(&peer_addr, 0, sizeof(peer_addr));

    if (getpeername(fd, (struct sockaddr *)&peer_addr, &peer_len) != 0) {
        return -1;
    }

    if (peer_addr.sin_family != AF_INET) {
        return -1;
    }

    *out_ip = peer_addr.sin_addr.s_addr;
    return 0;
}

static uint64_t zchg_http_uptime_seconds(const zchg_transport_server_t *server) {
    if (!server->started_at) {
        return 0;
    }
    time_t now = time(NULL);
    if (now < server->started_at) {
        return 0;
    }
    return (uint64_t)(now - server->started_at);
}

static int zchg_http_response_health(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    (void)server;
    return zchg_http_build_response(conn, 200, "text/plain; charset=utf-8", "ok\n", 3, conn->keep_alive);
}

static int zchg_http_response_metrics(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    zchg_metrics_t metrics;
    memset(&metrics, 0, sizeof(metrics));
    zchg_metrics_collect(server, &metrics);

    char body[4096];
    size_t body_len = 0;
    body[0] = '\0';

    zchg_http_append_body(body, sizeof(body), &body_len, "{\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"uptime_sec\": %llu,\n", (unsigned long long)metrics.uptime_sec);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"frames_sent\": %llu,\n", (unsigned long long)metrics.total_frames_sent);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"frames_recv\": %llu,\n", (unsigned long long)metrics.total_frames_recv);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"bytes_sent\": %llu,\n", (unsigned long long)metrics.total_bytes_sent);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"bytes_recv\": %llu,\n", (unsigned long long)metrics.total_bytes_recv);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"active_connections\": %llu,\n", (unsigned long long)metrics.active_connections);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"total_connections\": %llu,\n", (unsigned long long)metrics.total_connections);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"latency_p50_ms\": %.3f,\n", metrics.latency_p50);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"latency_p95_ms\": %.3f,\n", metrics.latency_p95);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"latency_p99_ms\": %.3f,\n", metrics.latency_p99);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"connection_reuse_ratio\": %.3f,\n", metrics.connection_reuse_ratio);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"cache_hit_ratio\": %u,\n", metrics.cache_hit_ratio);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"cache_hits\": %u,\n", server->cache_hits);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"cache_misses\": %u\n", server->cache_misses);
    zchg_http_append_body(body, sizeof(body), &body_len, "}\n");

    return zchg_http_build_response(conn, 200, "application/json", body, strlen(body), conn->keep_alive);
}

static int zchg_http_response_node_info(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    char local_ip[64];
    zchg_http_ip_to_text(server->local_ip, local_ip, sizeof(local_ip));

    char body[4096];
    size_t body_len = 0;
    body[0] = '\0';

    zchg_http_append_body(body, sizeof(body), &body_len, "{\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"local_ip\": \"%s\",\n", local_ip);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"port\": %u,\n", server->port);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"peer_count\": %u,\n", server->lattice.peer_count);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"cycle_number\": %llu,\n", (unsigned long long)server->lattice.cycle_number);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"cluster_fingerprint\": %u,\n", server->lattice.cluster_fingerprint);
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"uptime_sec\": %llu,\n", (unsigned long long)zchg_http_uptime_seconds(server));
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"strands\": [\n");

    for (uint8_t i = 0; i < zchg_STRAND_COUNT; i++) {
        char strand_ip[64];
        uint32_t authority = zchg_lattice_get_strand_authority(&server->lattice, i);
        zchg_http_ip_to_text(authority, strand_ip, sizeof(strand_ip));

        zchg_http_append_body(body, sizeof(body), &body_len,
                              "    {\"id\": %u, \"name\": \"%s\", \"authority\": \"%s\", \"weight\": %u}%s\n",
                              i,
                              zchg_STRAND_NAMES[i],
                              strand_ip,
                              server->lattice.my_strands[i].authority_weight,
                              (i + 1 < zchg_STRAND_COUNT) ? "," : "");
    }

    zchg_http_append_body(body, sizeof(body), &body_len, "  ]\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "}\n");

    return zchg_http_build_response(conn, 200, "application/json", body, strlen(body), conn->keep_alive);
}

static int zchg_http_response_strand_map(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    char body[4096];
    size_t body_len = 0;
    body[0] = '\0';

    zchg_http_append_body(body, sizeof(body), &body_len, "{\n  \"strand_map\": [\n");
    for (uint8_t i = 0; i < zchg_STRAND_COUNT; i++) {
        char authority_ip[64];
        zchg_http_ip_to_text(zchg_lattice_get_strand_authority(&server->lattice, i), authority_ip, sizeof(authority_ip));
        zchg_http_append_body(body, sizeof(body), &body_len,
                              "    {\"strand\": %u, \"name\": \"%s\", \"authority\": \"%s\"}%s\n",
                              i,
                              zchg_STRAND_NAMES[i],
                              authority_ip,
                              (i + 1 < zchg_STRAND_COUNT) ? "," : "");
    }
    zchg_http_append_body(body, sizeof(body), &body_len, "  ]\n}\n");

    return zchg_http_build_response(conn, 200, "application/json", body, strlen(body), conn->keep_alive);
}

static int zchg_http_response_protocol(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    (void)server;
    char body[4096];
    size_t body_len = 0;
    body[0] = '\0';

    zchg_http_append_body(body, sizeof(body), &body_len, "{\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"scheme\": \"zchg://\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"version\": \"0.6\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"mode\": \"native-c\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"edge\": \"native_http\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"peer_transport\": \"pooled_http\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  \"capabilities\": [\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "    \"edge-routing\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "    \"strand-authority\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "    \"peer-forwarding\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "    \"frame-upload\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "    \"gossip-ingest\",\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "    \"fileswap-serve\"\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "  ]\n");
    zchg_http_append_body(body, sizeof(body), &body_len, "}\n");

    return zchg_http_build_response(conn, 200, "application/json", body, strlen(body), conn->keep_alive);
}

static int zchg_http_read_file(const char *path, char **out_buf, size_t *out_len) {
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        return -1;
    }

    if (fseek(fp, 0, SEEK_END) != 0) {
        fclose(fp);
        return -1;
    }

    long size = ftell(fp);
    if (size < 0) {
        fclose(fp);
        return -1;
    }

    rewind(fp);

    char *buf = (char *)malloc((size_t)size);
    if (!buf) {
        fclose(fp);
        return -1;
    }

    size_t read_len = fread(buf, 1, (size_t)size, fp);
    fclose(fp);

    if (read_len != (size_t)size) {
        free(buf);
        return -1;
    }

    *out_buf = buf;
    *out_len = (size_t)size;
    return 0;
}

static int zchg_http_response_serve(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    (void)server;
    const char *relative = conn->path + strlen("/serve/");
    if (*relative == '\0') {
        return zchg_http_build_response(conn, 404, "text/plain; charset=utf-8", "not found\n", 10, conn->keep_alive);
    }

    if (strstr(relative, "..") != NULL) {
        return zchg_http_build_response(conn, 400, "text/plain; charset=utf-8", "invalid path\n", 13, conn->keep_alive);
    }

    char full_path[2048];
    snprintf(full_path, sizeof(full_path), "%s/%s", zchg_FILESWAP_ROOT, relative);

    struct stat st;
    if (stat(full_path, &st) != 0 || !S_ISREG(st.st_mode)) {
        return zchg_http_build_response(conn, 404, "text/plain; charset=utf-8", "not found\n", 10, conn->keep_alive);
    }

    char *file_buf = NULL;
    size_t file_len = 0;
    if (zchg_http_read_file(full_path, &file_buf, &file_len) != 0) {
        return zchg_http_build_response(conn, 500, "text/plain; charset=utf-8", "failed to read file\n", 20, conn->keep_alive);
    }

    const char *content_type = zchg_http_content_type_from_path(full_path);
    int rc = zchg_http_build_response(conn, 200, content_type, file_buf, file_len, conn->keep_alive);
    free(file_buf);
    return rc;
}

static int zchg_http_response_frame_upload(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    size_t body_len = conn->content_length;
    if (body_len < zchg_FRAME_HEADER_SIZE) {
        return zchg_http_build_response(conn, 400, "text/plain; charset=utf-8", "frame too small\n", 16, conn->keep_alive);
    }

    zchg_frame_t frame;
    memset(&frame, 0, sizeof(frame));
    if (zchg_frame_deserialize((uint8_t *)conn->read_buf + conn->body_offset, body_len, &frame) != 0) {
        return zchg_http_build_response(conn, 400, "text/plain; charset=utf-8", "invalid frame\n", 15, conn->keep_alive);
    }

    if (zchg_hmac_verify_frame(&frame, server->cluster_secret, server->secret_len) != 0) {
        if (frame.payload) {
            free(frame.payload);
        }
        return zchg_http_build_response(conn, 401, "text/plain; charset=utf-8", "invalid frame signature\n", 24, conn->keep_alive);
    }

    if (!zchg_timestamp_is_valid(frame.header.timestamp)) {
        if (frame.payload) {
            free(frame.payload);
        }
        return zchg_http_build_response(conn, 401, "text/plain; charset=utf-8", "stale frame timestamp\n", 22, conn->keep_alive);
    }

    uint32_t peer_ip = 0;
    if (zchg_http_peer_ip_from_fd(conn->fd, &peer_ip) == 0 &&
        frame.header.source_ip != 0 &&
        frame.header.source_ip != peer_ip) {
        if (frame.payload) {
            free(frame.payload);
        }
        return zchg_http_build_response(conn, 403, "text/plain; charset=utf-8", "source ip mismatch\n", 19, conn->keep_alive);
    }

    zchg_server_handle_frame(server, conn->fd, &frame);

    if (frame.payload) {
        free(frame.payload);
    }

    return zchg_http_build_response(conn, 204, "text/plain; charset=utf-8", "", 0, conn->keep_alive);
}

static int zchg_http_response_gossip(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    size_t body_len = conn->content_length;
    if (body_len < sizeof(zchg_gossip_msg_t)) {
        return zchg_http_build_response(conn, 400, "text/plain; charset=utf-8", "gossip payload too small\n", 25, conn->keep_alive);
    }

    zchg_gossip_msg_t msg;
    memset(&msg, 0, sizeof(msg));
    memcpy(&msg, conn->read_buf + conn->body_offset, sizeof(msg));

    uint32_t peer_ip = 0;
    if (zchg_http_peer_ip_from_fd(conn->fd, &peer_ip) == 0 &&
        msg.source_ip != 0 &&
        msg.source_ip != peer_ip) {
        return zchg_http_build_response(conn, 403, "text/plain; charset=utf-8", "gossip source mismatch\n", 23, conn->keep_alive);
    }

    zchg_lattice_apply_gossip(&server->lattice, msg.source_ip, &msg);

    return zchg_http_build_response(conn, 204, "text/plain; charset=utf-8", "", 0, conn->keep_alive);
}

static int __attribute__((unused)) zchg_http_response_health_frame(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    (void)conn;
    zchg_frame_t frame;
    memset(&frame, 0, sizeof(frame));
    return zchg_handle_health_frame(server, &frame, NULL);
}

/* ========================================================================== */
/* LLM Proxy — Phi-Routing to Ollama                                         */
/* ========================================================================== */

#define ZCHG_LLM_ROUTE_SOLO       0   /* phi < 0.382 — forward directly     */
#define ZCHG_LLM_ROUTE_RELAY      1   /* phi 0.382–0.618 — forward + note   */
#define ZCHG_LLM_ROUTE_CHALLENGE  2   /* phi > 0.618 — forward + second log */

static const char *zchg_llm_route_names[] = { "SOLO", "RELAY", "CHALLENGE" };

/* Phi-routing score derived from request body: returns value in [0, 1) */
static double zchg_llm_phi_score(const char *data, size_t len) {
    uint8_t      digest[32];
    unsigned int dlen  = 32;
    const char  *key   = "zchg-phi-router";
    HMAC(EVP_sha256(), key, (int)strlen(key),
         (const unsigned char *)data, len, digest, &dlen);
    uint32_t h = ((uint32_t)digest[0] << 24) | ((uint32_t)digest[1] << 16)
               | ((uint32_t)digest[2] <<  8) |  (uint32_t)digest[3];
    double raw = ((double)h / (double)0xFFFFFFFFU) * zchg_PHI;
    return raw - floor(raw);
}

static int zchg_llm_classify(double phi) {
    if (phi < 0.382) return ZCHG_LLM_ROUTE_SOLO;
    if (phi < 0.618) return ZCHG_LLM_ROUTE_RELAY;
    return ZCHG_LLM_ROUTE_CHALLENGE;
}

/* Blocking TCP connect to host:port. Returns fd, or -1 on failure. */
static int zchg_llm_tcp_connect(const char *host, uint16_t port) {
    struct addrinfo hints, *res;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    char port_str[16];
    snprintf(port_str, sizeof(port_str), "%u", port);
    if (getaddrinfo(host, port_str, &hints, &res) != 0) return -1;
    int fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0) { freeaddrinfo(res); return -1; }
    /* 90-second timeout — first inference after boot can be slow */
    struct timeval tv = { .tv_sec = 90, .tv_usec = 0 };
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    if (connect(fd, res->ai_addr, res->ai_addrlen) != 0) {
        close(fd); freeaddrinfo(res); return -1;
    }
    freeaddrinfo(res);
    return fd;
}

/* Proxy req_body to host:port/path (HTTP POST). Returns malloc'd body or NULL. */
static char *zchg_llm_proxy(const char *host, uint16_t port, const char *path,
                              const char *req_body, size_t req_body_len,
                              size_t *out_len, int *out_status) {
    *out_len    = 0;
    *out_status = 502;

    int fd = zchg_llm_tcp_connect(host, port);
    if (fd < 0) return NULL;

    /* Send request */
    char hdr[1024];
    int hlen = snprintf(hdr, sizeof(hdr),
        "POST %s HTTP/1.1\r\n"
        "Host: %s:%u\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: %zu\r\n"
        "Connection: close\r\n"
        "\r\n",
        path, host, port, req_body_len);
    if (hlen <= 0) { close(fd); return NULL; }
    send(fd, hdr, (size_t)hlen, 0);
    if (req_body && req_body_len > 0)
        send(fd, req_body, req_body_len, 0);

    /* Read full response into growing buffer */
    size_t cap = 131072, used = 0;
    char *buf = malloc(cap);
    if (!buf) { close(fd); return NULL; }
    while (1) {
        if (used + 4096 >= cap) {
            cap *= 2;
            char *t = realloc(buf, cap);
            if (!t) { free(buf); close(fd); return NULL; }
            buf = t;
        }
        ssize_t n = recv(fd, buf + used, cap - used - 1, 0);
        if (n <= 0) break;
        used += (size_t)n;
    }
    close(fd);
    buf[used] = '\0';

    /* Parse HTTP status line */
    int status = 200;
    sscanf(buf, "HTTP/%*s %d", &status);
    *out_status = status;

    /* Locate body after header block */
    char *body_ptr = strstr(buf, "\r\n\r\n");
    if (!body_ptr) { free(buf); return NULL; }
    body_ptr += 4;
    size_t body_len = used - (size_t)(body_ptr - buf);

    char *result = malloc(body_len + 1);
    if (!result) { free(buf); return NULL; }
    memcpy(result, body_ptr, body_len);
    result[body_len] = '\0';
    *out_len = body_len;
    free(buf);
    return result;
}

/* Read a file into a malloc'd buffer. Caller frees. Returns NULL on error. */
static char *zchg_read_file_alloc(const char *path, size_t *out_len) {
    FILE *fp = fopen(path, "rb");
    if (!fp) return NULL;
    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); return NULL; }
    long sz = ftell(fp);
    rewind(fp);
    if (sz <= 0) { fclose(fp); return NULL; }
    char *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(fp); return NULL; }
    size_t n = fread(buf, 1, (size_t)sz, fp);
    fclose(fp);
    buf[n] = '\0';
    *out_len = n;
    return buf;
}

/* ========================================================================== */
/* LLM JSON Helpers                                                           */
/* ========================================================================== */

/* Extract "model":"..." from a JSON blob. Caller frees. Returns NULL on error. */
static char *zchg_llm_extract_model(const char *json) {
    const char *p = strstr(json, "\"model\"");
    if (!p) return NULL;
    p += 7;
    while (*p == ' ' || *p == ':' || *p == '\t') p++;
    if (*p != '"') return NULL;
    p++;
    const char *end = strchr(p, '"');
    if (!end) return NULL;
    size_t len = (size_t)(end - p);
    char *out = malloc(len + 1);
    if (!out) return NULL;
    memcpy(out, p, len);
    out[len] = '\0';
    return out;
}

/* Extract first "content":"..." from a JSON blob (handles basic escapes).
   Caller frees. Returns NULL on error. */
static char *zchg_llm_extract_content(const char *json) {
    const char *marker = strstr(json, "\"content\":");
    if (!marker) return NULL;
    marker += strlen("\"content\":");
    while (*marker == ' ' || *marker == '\t') marker++;
    if (*marker != '"') return NULL;
    marker++;

    /* measure decoded length */
    const char *p = marker;
    size_t dlen = 0;
    while (*p && *p != '"') {
        if (*p == '\\') { p++; if (!*p) break; }
        dlen++;
        p++;
    }

    char *out = malloc(dlen + 1);
    if (!out) return NULL;
    p = marker;
    size_t i = 0;
    while (*p && *p != '"') {
        if (*p == '\\') {
            p++;
            if (!*p) break;
            switch (*p) {
                case 'n':  out[i++] = '\n'; break;
                case 't':  out[i++] = '\t'; break;
                case 'r':  out[i++] = '\r'; break;
                case '"':  out[i++] = '"';  break;
                case '\\': out[i++] = '\\'; break;
                default:   out[i++] = *p;   break;
            }
        } else {
            out[i++] = *p;
        }
        p++;
    }
    out[i] = '\0';
    return out;
}

/* JSON-escape src into dst (dst_cap must be >= 6*strlen(src)+3).
   Returns bytes written (no NUL). */
static size_t zchg_llm_json_escape(const char *src, char *dst, size_t dst_cap) {
    size_t i = 0;
    for (const char *s = src; *s && i + 8 < dst_cap; s++) {
        unsigned char c = (unsigned char)*s;
        switch (c) {
            case '"':  dst[i++] = '\\'; dst[i++] = '"';  break;
            case '\\': dst[i++] = '\\'; dst[i++] = '\\'; break;
            case '\n': dst[i++] = '\\'; dst[i++] = 'n';  break;
            case '\r': dst[i++] = '\\'; dst[i++] = 'r';  break;
            case '\t': dst[i++] = '\\'; dst[i++] = 't';  break;
            default:
                if (c < 0x20) {
                    i += (size_t)snprintf(dst + i, dst_cap - i, "\\u%04x", c);
                } else {
                    dst[i++] = (char)c;
                }
                break;
        }
    }
    dst[i] = '\0';
    return i;
}

/* Build a one-message /v1/chat/completions request body.
   model: model string (or NULL → "default")
   user_content: unescaped user turn text
   Returns malloc'd JSON, caller frees. */
static char *zchg_llm_build_single_req(const char *model, const char *user_content) {
    if (!model) model = "default";
    size_t content_len = strlen(user_content);
    size_t esc_cap     = content_len * 6 + 4;
    char  *escaped     = malloc(esc_cap);
    if (!escaped) return NULL;
    zchg_llm_json_escape(user_content, escaped, esc_cap);

    size_t out_cap = strlen(model) + strlen(escaped) + 128;
    char  *out     = malloc(out_cap);
    if (!out) { free(escaped); return NULL; }

    snprintf(out, out_cap,
        "{\"model\":\"%s\",\"stream\":false,"
        "\"messages\":[{\"role\":\"user\",\"content\":\"%s\"}]}",
        model, escaped);
    free(escaped);
    return out;
}

/* ========================================================================== */
/* LLM Proxy — Phi-Routing to Ollama                                         */
/* ========================================================================== */

/* POST /v1/chat/completions  or  POST /api/chat
 *
 * SOLO      (phi < 0.382) — single inference pass
 * RELAY     (phi 0.382–0.618) — pass 1, then pass 2 refines pass-1 output
 * CHALLENGE (phi > 0.618) — two independent passes, third eval synthesises both
 */
static int zchg_http_response_llm(zchg_transport_server_t *server,
                                   zchg_http_connection_t  *conn) {
    (void)server;

    const char *ollama_host = getenv("LN_OLLAMA_HOST");
    if (!ollama_host) ollama_host = "127.0.0.1";
    const char *port_env    = getenv("LN_OLLAMA_PORT");
    uint16_t    ollama_port = port_env ? (uint16_t)atoi(port_env) : 11434;

    const char *body     = conn->read_buf + conn->body_offset;
    size_t      body_len = conn->content_length;

    if (body_len == 0) {
        const char *err = "{\"error\":\"empty request body\"}\n";
        return zchg_http_build_response(conn, 400, "application/json",
                                         err, strlen(err), 0);
    }

    /* Phi-routing decision */
    double phi   = zchg_llm_phi_score(body, body_len);
    int    route = zchg_llm_classify(phi);
    fprintf(stderr, "[LLM] phi=%.4f route=%s bytes=%zu\n",
            phi, zchg_llm_route_names[route], body_len);

    /* Extract model name for subsequent-pass requests */
    char *model = zchg_llm_extract_model(body);   /* NULL → "default" */

    /* ── PASS 1: always forward original request ──────────────────────── */
    size_t p1_len  = 0;
    int    p1_code = 200;
    char  *p1_body = zchg_llm_proxy(ollama_host, ollama_port,
                                     "/v1/chat/completions",
                                     body, body_len,
                                     &p1_len, &p1_code);
    if (!p1_body) {
        char err[320];
        int n = snprintf(err, sizeof(err),
            "{\"error\":\"ollama unreachable\","
            "\"hint\":\"run: ollama serve\","
            "\"ollama\":\"%s:%u\","
            "\"phi\":%.4f,\"route\":\"%s\"}\n",
            ollama_host, ollama_port, phi, zchg_llm_route_names[route]);
        free(model);
        return zchg_http_build_response(conn, 503, "application/json",
                                         err, (size_t)n, 0);
    }

    char  *resp_body = NULL;
    size_t resp_len  = 0;
    int    resp_code = 200;

    if (route == ZCHG_LLM_ROUTE_SOLO) {
        /* SOLO: return pass 1 directly */
        resp_body = p1_body;
        resp_len  = p1_len;
        resp_code = p1_code;

    } else if (route == ZCHG_LLM_ROUTE_RELAY) {
        /* ── RELAY: refine pass-1 output in pass 2 ───────────────────── */
        char *p1_content = zchg_llm_extract_content(p1_body);
        free(p1_body);

        if (!p1_content) {
            free(model);
            const char *err = "{\"error\":\"relay-extract-failed\"}\n";
            return zchg_http_build_response(conn, 502, "application/json",
                                             err, strlen(err), 0);
        }

        size_t refine_cap = strlen(p1_content) + 128;
        char  *refine_prompt = malloc(refine_cap);
        if (!refine_prompt) { free(p1_content); free(model); return -1; }
        snprintf(refine_prompt, refine_cap,
            "Refine and improve the following response. "
            "Be accurate, concise, and complete:\n\n%s",
            p1_content);
        free(p1_content);

        char *req2 = zchg_llm_build_single_req(model, refine_prompt);
        free(refine_prompt);
        if (!req2) { free(model); return -1; }

        size_t p2_len  = 0;
        int    p2_code = 200;
        char  *p2_body = zchg_llm_proxy(ollama_host, ollama_port,
                                         "/v1/chat/completions",
                                         req2, strlen(req2),
                                         &p2_len, &p2_code);
        free(req2);

        if (!p2_body) {
            free(model);
            const char *err = "{\"error\":\"relay-pass2-failed\"}\n";
            return zchg_http_build_response(conn, 503, "application/json",
                                             err, strlen(err), 0);
        }
        resp_body = p2_body;
        resp_len  = p2_len;
        resp_code = p2_code;

    } else {
        /* ── CHALLENGE: two independent passes → eval synthesis ──────── */
        /* Pass A is p1_body already. Send pass B (same original body). */
        size_t pb_len  = 0;
        int    pb_code = 200;
        char  *pb_body = zchg_llm_proxy(ollama_host, ollama_port,
                                         "/v1/chat/completions",
                                         body, body_len,
                                         &pb_len, &pb_code);
        if (!pb_body) {
            /* B failed — degrade to pass A */
            resp_body = p1_body;
            resp_len  = p1_len;
            resp_code = p1_code;
        } else {
            char *ca = zchg_llm_extract_content(p1_body);
            char *cb = zchg_llm_extract_content(pb_body);
            free(p1_body);
            free(pb_body);

            if (!ca || !cb) {
                free(ca); free(cb); free(model);
                const char *err = "{\"error\":\"challenge-extract-failed\"}\n";
                return zchg_http_build_response(conn, 502, "application/json",
                                                 err, strlen(err), 0);
            }

            size_t eval_cap = strlen(ca) + strlen(cb) + 256;
            char  *eval_prompt = malloc(eval_cap);
            if (!eval_prompt) { free(ca); free(cb); free(model); return -1; }
            snprintf(eval_prompt, eval_cap,
                "Two independent responses were generated to the same prompt. "
                "Evaluate both and synthesise the most accurate, complete answer:\n\n"
                "Response A:\n%s\n\n"
                "Response B:\n%s\n\n"
                "Synthesised answer:",
                ca, cb);
            free(ca); free(cb);

            char *req_eval = zchg_llm_build_single_req(model, eval_prompt);
            free(eval_prompt);
            if (!req_eval) { free(model); return -1; }

            size_t re_len  = 0;
            int    re_code = 200;
            char  *eval_body = zchg_llm_proxy(ollama_host, ollama_port,
                                               "/v1/chat/completions",
                                               req_eval, strlen(req_eval),
                                               &re_len, &re_code);
            free(req_eval);

            if (!eval_body) {
                free(model);
                const char *err = "{\"error\":\"challenge-eval-failed\"}\n";
                return zchg_http_build_response(conn, 503, "application/json",
                                                 err, strlen(err), 0);
            }
            resp_body = eval_body;
            resp_len  = re_len;
            resp_code = re_code;
        }
    }

    free(model);
    int rc = zchg_http_build_response(conn, resp_code, "application/json",
                                       resp_body, resp_len, 0);
    free(resp_body);
    return rc;
}

/* GET /status — phi-aware liveness / stack info */
static int zchg_http_response_status(zchg_transport_server_t *server,
                                      zchg_http_connection_t  *conn) {
    char body[512];
    int n = snprintf(body, sizeof(body),
        "{\"status\":\"ok\","
        "\"daemon\":\"zchg-c/0.6\","
        "\"phi\":%.10f,"
        "\"strands\":%u,"
        "\"peers\":%u,"
        "\"uptime_sec\":%llu}\n",
        zchg_PHI,
        (unsigned)zchg_STRAND_COUNT,
        (unsigned)server->lattice.peer_count,
        (unsigned long long)zchg_http_uptime_seconds(server));
    return zchg_http_build_response(conn, 200, "application/json",
                                     body, (size_t)n, conn->keep_alive);
}

/* GET / or GET /chat — serve chat.html from LN_WEB_ROOT (default: .) */
static int zchg_http_response_chat_ui(zchg_transport_server_t *server,
                                       zchg_http_connection_t  *conn) {
    (void)server;
    const char *web_root = getenv("LN_WEB_ROOT");
    if (!web_root) web_root = ".";
    char path[1024];
    snprintf(path, sizeof(path), "%s/chat.html", web_root);
    size_t file_len = 0;
    char  *file_buf = zchg_read_file_alloc(path, &file_len);
    if (!file_buf) {
        const char *body =
            "<html><head><title>ZCHG</title></head><body>"
            "<h2>ZCHG v0.6 — running</h2>"
            "<p>Place <code>chat.html</code> in <code>LN_WEB_ROOT</code> "
            "(default: current directory) to enable the chat UI.</p>"
            "<p><a href='/health'>/health</a> &nbsp; "
            "<a href='/status'>/status</a> &nbsp; "
            "<a href='/metrics'>/metrics</a></p>"
            "</body></html>\n";
        return zchg_http_build_response(conn, 200, "text/html; charset=utf-8",
                                         body, strlen(body), conn->keep_alive);
    }
    int rc = zchg_http_build_response(conn, 200, "text/html; charset=utf-8",
                                       file_buf, file_len, conn->keep_alive);
    free(file_buf);
    return rc;
}

static int zchg_http_handle_request(zchg_transport_server_t *server, zchg_http_connection_t *conn) {
    int method_is_get = strcmp(conn->method, "GET") == 0;
    int method_is_post = strcmp(conn->method, "POST") == 0;
    int method_is_head = strcmp(conn->method, "HEAD") == 0;

    if (!method_is_get && !method_is_post && !method_is_head) {
        return zchg_http_build_response(conn, 405, "text/plain; charset=utf-8", "method not allowed\n", 19, 0);
    }

    if (strcmp(conn->path, "/health") == 0 || strcmp(conn->path, "/healthz") == 0) {
        return zchg_http_response_health(server, conn);
    }

    if (strcmp(conn->path, "/metrics") == 0) {
        return zchg_http_response_metrics(server, conn);
    }

    if (strcmp(conn->path, "/node_info") == 0) {
        return zchg_http_response_node_info(server, conn);
    }

    if (strcmp(conn->path, "/strand_map") == 0) {
        return zchg_http_response_strand_map(server, conn);
    }

    if (strcmp(conn->path, "/protocol") == 0 || strcmp(conn->path, "/.well-known/ZCHG") == 0) {
        return zchg_http_response_protocol(server, conn);
    }

    if (strncmp(conn->path, "/serve/", 7) == 0) {
        return zchg_http_response_serve(server, conn);
    }

    if (method_is_post && strcmp(conn->path, "/frame") == 0) {
        return zchg_http_response_frame_upload(server, conn);
    }

    if (method_is_post && strcmp(conn->path, "/gossip") == 0) {
        return zchg_http_response_gossip(server, conn);
    }

    /* LLM proxy — phi-routing to Ollama */
    if (method_is_post && (strcmp(conn->path, "/v1/chat/completions") == 0 ||
                           strcmp(conn->path, "/api/chat") == 0)) {
        return zchg_http_response_llm(server, conn);
    }

    /* Status / liveness */
    if (strcmp(conn->path, "/status") == 0) {
        return zchg_http_response_status(server, conn);
    }

    /* Chat UI */
    if (strcmp(conn->path, "/") == 0 || strcmp(conn->path, "/chat") == 0) {
        return zchg_http_response_chat_ui(server, conn);
    }

    return zchg_http_build_response(conn, 404, "text/plain; charset=utf-8", "not found\n", 10, conn->keep_alive);
}

static int zchg_http_process_buffer(struct zchg_event_loop *loop, zchg_http_connection_t *conn) {
    while (conn->read_len > 0) {
        size_t consumed = 0;
        int parse_rc = zchg_http_parse_request(conn, &consumed);
        if (parse_rc == 0) {
            return 0;
        }
        if (parse_rc < 0) {
            zchg_http_build_response(conn, 400, "text/plain; charset=utf-8", "bad request\n", 12, 0);
            return -1;
        }

        if (zchg_http_handle_request(loop->server, conn) != 0) {
            zchg_http_build_response(conn, 500, "text/plain; charset=utf-8", "internal error\n", 15, 0);
            return -1;
        }

        zchg_http_consume_bytes(conn, consumed);
        return 0;
    }

    return 0;
}

static int zchg_http_flush_response(zchg_http_connection_t *conn) {
    if (!conn->write_buf || conn->write_sent >= conn->write_len) {
        return 0;
    }

    ssize_t rc = send(conn->fd, conn->write_buf + conn->write_sent, conn->write_len - conn->write_sent, 0);
    if (rc < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
            return 0;
        }
        return -1;
    }

    conn->write_sent += (size_t)rc;
    if (conn->write_sent >= conn->write_len) {
        zchg_http_reset_response(conn);
        conn->state = zchg_HTTP_CONN_READING;
        return 1;
    }

    return 0;
}

static int zchg_http_drain_connection(struct zchg_event_loop *loop, zchg_http_connection_t *conn) {
    char buffer[zchg_HTTP_READ_BUF];

    while (1) {
        ssize_t bytes_read = recv(conn->fd, buffer, sizeof(buffer), 0);
        if (bytes_read > 0) {
            if (conn->read_len + (size_t)bytes_read >= zchg_HTTP_READ_BUF) {
                return -1;
            }
            memcpy(conn->read_buf + conn->read_len, buffer, (size_t)bytes_read);
            conn->read_len += (size_t)bytes_read;
            continue;
        }

        if (bytes_read == 0) {
            return -1;
        }

        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            break;
        }

        if (errno == EINTR) {
            continue;
        }

        return -1;
    }

    return zchg_http_process_buffer(loop, conn);
}

/* ========================================================================== */
/* Public Event Loop API                                                      */
/* ========================================================================== */

zchg_event_loop_t *zchg_event_loop_create(void) {
    zchg_event_loop_t *loop = (zchg_event_loop_t *)malloc(sizeof(*loop));
    if (!loop) {
        return NULL;
    }

    memset(loop, 0, sizeof(*loop));
    loop->running = 1;
    for (int i = 0; i < zchg_HTTP_MAX_CONNECTIONS; i++) {
        loop->connections[i].fd = -1;
    }

    return loop;
}

void zchg_event_loop_destroy(zchg_event_loop_t *loop) {
    if (!loop) {
        return;
    }

    for (int i = 0; i < zchg_HTTP_MAX_CONNECTIONS; i++) {
        if (loop->connections[i].state != zchg_HTTP_CONN_FREE) {
            zchg_http_close_connection(loop, &loop->connections[i]);
        }
    }

    if (loop->server && loop->server->listen_fd >= 0) {
        close(loop->server->listen_fd);
        loop->server->listen_fd = -1;
    }

    free(loop);
}

void zchg_event_loop_break(zchg_event_loop_t *loop) {
    if (loop) {
        loop->running = 0;
    }
}

int zchg_event_loop_add_read(zchg_event_loop_t *loop, int fd, zchg_conn_cb_t cb, void *user_data) {
    (void)loop;
    (void)fd;
    (void)cb;
    (void)user_data;
    return 0;
}

int zchg_event_loop_add_write(zchg_event_loop_t *loop, int fd, zchg_conn_cb_t cb, void *user_data) {
    (void)loop;
    (void)fd;
    (void)cb;
    (void)user_data;
    return 0;
}

int zchg_event_loop_remove_fd(zchg_event_loop_t *loop, int fd) {
    if (!loop || fd < 0 || fd >= zchg_HTTP_MAX_CONNECTIONS) {
        return -1;
    }

    zchg_http_close_connection(loop, &loop->connections[fd]);
    return 0;
}

int zchg_event_loop_add_timer(zchg_event_loop_t *loop, uint32_t ms, zchg_timer_cb_t cb, void *user_data) {
    (void)loop;
    (void)ms;
    (void)cb;
    (void)user_data;
    return 0;
}

/* ========================================================================== */
/* Server Setup                                                               */
/* ========================================================================== */

int zchg_server_listen(zchg_transport_server_t *server, zchg_event_loop_t *loop) {
    if (!server || !loop) {
        return -1;
    }

    int listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        perror("socket");
        return -1;
    }

    int reuse = 1;
    (void)setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
#ifdef SO_REUSEPORT
    (void)setsockopt(listen_fd, SOL_SOCKET, SO_REUSEPORT, &reuse, sizeof(reuse));
#endif

    if (zchg_http_set_nonblocking(listen_fd) != 0) {
        perror("fcntl");
        close(listen_fd);
        return -1;
    }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(server->port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(listen_fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        perror("bind");
        close(listen_fd);
        return -1;
    }

    if (listen(listen_fd, 1024) != 0) {
        perror("listen");
        close(listen_fd);
        return -1;
    }

    server->listen_fd = listen_fd;
    server->started_at = time(NULL);
    loop->server = server;
    loop->running = 1;

    return 0;
}

int zchg_server_accept_connection(zchg_transport_server_t *server, int client_fd) {
    (void)server;
    if (client_fd < 0) {
        return -1;
    }

    return zchg_http_set_nonblocking(client_fd);
}

/* ========================================================================== */
/* Request / Response Processing                                              */
/* ========================================================================== */

static int zchg_http_accept_clients(struct zchg_event_loop *loop) {
    while (1) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        int client_fd = accept(loop->server->listen_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_fd < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
                return 0;
            }
            return -1;
        }

        if (client_fd >= zchg_HTTP_MAX_CONNECTIONS) {
            close(client_fd);
            continue;
        }

        if (zchg_http_set_nonblocking(client_fd) != 0) {
            close(client_fd);
            continue;
        }

        zchg_http_connection_t *conn = zchg_http_acquire_connection(loop, client_fd);
        if (!conn) {
            close(client_fd);
            continue;
        }

        conn->state = zchg_HTTP_CONN_READING;
        loop->server->active_connections += 1;
        loop->server->total_connections += 1;
    }

    return 0;
}

static int zchg_http_handle_readable(struct zchg_event_loop *loop, int fd) {
    zchg_http_connection_t *conn = zchg_http_find_connection(loop, fd);
    if (!conn) {
        return -1;
    }

    if (conn->state == zchg_HTTP_CONN_WRITING && conn->write_buf) {
        char buffer[zchg_HTTP_READ_BUF];
        while (1) {
            ssize_t bytes_read = recv(conn->fd, buffer, sizeof(buffer), 0);
            if (bytes_read > 0) {
                if (conn->read_len + (size_t)bytes_read >= zchg_HTTP_READ_BUF) {
                    return -1;
                }
                memcpy(conn->read_buf + conn->read_len, buffer, (size_t)bytes_read);
                conn->read_len += (size_t)bytes_read;
                continue;
            }
            if (bytes_read == 0) {
                return -1;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                return 0;
            }
            if (errno == EINTR) {
                continue;
            }
            return -1;
        }
    }

    if (zchg_http_drain_connection(loop, conn) != 0) {
        return -1;
    }

    if (conn->state == zchg_HTTP_CONN_WRITING) {
        return 0;
    }

    return 0;
}

static int zchg_http_handle_writable(struct zchg_event_loop *loop, int fd) {
    zchg_http_connection_t *conn = zchg_http_find_connection(loop, fd);
    if (!conn) {
        return -1;
    }

    if (conn->state != zchg_HTTP_CONN_WRITING) {
        return 0;
    }

    int flush_rc = zchg_http_flush_response(conn);
    if (flush_rc < 0) {
        return -1;
    }

    if (flush_rc > 0 && !conn->keep_alive) {
        zchg_http_close_connection(loop, conn);
        return 0;
    }

    if (conn->state == zchg_HTTP_CONN_READING && conn->read_len > 0) {
        if (zchg_http_process_buffer(loop, conn) != 0) {
            return -1;
        }
    }

    return 0;
}

int zchg_event_loop_run(zchg_event_loop_t *loop) {
    if (!loop || !loop->server || loop->server->listen_fd < 0) {
        return -1;
    }

    time_t last_gossip_cycle = time(NULL);
    time_t last_fileswap_evict = time(NULL);

    while (loop->running) {
        fd_set read_fds;
        fd_set write_fds;
        FD_ZERO(&read_fds);
        FD_ZERO(&write_fds);

        FD_SET(loop->server->listen_fd, &read_fds);
        int max_fd = loop->server->listen_fd;

        for (int fd = 0; fd < zchg_HTTP_MAX_CONNECTIONS; fd++) {
            zchg_http_connection_t *conn = &loop->connections[fd];
            if (conn->state == zchg_HTTP_CONN_FREE) { continue; }
            FD_SET(fd, &read_fds);
            if (conn->state == zchg_HTTP_CONN_WRITING && conn->write_buf && conn->write_sent < conn->write_len) {
                FD_SET(fd, &write_fds);
            }
            if (fd > max_fd) { max_fd = fd; }
        }

        int ready = select(max_fd + 1, &read_fds, &write_fds, NULL, NULL);
        if (ready < 0) {
            if (errno == EINTR) { continue; }
            perror("select");
            return -1;
        }

        time_t now = time(NULL);
        if (now - last_gossip_cycle >= zchg_GOSSIP_INTERVAL) {
            zchg_gossip_cycle(loop->server);
            zchg_gossip_evict_dead_peers(&loop->server->lattice);
            last_gossip_cycle = now;
        }
        if (now - last_fileswap_evict >= 60) {
            zchg_fileswap_evict_lru(loop->server, 0);
            last_fileswap_evict = now;
        }

        if (FD_ISSET(loop->server->listen_fd, &read_fds)) {
            if (zchg_http_accept_clients(loop) != 0) { return -1; }
        }

        for (int fd = 0; fd < zchg_HTTP_MAX_CONNECTIONS; fd++) {
            zchg_http_connection_t *conn = &loop->connections[fd];
            if (conn->state == zchg_HTTP_CONN_FREE) { continue; }

            if (FD_ISSET(fd, &read_fds)) {
                if (zchg_http_handle_readable(loop, fd) != 0) {
                    zchg_http_close_connection(loop, conn);
                    continue;
                }
            }
            if (conn->state != zchg_HTTP_CONN_FREE && FD_ISSET(fd, &write_fds)) {
                if (zchg_http_handle_writable(loop, fd) != 0) {
                    zchg_http_close_connection(loop, conn);
                    continue;
                }
            }
            if (conn->state == zchg_HTTP_CONN_WRITING && conn->write_buf == NULL) {
                if (!conn->keep_alive) { zchg_http_close_connection(loop, conn); }
            }
        }
    }

    return 0;
}

/* ========================================================================== */
/* Native ZCHG Frame Handlers                                                 */
/* ========================================================================== */

int zchg_metrics_collect(zchg_transport_server_t *server, zchg_metrics_t *out_metrics) {
    if (!server || !out_metrics) { return -1; }
    memset(out_metrics, 0, sizeof(*out_metrics));
    out_metrics->total_frames_sent      = server->total_frames_sent;
    out_metrics->total_frames_recv      = server->total_frames_recv;
    out_metrics->total_bytes_sent       = server->total_bytes_sent;
    out_metrics->total_bytes_recv       = server->total_bytes_recv;
    out_metrics->active_connections     = server->active_connections;
    out_metrics->total_connections      = server->total_connections;
    out_metrics->latency_p50            = 0.0;
    out_metrics->latency_p95            = 0.0;
    out_metrics->latency_p99            = 0.0;
    out_metrics->connection_reuse_ratio = 0.96;
    out_metrics->cache_hit_ratio        = server->cache_size > 0
        ? (uint32_t)((100U * server->cache_hits) / server->cache_size) : 0;
    out_metrics->uptime_sec             = zchg_http_uptime_seconds(server);
    return 0;
}

int zchg_handle_health_frame(zchg_transport_server_t *server, zchg_frame_t *frame, zchg_frame_t **out_response) {
    (void)server;
    if (!frame) { return -1; }
    if (out_response) {
        zchg_frame_t *response = (zchg_frame_t *)calloc(1, sizeof(*response));
        if (!response) { return -1; }
        const char *payload = "ok";
        response->payload_len = strlen(payload);
        response->payload = (uint8_t *)malloc(response->payload_len);
        if (!response->payload) { free(response); return -1; }
        memcpy(response->payload, payload, response->payload_len);
        response->header.version     = zchg_FRAME_VERSION;
        response->header.type        = zchg_FRAME_ACK;
        response->header.payload_len = (uint32_t)response->payload_len;
        response->header.timestamp   = (uint64_t)time(NULL) * 1000ULL;
        *out_response = response;
    }
    return 0;
}

int zchg_handle_info_frame(zchg_transport_server_t *server, zchg_frame_t *frame, zchg_frame_t **out_response) {
    if (!server || !frame) { return -1; }
    if (out_response) {
        zchg_frame_t *response = (zchg_frame_t *)calloc(1, sizeof(*response));
        if (!response) { return -1; }
        char payload[1024], ip_text[64];
        zchg_http_ip_to_text(server->local_ip, ip_text, sizeof(ip_text));
        int written = snprintf(payload, sizeof(payload),
            "{\"local_ip\":\"%s\",\"port\":%u,\"cluster_fingerprint\":%u,\"peer_count\":%u}",
            ip_text, server->port, server->lattice.cluster_fingerprint, server->lattice.peer_count);
        if (written < 0) { free(response); return -1; }
        response->payload_len = (size_t)written;
        response->payload = (uint8_t *)malloc(response->payload_len);
        if (!response->payload) { free(response); return -1; }
        memcpy(response->payload, payload, response->payload_len);
        response->header.version     = zchg_FRAME_VERSION;
        response->header.type        = zchg_FRAME_INFO;
        response->header.payload_len = (uint32_t)response->payload_len;
        response->header.timestamp   = (uint64_t)time(NULL) * 1000ULL;
        *out_response = response;
    }
    return 0;
}

int zchg_handle_gossip_frame(zchg_transport_server_t *server, zchg_frame_t *frame) {
    if (!server || !frame || !frame->payload || frame->payload_len < sizeof(zchg_gossip_msg_t)) { return -1; }
    zchg_gossip_msg_t msg;
    memcpy(&msg, frame->payload, sizeof(msg));
    return zchg_lattice_apply_gossip(&server->lattice, msg.source_ip, &msg);
}

int zchg_handle_fetch_frame(zchg_transport_server_t *server, zchg_frame_t *frame, zchg_frame_t **out_response) {
    if (!server || !frame || !out_response) { return -1; }
    zchg_frame_t *response = (zchg_frame_t *)calloc(1, sizeof(*response));
    if (!response) { return -1; }
    const char *payload = "fetch not implemented in native HTTP front door";
    response->payload_len = strlen(payload);
    response->payload = (uint8_t *)malloc(response->payload_len);
    if (!response->payload) { free(response); return -1; }
    memcpy(response->payload, payload, response->payload_len);
    response->header.version     = zchg_FRAME_VERSION;
    response->header.type        = zchg_FRAME_ERROR;
    response->header.payload_len = (uint32_t)response->payload_len;
    response->header.timestamp   = (uint64_t)time(NULL) * 1000ULL;
    *out_response = response;
    return 0;
}

int zchg_server_handle_frame(zchg_transport_server_t *server, int conn_fd, zchg_frame_t *frame) {
    (void)conn_fd;
    if (!server || !frame) { return -1; }
    server->total_frames_recv += 1;
    server->total_bytes_recv  += frame->payload_len + zchg_FRAME_HEADER_SIZE;
    switch (frame->header.type) {
        case zchg_FRAME_HEALTH:  return zchg_handle_health_frame(server, frame, NULL);
        case zchg_FRAME_INFO:    return zchg_handle_info_frame(server, frame, NULL);
        case zchg_FRAME_GOSSIP:  return zchg_handle_gossip_frame(server, frame);
        case zchg_FRAME_FETCH: {
            zchg_frame_t *response = NULL;
            int rc = zchg_handle_fetch_frame(server, frame, &response);
            if (response) {
                if (response->payload) { free(response->payload); }
                free(response);
            }
            return rc;
        }
        default: return 0;
    }
}

/* ========================================================================== */
/* Serial Bridge — COM1 UART proxy for HDGL-OS kernel inference               */
/*                                                                            */
/* Protocol (both directions): STX (0x02) + text + ETX (0x03)                */
/*                                                                            */
/* QEMU launch:  -serial tcp:127.0.0.1:9001                                  */
/* Daemon start: LN_SERIAL_PORT=9001 zchg_daemon                             */
/*                                                                            */
/* The bridge reads a prompt from the kernel, phi-routes it to Ollama via    */
/* the same SOLO/RELAY/CHALLENGE multi-pass logic as the HTTP handler, then  */
/* writes the content text back to the kernel over the same connection.       */
/*                                                                            */
/* Hotswap: update LN_OLLAMA_MODEL and restart zchg_daemon — no ISO rebuild. */
/* ========================================================================== */

#include <pthread.h>

#define ZCHG_SERIAL_BRIDGE_DEFAULT_PORT  9001
#define ZCHG_SERIAL_BRIDGE_BUF           65536

/* Read a STX...ETX framed message from fd into buf (NUL-terminated).
   Returns number of bytes read (excluding framing), or -1 on error/EOF. */
static ssize_t serial_read_frame(int fd, char *buf, size_t cap) {
    /* Drain until STX */
    char c;
    for (;;) {
        ssize_t n = recv(fd, &c, 1, 0);
        if (n <= 0) return -1;
        if ((uint8_t)c == 0x02) break;  /* STX */
    }
    /* Read until ETX */
    size_t i = 0;
    while (i < cap - 1) {
        ssize_t n = recv(fd, &c, 1, 0);
        if (n <= 0) break;
        if ((uint8_t)c == 0x03) break;  /* ETX */
        buf[i++] = c;
    }
    buf[i] = '\0';
    return (ssize_t)i;
}

/* Write a STX...ETX framed message to fd. */
static int serial_write_frame(int fd, const char *msg, size_t len) {
    uint8_t stx = 0x02, etx = 0x03;
    if (send(fd, &stx, 1, 0) != 1) return -1;
    size_t sent = 0;
    while (sent < len) {
        ssize_t n = send(fd, msg + sent, len - sent, 0);
        if (n <= 0) return -1;
        sent += (size_t)n;
    }
    if (send(fd, &etx, 1, 0) != 1) return -1;
    return 0;
}

/* Per-connection handler: read prompt, phi-route, write response content. */
static void serial_handle_connection(int client_fd) {
    char *prompt_buf = malloc(ZCHG_SERIAL_BRIDGE_BUF);
    if (!prompt_buf) { close(client_fd); return; }

    const char *ollama_host = getenv("LN_OLLAMA_HOST");
    if (!ollama_host) ollama_host = "127.0.0.1";
    const char *port_env   = getenv("LN_OLLAMA_PORT");
    uint16_t    ollama_port = port_env ? (uint16_t)atoi(port_env) : 11434;

    const char *model_env  = getenv("LN_OLLAMA_MODEL");
    if (!model_env) model_env = "qwen3.5:9b";  /* default; hotswap via env */

    for (;;) {
        /* Read one framed prompt from kernel */
        ssize_t plen = serial_read_frame(client_fd, prompt_buf, ZCHG_SERIAL_BRIDGE_BUF);
        if (plen <= 0) break;

        fprintf(stderr, "[SERIAL] prompt=%zu bytes phi-routing...\n", (size_t)plen);

        /* Phi-routing decision on the raw prompt text */
        double phi   = zchg_llm_phi_score(prompt_buf, (size_t)plen);
        int    route = zchg_llm_classify(phi);
        fprintf(stderr, "[SERIAL] phi=%.4f route=%s\n",
                phi, zchg_llm_route_names[route]);

        /* Build a /v1/chat/completions request body */
        char *req1 = zchg_llm_build_single_req(model_env, prompt_buf);
        if (!req1) break;

        size_t r1_len  = 0;
        int    r1_code = 200;
        char  *p1      = zchg_llm_proxy(ollama_host, ollama_port,
                                         "/v1/chat/completions",
                                         req1, strlen(req1),
                                         &r1_len, &r1_code);
        free(req1);

        if (!p1) {
            const char *err = "[ZCHG-DAEMON: ollama unreachable]";
            serial_write_frame(client_fd, err, strlen(err));
            continue;
        }

        char *response_text = NULL;

        if (route == ZCHG_LLM_ROUTE_SOLO) {
            response_text = zchg_llm_extract_content(p1);
            free(p1);

        } else if (route == ZCHG_LLM_ROUTE_RELAY) {
            char *p1c = zchg_llm_extract_content(p1);
            free(p1);
            if (p1c) {
                size_t rcap = strlen(p1c) + 128;
                char  *rprompt = malloc(rcap);
                if (rprompt) {
                    snprintf(rprompt, rcap,
                        "Refine and improve the following response. "
                        "Be accurate, concise, and complete:\n\n%s", p1c);
                    char *req2 = zchg_llm_build_single_req(model_env, rprompt);
                    free(rprompt);
                    if (req2) {
                        size_t r2_len = 0; int r2_code = 200;
                        char  *p2 = zchg_llm_proxy(ollama_host, ollama_port,
                                                    "/v1/chat/completions",
                                                    req2, strlen(req2),
                                                    &r2_len, &r2_code);
                        free(req2);
                        if (p2) { response_text = zchg_llm_extract_content(p2); free(p2); }
                    }
                }
                free(p1c);
            }

        } else { /* CHALLENGE */
            size_t pb_len = 0; int pb_code = 200;
            char  *req_b  = zchg_llm_build_single_req(model_env, prompt_buf);
            char  *p2     = req_b ? zchg_llm_proxy(ollama_host, ollama_port,
                                                    "/v1/chat/completions",
                                                    req_b, strlen(req_b),
                                                    &pb_len, &pb_code) : NULL;
            free(req_b);

            char *ca = zchg_llm_extract_content(p1); free(p1);
            char *cb = p2 ? zchg_llm_extract_content(p2) : NULL; if (p2) free(p2);

            if (ca && cb) {
                size_t ecap = strlen(ca) + strlen(cb) + 256;
                char  *ep   = malloc(ecap);
                if (ep) {
                    snprintf(ep, ecap,
                        "Two independent responses were generated. "
                        "Evaluate both and synthesise the best answer:\n\n"
                        "Response A:\n%s\n\nResponse B:\n%s\n\nSynthesised answer:",
                        ca, cb);
                    char *req_e = zchg_llm_build_single_req(model_env, ep);
                    free(ep);
                    if (req_e) {
                        size_t re_len = 0; int re_code = 200;
                        char  *pe = zchg_llm_proxy(ollama_host, ollama_port,
                                                   "/v1/chat/completions",
                                                   req_e, strlen(req_e),
                                                   &re_len, &re_code);
                        free(req_e);
                        if (pe) { response_text = zchg_llm_extract_content(pe); free(pe); }
                    }
                }
            }
            free(ca); free(cb);
        }

        if (!response_text) response_text = strdup("[ZCHG-DAEMON: extract failed]");
        if (response_text) {
            serial_write_frame(client_fd, response_text, strlen(response_text));
            free(response_text);
        }
    }

    free(prompt_buf);
    close(client_fd);
}

/*
 * zchg_serial_bridge_run — TCP server for kernel serial bridge.
 * Called from a detached pthread in zchg_main.c.
 * Env: LN_SERIAL_PORT (default 9001).
 */
void *zchg_serial_bridge_run(void *arg) {
    (void)arg;

    const char *port_env  = getenv("LN_SERIAL_PORT");
    uint16_t    port      = port_env ? (uint16_t)atoi(port_env)
                                     : ZCHG_SERIAL_BRIDGE_DEFAULT_PORT;

    int srv_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (srv_fd < 0) {
        perror("[SERIAL] socket");
        return NULL;
    }

    int reuse = 1;
    setsockopt(srv_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    if (bind(srv_fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        perror("[SERIAL] bind");
        close(srv_fd);
        return NULL;
    }

    if (listen(srv_fd, 1) != 0) {
        perror("[SERIAL] listen");
        close(srv_fd);
        return NULL;
    }

    fprintf(stderr, "[SERIAL] bridge listening on 127.0.0.1:%u\n", port);
    fprintf(stderr, "[SERIAL] QEMU: add  -serial tcp:127.0.0.1:%u\n", port);

    for (;;) {
        struct sockaddr_in cli_addr;
        socklen_t cli_len = sizeof(cli_addr);
        int cli_fd = accept(srv_fd, (struct sockaddr *)&cli_addr, &cli_len);
        if (cli_fd < 0) continue;
        fprintf(stderr, "[SERIAL] kernel connected\n");
        serial_handle_connection(cli_fd);  /* blocking until disconnect */
        fprintf(stderr, "[SERIAL] kernel disconnected\n");
    }

    close(srv_fd);
    return NULL;
}
