#!/usr/bin/env bash
# test_live.sh — test ZCHG daemon with actual Ollama output
# Run from the NGINX-HDGL-0.6-c directory after: make build
# Usage: LN_LOCAL_NODE=127.0.0.1 LN_CLUSTER_SECRET=x bash test_live.sh

DAEMON_URL="${DAEMON_URL:-http://127.0.0.1:8080}"
MODEL="${LN_OLLAMA_MODEL:-qwen3.5:9b}"
OUTF=/tmp/zchg_test_resp.json

check_health() {
    curl -sf "$DAEMON_URL/health" > /dev/null 2>&1
}

run_prompt() {
    local prompt="$1"
    printf '\n%s\n' "$(printf '=%.0s' {1..60})"
    printf 'PROMPT: %s\n\n' "$prompt"

    local body
    body=$(printf '{"model":"%s","stream":false,"messages":[{"role":"user","content":"%s"}]}' \
        "$MODEL" "$(printf '%s' "$prompt" | sed 's/"/\\"/g')")

    curl -s -X POST "$DAEMON_URL/v1/chat/completions" \
         -H "Content-Type: application/json" \
         -d "$body" \
         --max-time 300 \
         -o "$OUTF"

    # Extract route from daemon stderr (if redirected) or from error JSON
    local route
    route=$(grep -oP '"route":"\K[^"]+' "$OUTF" 2>/dev/null || echo "")

    # Extract content
    local content
    content=$(grep -oP '"content":"\K((?:[^"\\]|\\.)*)' "$OUTF" 2>/dev/null | head -1 \
              | sed 's/\\n/\n/g; s/\\t/\t/g; s/\\"/"/g; s/\\\\/\\/g')

    if [ -n "$route" ]; then
        printf 'Route: %s\n' "$route"
    fi
    printf 'RESPONSE:\n%s\n' "${content:-$(cat "$OUTF")}"
}

echo "ZCHG live bot test"
echo "Daemon: $DAEMON_URL   Model: $MODEL"
echo ""

# Start daemon in background if not running
if ! check_health; then
    echo "Starting daemon..."
    LN_LOCAL_NODE="${LN_LOCAL_NODE:-127.0.0.1}" \
    LN_CLUSTER_SECRET="${LN_CLUSTER_SECRET:-hdgl}" \
      ./bin/zchg_daemon > /tmp/zchg_daemon.log 2>&1 &
    DPID=$!
    sleep 2
    if ! check_health; then
        echo "ERROR: daemon failed to start. Log:"
        cat /tmp/zchg_daemon.log
        exit 1
    fi
    echo "Daemon started (PID $DPID)"
else
    echo "Daemon: already running"
fi

run_prompt "What is phi, the golden ratio, and why does it appear in nature?"
run_prompt "Explain HDGL strand routing in one sentence."
run_prompt "What is consciousness?"

echo ""
printf '=%.0s' {1..60}; echo ""
echo "Done. Daemon log: /tmp/zchg_daemon.log"
echo "Phi-routing log:  grep LLM /tmp/zchg_daemon.log"
