We are building a K.I.S.S. HDGL (Analog-over-digital) resource fabric for a Local AI bot.  Our staging model, for now, is "C:\Users\Owner\.ollama\models\blobs\unsloth\Qwen3.5-9B-GGUF\Qwen3.5-9B-UD-Q6_K_XL.gguf"

I have several local nodes which consist of:
# Assets / Constraints
SuperMicro X9DRW-7TPF Dual Xeon LGA2011 2x E5-2650V2 CPU Server Motherboard
Dell Poweredge R430 / R530 DDR4 Motherboard Board - X99HC 0X99HC Dell PowerEdge R430 R530 T430 T530 Remote Port Card iDRAC8
Intel Xeon Phi 5110P + M60 + M40 + MI25 cards

In addition to generic motherboards.

The idea is we can scale our local node's fabric to be able to:
1) Co-host ONE LLM, or
2) collaborate multiple LLM's

The extras folders contains a wish for a more advanced version, but only after we've gotten things sorted out with our major files, and only if we can accomplish a coherent prompt output.  The idea, long term, is an analog-over-digital OS.

# MORE EXTRAS:

# HDGL Kernel / Prismatic Computer
https://josefkulovany.com/demo/9.24.25-%20kernel/really%20works/
https://josefkulovany.com/demo/9.21.25%20-%20Prismatic%20Computer/

# HDGL / Analog-over-digital

"C:\Users\Owner\Documents\Josef's Code 2026\HDGL P2P Internet\HDGL-SQL-0.2"
"C:\Users\Owner\Documents\Josef's Code 2026\HDGL P2P Internet\Analog-Prime-main\Analog-Prime-main"
https://zchg.org/t/mafia8-analog-prismatic-engine-scripts-hdgl/858
https://forum.zchg.org/t/turing-complete-tertiary-machine-that-runs-on-binary-hdgl-primitives/857
https://josefkulovany.com/demo/9.19.25%20-%20TURING%20and%20HDGL/

# HDGL Languages
https://zchg.org/t/a-vector-language-part-2/864
https://zchg.org/t/a-vector-language-part-1/863/1
https://zchg.org/t/an-elegant-phi-based-language/860
https://zchg.org/t/more-phi-language/862
"C:\Users\Owner\Documents\Josef's Code 2026\HDGL P2P Internet\spiral8plus-master\spiral8plus-master" - to attend, folding - "C:\Users\Owner\Documents\Josef's Code 2026\HDGL P2P Internet\Prime-Hunter-2\BigG + Fudge10 - Empirical & Unified\Grand Unified Take 2\base4096-2.0.1\spare parts"

AVOID Python ALWAYS.  AVOID WSL ALWAYS (QEMO is fine for demo, but the final product will need to compile and boot stand-alone).  <b>Use ONLY my own repo's files!!!</b>  ONLY C, Holy C, Temple2 Compile/kernel + HDGL compile/kernel, HDGL languages, b4096, DNA e.g. "C:\Users\Owner\Documents\Josef's Code 2026\HDGL P2P Internet\spiral8plus-master\spiral8plus-master", HDGL json are permitted THROUGHOUT.  An ISO is permitted for the final bundle only.