# TempleOS Integration Guide for conscious

This document is the canonical guide for using TempleOS in this repository.
It explains what TempleOS is, what core functions it provides, how this project uses it, and how to operate the full Windows + QEMU + TempleOS workflow.

## 1. What TempleOS Is

TempleOS is a 64-bit x86 operating system created by Terry A. Davis.
Its design goals are simplicity, directness, and full transparency of the runtime.

Core characteristics:
- Single-user environment
- Tight integration between editor, compiler, shell, and graphics
- HolyC as the native systems/programming language
- Minimal abstraction layers compared to modern general-purpose OSes
- Emphasis on direct hardware-era style workflows

TempleOS is best treated as a research and experimentation OS, not a hardened production platform.

## 2. Core TempleOS Functions

TempleOS includes these built-in functions/capabilities relevant to this project:

1. Interactive shell and command environment
- Immediate command execution
- Script-like command workflows
- Fast iterative experimentation

2. HolyC development loop
- Edit, compile, and run in the same environment
- Low-friction prototyping of systems logic
- Direct access to OS internals

3. Built-in editor and tooling
- Source editing without external IDE dependencies
- Native workflow for quick patch/test cycles

4. File operations and disk access
- Simple file model
- Suitable for artifact-driven workflows (input files, output files, logs)

5. VM-friendly operation
- Runs reliably under QEMU with low host coupling
- Works well in "host orchestrates, guest executes" pipelines

## 3. How TempleOS Is Used in This Repo

This repository now uses TempleOS through QEMU, replacing Alpine/Docker-centric runtime control in the main UI flow.

High-level architecture:
- Host: Windows (build/orchestration)
- Guest: TempleOS VM in QEMU
- Bridge: shared FAT folder at conscious/lattice_data

Data flow:
1. Host prepares artifacts (state, scripts, runtime files).
2. Files are copied into conscious/lattice_data.
3. QEMU boots TempleOS with the shared folder attached.
4. TempleOS accesses those artifacts.
5. Outputs are written back to the shared folder for host-side consumption.

## 4. Prerequisites

Required:
- Windows 10 or 11
- QEMU installed (qemu-system-x86_64w.exe)
- TempleOS ISO at Temple2/TempleOS.ISO
- Project folder at Temple2/conscious

Recommended:
- Keep paths stable (avoid moving the Temple2 root often)
- Keep VM memory at 512M or higher unless actively tuning memory behavior

## 5. Boot TempleOS for conscious

Canonical command used in this workspace:

```powershell
& "C:\Program Files\qemu\qemu-system-x86_64w.exe" \
  -name phi4096-lattice \
  -m 512M \
  -vga std \
  -accel tcg \
  -boot d \
  -cdrom "c:\Users\Owner\Documents\Josef's Code 2026\Temple2\TempleOS.ISO" \
  -drive "file=fat:rw:c:\Users\Owner\Documents\Josef's Code 2026\Temple2\conscious\lattice_data,format=raw,if=virtio"
```

Live-process check:

```powershell
tasklist /FI "IMAGENAME eq qemu-system-x86_64w.exe" /FO TABLE
```

Stop VM:
- Close the QEMU window, or
- End process from Task Manager / taskkill

## 6. Practical Usage Workflow

Use this workflow for repeatable runs:

1. Prepare host artifacts
- Ensure these files exist in conscious:
  - lattice_state.env
  - lattice_init.sh
  - lattice_crystal.sh
  - lattice_quantum.sh
  - lattice_proc.sh

2. Stage artifacts into shared folder
- Copy files into conscious/lattice_data
- Keep file names stable to reduce guest-side lookup errors

3. Boot TempleOS VM
- Launch with the canonical QEMU command
- Confirm process exists via tasklist

4. Execute TempleOS-side tasks
- Use TempleOS shell/HolyC workflows to inspect/process staged files
- Write outputs back into shared folder for host tools

5. Validate outputs on host
- Read artifacts from conscious/lattice_data
- Perform comparisons, benchmarks, or follow-up processing

## 7. Operational Notes for This Migration

What changed from legacy behavior:
- Docker lifecycle checks were replaced by QEMU process checks
- Container file injection was replaced by host copy to shared FAT drive
- Alpine/APK-specific provisioning references were replaced with TempleOS/HolyC notes in active paths

Important implication:
- Some legacy shell lines are now documentary placeholders rather than directly TempleOS-native actions.
- True TempleOS-native behavior should be implemented in HolyC where needed.

## 8. Security and Risk Posture

Treat this setup as a controlled research environment.

Guidelines:
- Do not treat TempleOS VM as a hardened trust boundary
- Avoid placing secrets directly in shared lattice_data when unnecessary
- Keep host-side backups of critical artifacts
- Prefer deterministic, file-based interfaces over ad-hoc manual edits

## 9. Performance Considerations

Expected tradeoffs:
- VM boot and GUI overhead is higher than headless Linux containers
- Shared FAT drive is convenient but not high-performance
- Great for experimentation and deterministic replay; weaker for high-throughput automation

Tune knobs:
- VM memory (-m)
- Optional CPU flags if your QEMU build/environment supports them
- Artifact batching to reduce repeated copy churn

## 10. Troubleshooting

QEMU command not found:
- Verify QEMU install path
- Use full executable path in command

ISO not booting:
- Confirm TempleOS.ISO path
- Confirm file integrity and readable permissions

Shared folder not visible from guest:
- Verify -drive fat:rw path is correct
- Confirm lattice_data exists and is accessible on host

Multiple VMs running unexpectedly:
- Use tasklist and terminate stale qemu-system-x86_64w.exe instances

Artifact mismatch across runs:
- Clear or version lattice_data between runs
- Keep deterministic input snapshots

## 11. Recommended Repo Conventions

Adopt these conventions for long-term stability:
- Keep one canonical QEMU launch command in documentation and scripts
- Keep one canonical shared-folder contract (inputs, outputs, naming)
- Keep preflight checks on host before each run
- Keep golden-run expected outputs for regression testing

## 12. Quick Reference

Start VM:
```powershell
& "C:\Program Files\qemu\qemu-system-x86_64w.exe" -name phi4096-lattice -m 512M -vga std -accel tcg -boot d -cdrom "c:\Users\Owner\Documents\Josef's Code 2026\Temple2\TempleOS.ISO" -drive "file=fat:rw:c:\Users\Owner\Documents\Josef's Code 2026\Temple2\conscious\lattice_data,format=raw,if=virtio"
```

Check VM:
```powershell
tasklist /FI "IMAGENAME eq qemu-system-x86_64w.exe" /FO TABLE
```

Stop VM:
```powershell
taskkill /IM qemu-system-x86_64w.exe /F
```

## 13. Scope Boundary

This document explains TempleOS usage and integration in this project.
It does not attempt to be a full historical or philosophical manual for every TempleOS subsystem.

For this repo, the key rule is:
- Windows orchestrates,
- QEMU hosts TempleOS,
- shared lattice_data carries deterministic artifacts.
