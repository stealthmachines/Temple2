$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

$clang = "C:\Program Files\LLVM\bin\clang.exe"
$ld = "C:\Program Files\LLVM\bin\ld.lld.exe"
$objcopy = "C:\Program Files\LLVM\bin\llvm-objcopy.exe"

function Invoke-Checked {
  param([string]$exe, [string[]]$argv)
  & $exe @argv
  if ($LASTEXITCODE -ne 0) {
    throw "Command failed: $exe $($argv -join ' ')"
  }
}

foreach ($tool in @($clang, $ld, $objcopy)) {
  if (-not (Test-Path $tool)) {
    throw "Missing tool: $tool"
  }
}

Write-Host "[boot] assembling stage-1..."
Write-Host "[boot] assembling stage-2..."
Invoke-Checked $clang @("--target=i386-pc-none-elf","-m16","-ffreestanding","-fno-pic","-fno-pie","-c",".\\boot_stage2.S","-o",".\\boot_stage2.o")

Write-Host "[boot] linking stage-2..."
Invoke-Checked $ld @("-flavor","gnu","-m","elf_i386","-T",".\\boot_stage2.ld",".\\boot_stage2.o","-o",".\\boot_stage2.elf")

Write-Host "[boot] extracting stage-2 binary..."
Invoke-Checked $objcopy @("-O","binary",".\\boot_stage2.elf",".\\boot_stage2.bin")

[byte[]]$stage2 = [System.IO.File]::ReadAllBytes(".\boot_stage2.bin")
$stage2Sectors = [int][Math]::Ceiling($stage2.Length / 512.0)
if ($stage2Sectors -lt 1) { $stage2Sectors = 1 }
if ($stage2Sectors -gt 32) {
  throw "Stage-2 too large for current stage-1 loader: $stage2Sectors sectors (max 32)."
}

Write-Host "[boot] assembling stage-1..."
Invoke-Checked $clang @("--target=i386-pc-none-elf","-m16","-ffreestanding","-fno-pic","-fno-pie","-DSTAGE2_SECTORS=$stage2Sectors","-c",".\\boot_stage1.S","-o",".\\boot_stage1.o")

Write-Host "[boot] linking stage-1..."
Invoke-Checked $ld @("-flavor","gnu","-m","elf_i386","-T",".\\boot_stage1.ld",".\\boot_stage1.o","-o",".\\boot_stage1.elf")

Write-Host "[boot] extracting flat binary..."
Invoke-Checked $objcopy @("-O","binary",".\\boot_stage1.elf",".\\boot_stage1.bin")

[byte[]]$stage1 = [System.IO.File]::ReadAllBytes(".\boot_stage1.bin")
if ($stage1.Length -gt 510) {
  throw "Stage-1 too large: $($stage1.Length) bytes (max 510)."
}

[byte[]]$sector = New-Object byte[] 512
[Array]::Copy($stage1, 0, $sector, 0, $stage1.Length)
$sector[510] = 0x55
$sector[511] = 0xAA
[System.IO.File]::WriteAllBytes(".\boot_stage1.sector.bin", $sector)

# Build a simple 1.44MB bootable image with stage-1 in sector 0.
[byte[]]$image = New-Object byte[] (1474560)
[Array]::Copy($sector, 0, $image, 0, 512)

# Place stage-2 immediately after stage-1 (starting at LBA sector 1).
[Array]::Copy($stage2, 0, $image, 512, $stage2.Length)

[System.IO.File]::WriteAllBytes(".\kiss2_boot.img", $image)

Write-Host "[ok] built .\boot_stage1.sector.bin (512 bytes, boot signature 0x55AA)"
Write-Host "[ok] built .\boot_stage2.bin ($($stage2.Length) bytes, $stage2Sectors sector(s))"
Write-Host "[ok] built .\kiss2_boot.img (1.44MB boot image)"
