# KISS2 Custom Stand-Alone Bootloader (BIOS Stage-1 + Stage-2 + UEFI Path)

This folder contains real bare-metal boot paths:

- BIOS stage-1 boot sector that loads stage-2 from disk sectors
- BIOS stage-2 loader stub
- UEFI boot application (`EFI/BOOT/BOOTX64.EFI`)

## What this is

- Stand-alone stage-1 BIOS boot sector (`boot_stage1.S`)
- Stand-alone stage-2 BIOS loader (`boot_stage2.S`)
- Linker script for boot address `0x7C00` (`boot_stage1.ld`)
- Build pipeline using LLVM tools already present on your machine
- Produces:
  - `boot_stage1.sector.bin` (exactly 512 bytes, includes `0x55AA` signature)
  - `boot_stage2.bin` (loaded by stage-1 via BIOS INT 13h)
  - `kiss2_boot.img` (1.44MB bootable image with stage-1 in sector 0)
  - `BOOTX64.EFI` and `EFI/BOOT/BOOTX64.EFI` (UEFI fallback path)

## Filesystem note (your 8GB model issue)

- FAT32 cannot store files larger than 4GB.
- TempleOS filesystem was **RedSea** (its own custom FS), not FAT32.
- For modern USB boot with large model files, use a dual-partition layout:
  - Small FAT32 EFI/boot partition (contains `EFI/BOOT/BOOTX64.EFI` and boot files)
  - Large data partition (exFAT/NTFS/ext4) for model payloads over 4GB

## Build

```powershell
powershell -ExecutionPolicy Bypass -File .\build_bootloader.ps1
```

## Build UEFI path

```powershell
powershell -ExecutionPolicy Bypass -File .\build_uefi.ps1
```

## Validate

```powershell
powershell -ExecutionPolicy Bypass -File .\validate_bootloader.ps1
```

## Test in VM (if QEMU installed)

```powershell
qemu-system-x86_64 -drive format=raw,file=kiss2_boot.img
```

Expected screen output:

- `KISS2 custom stand-alone bootloader stage-1`
- `Loading stage-2 from disk...`
- `KISS2 stage-2 BIOS loader online.`

## Next stage (planned)

1. Add kernel payload loading from stage-2 (currently stage-2 prints/hangs).
2. Implement common handoff protocol between BIOS and UEFI paths.
3. Add model partition discovery and payload loading logic.
4. Integrate chat runtime components progressively.

This intentionally does **not** depend on Windows at runtime; Windows is only used here as the build host.
