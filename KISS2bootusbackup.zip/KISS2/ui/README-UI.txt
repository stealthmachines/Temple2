KISS2 UI payload staged on boot partition.
Use chat-nginx.html or chat-council.html depending on runtime endpoint.
This is static UI staging; network/runtime service is provided by later kernel stages.
